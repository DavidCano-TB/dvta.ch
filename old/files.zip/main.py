# =============================================================================
# DVDcoin Bank — Backend v4.0
# 5-DB architecture: users.db | rights.db | transactions.db | stats.db | opo.db
# Superadmin: dvd + nebulosa | Admin: nina, victor, yu + dynamic
# =============================================================================
 
import os, sys, asyncio, sqlite3, time as _time, logging, signal, json as _json
from datetime import datetime, timedelta
from typing import Optional
from contextlib import asynccontextmanager
 
from fastapi import FastAPI, HTTPException, Depends, Request, WebSocket, WebSocketDisconnect, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
 
import bcrypt as _bcrypt
from jose import JWTError, jwt
from pydantic import BaseModel
 
try:
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded
    _has_limiter = True
except ImportError:
    _has_limiter = False
    def get_remote_address(r): return "127.0.0.1"
    class _FakeLimiter:
        def limit(self, *a, **k): return lambda f: f
        def init_app(self, *a): pass
    class _FakeExc(Exception): pass
    RateLimitExceeded = _FakeExc
 
# =============================================================================
# CONFIG
# =============================================================================
 
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
DATA_DIR  = os.path.join(BASE_DIR, "data")
 
# 5 separate DB files
DB_USERS  = os.path.join(DATA_DIR, "users.db")        # users, lang_prefs
DB_RIGHTS = os.path.join(DATA_DIR, "rights.db")       # roles, opo_players
DB_TX     = os.path.join(DATA_DIR, "transactions.db") # transactions
DB_STATS  = os.path.join(DATA_DIR, "stats.db")        # sessions
DB_OPO    = os.path.join(DATA_DIR, "opo.db")          # opo_results, opo_sessions
 
# Legacy path for auto-migration
DB_LEGACY = os.path.join(BASE_DIR, "dvdcoin.db")
 
CONF_DIR    = os.path.join(BASE_DIR, "conf")
GALLERY_DIR = os.path.join(BASE_DIR, "static", "gallery")
GALLERY_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".svg"}
 
ADMINS      = {"dvd", "nebulosa", "nina", "victor", "yu", "roy","admin","aitor"}
SUPERADMINS = {"dvd", "nebulosa"}
GHOST       = {"admin"}
ALL_ADMINS  = ADMINS | GHOST
 
JWT_ALGORITHM  = "HS256"
JWT_EXPIRE_H   = 168  # 1 week
ONLINE_TIMEOUT_S = 90
TX_MAX_ROWS    = 1000
 
_ONLINE: dict = {}
 
logger = logging.getLogger("dvdcoin")
logging.basicConfig(level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
 
# =============================================================================
# JWT
# =============================================================================
 
def _load_jwt_secret() -> str:
    os.makedirs(CONF_DIR, exist_ok=True)
    p = os.path.join(CONF_DIR, "jwt_secret.txt")
    if os.path.exists(p):
        s = open(p).read().strip()
        if s: return s
    import secrets
    s = secrets.token_hex(32)
    open(p, "w").write(s)
    return s
 
JWT_SECRET = _load_jwt_secret()
 
def create_token(username: str) -> str:
    exp = datetime.utcnow() + timedelta(hours=JWT_EXPIRE_H)
    return jwt.encode({"sub": username, "exp": exp}, JWT_SECRET, algorithm=JWT_ALGORITHM)
 
def decode_token(token: str) -> Optional[str]:
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return data.get("sub")
    except JWTError:
        return None
 
security = HTTPBearer()
 
def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)) -> str:
    u = decode_token(creds.credentials)
    if not u:
        raise HTTPException(401, "Invalid or expired session")
    # Check is_blocked for ALL authenticated users on every request (not just GHOST)
    conn = db_users()
    row = conn.execute("SELECT is_blocked FROM users WHERE username=?", (u,)).fetchone()
    conn.close()
    if row and row["is_blocked"]:
        raise HTTPException(403, "Account blocked")
    return u
 
def verify_password(plain: str, hashed: str) -> bool:
    if hashed in ("__UNSET__", "__AUTO__"): return False
    try: return _bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception: return False
 
def hash_password(plain: str) -> str:
    return _bcrypt.hashpw(plain.encode(), _bcrypt.gensalt()).decode()
 
# =============================================================================
# MASTER PASSWORD — emergency superadmin access
# Generated once on first startup, stored in conf/master.txt, printed to logs.
# Allows dvd/nebulosa to login even if their hash is unknown/broken.
# =============================================================================
 
_MASTER_PASSWORD: str = ""
 
def _load_master_password() -> str:
    """Load or generate the master emergency password for superadmins."""
    import secrets as _sec, string as _str
    os.makedirs(CONF_DIR, exist_ok=True)
    p = os.path.join(CONF_DIR, "master.txt")
    if os.path.exists(p):
        pwd = open(p).read().strip()
        if pwd:
            return pwd
    pwd = "dvd_" + "".join(_sec.choice(_str.ascii_letters + _str.digits) for _ in range(12))
    open(p, "w").write(pwd)
    return pwd
 
 
# =============================================================================
# DATABASE
# =============================================================================
 
def _open_db(path: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn
 
def db_users()  -> sqlite3.Connection: return _open_db(DB_USERS)
def db_rights() -> sqlite3.Connection: return _open_db(DB_RIGHTS)
def db_tx()     -> sqlite3.Connection: return _open_db(DB_TX)
def db_stats()  -> sqlite3.Connection: return _open_db(DB_STATS)
def db_opo()    -> sqlite3.Connection: return _open_db(DB_OPO)
 
# Legacy alias for code that uses db_connect()
def db_connect() -> sqlite3.Connection: return db_users()
 
def db_init():
    """Create all tables. Safe to call on every restart."""
    os.makedirs(DATA_DIR, exist_ok=True)
 
    # users.db
    c = db_users()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            username        TEXT PRIMARY KEY,
            password_hash   TEXT    NOT NULL DEFAULT '__UNSET__',
            balance         REAL    NOT NULL DEFAULT 0.0,
            is_blocked      INTEGER NOT NULL DEFAULT 0,
            failed_attempts INTEGER NOT NULL DEFAULT 0,
            locked_until    TEXT,
            created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
            lang_pref       TEXT    NOT NULL DEFAULT 'en'
        );
        CREATE TABLE IF NOT EXISTS lang_prefs (
            username   TEXT PRIMARY KEY,
            lang       TEXT NOT NULL DEFAULT 'en',
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    """)
    c.commit()
    # Add lang_pref column to existing DB if missing (migration safety)
    try:
        c.execute("ALTER TABLE users ADD COLUMN lang_pref TEXT NOT NULL DEFAULT 'en'")
        c.commit()
    except Exception:
        pass  # column already exists
    c.close()
 
    # rights.db
    c = db_rights()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS roles (
            username   TEXT PRIMARY KEY,
            role       TEXT NOT NULL DEFAULT 'admin',
            granted_by TEXT,
            granted_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS opo_players (
            username TEXT PRIMARY KEY,
            added_by TEXT NOT NULL DEFAULT 'dvd',
            added_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    """)
    c.commit(); c.close()
 
    # transactions.db
    c = db_tx()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS transactions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            from_user   TEXT NOT NULL,
            to_user     TEXT NOT NULL,
            amount      REAL NOT NULL,
            concept     TEXT NOT NULL DEFAULT '',
            created_at  TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_tx_from ON transactions(from_user);
        CREATE INDEX IF NOT EXISTS idx_tx_to   ON transactions(to_user);
        CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(created_at);
    """)
    c.commit(); c.close()
 
    # stats.db
    c = db_stats()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT NOT NULL,
            section    TEXT NOT NULL,
            detail     TEXT NOT NULL DEFAULT '',
            started_at TEXT NOT NULL DEFAULT (datetime('now')),
            ended_at   TEXT,
            duration_s INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_sess_user ON sessions(username);
        CREATE INDEX IF NOT EXISTS idx_sess_sect ON sessions(section);
        CREATE INDEX IF NOT EXISTS idx_sess_dt   ON sessions(started_at);
    """)
    c.commit(); c.close()
 
    # opo.db
    c = db_opo()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS opo_results (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT NOT NULL,
            block_n    INTEGER NOT NULL,
            played_at  TEXT NOT NULL DEFAULT (datetime('now')),
            correct    INTEGER NOT NULL DEFAULT 0,
            wrong      INTEGER NOT NULL DEFAULT 0,
            wrong_qs   TEXT NOT NULL DEFAULT '[]',
            duration_s INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_opo_user  ON opo_results(username);
        CREATE INDEX IF NOT EXISTS idx_opo_block ON opo_results(block_n);
        CREATE INDEX IF NOT EXISTS idx_opo_date  ON opo_results(played_at);
        CREATE TABLE IF NOT EXISTS opo_sessions (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT NOT NULL,
            started_at TEXT NOT NULL DEFAULT (datetime('now')),
            ended_at   TEXT,
            duration_s INTEGER
        );
    """)
    c.commit(); c.close()
 
 
def _auto_migrate_legacy():
    """Migrate user hashes from dvdcoin.db (or .migrated backup) into data/users.db.
    Runs every startup so admin password hashes are always correct."""
    # Try the live file first, then the renamed backup
    legacy = DB_LEGACY
    if not os.path.exists(legacy):
        legacy = DB_LEGACY + ".migrated"
    if not os.path.exists(legacy):
        return  # No source DB at all
    logger.info("Running migration from %s ...", os.path.basename(legacy))
 
    logger.info("Starting auto-migration from dvdcoin.db ...")
    try:
        import sqlite3 as _sq
        leg = _sq.connect(legacy)
        leg.row_factory = _sq.Row
        migrated = {}
 
        # users — smart merge:
        #   • GHOST users are skipped (keep __UNSET__ so default password works)
        #   • New users get full row inserted
        #   • Existing users only get hash updated if current hash is __UNSET__
        try:
            rows = leg.execute("SELECT * FROM users").fetchall()
            c = db_users()
            for r in rows:
                d = dict(r)
                uname = d.get("username", "")
                if uname in GHOST:
                    continue  # never overwrite ghost users — they use default password
                src_hash = d.get("password_hash", "__UNSET__")
                # Check if user already exists with a real hash
                existing = c.execute(
                    "SELECT password_hash FROM users WHERE username=?", (uname,)
                ).fetchone()
                if existing is None:
                    # New user — insert full row
                    c.execute(
                        "INSERT INTO users(username,password_hash,balance,is_blocked,"
                        "failed_attempts,locked_until,created_at) VALUES(?,?,?,?,?,?,?)",
                        (uname, src_hash, d.get("balance", 0), d.get("is_blocked", 0),
                         d.get("failed_attempts", 0), d.get("locked_until"), d.get("created_at"))
                    )
                elif existing["password_hash"] in ("__UNSET__", "__AUTO__"):
                    # Existing user with no real hash — update hash only
                    c.execute(
                        "UPDATE users SET password_hash=? WHERE username=?",
                        (src_hash, uname)
                    )
                # else: user already has a real hash — leave it alone
            c.commit(); c.close()
            migrated["users"] = len(rows)
        except Exception as e:
            logger.warning("Migration users: %s", e)
 
        # transactions
        try:
            rows = leg.execute("SELECT * FROM transactions").fetchall()
            c = db_tx()
            for r in rows:
                d = dict(r)
                c.execute(
                    "INSERT OR IGNORE INTO transactions(id,from_user,to_user,amount,concept,created_at)"
                    " VALUES(?,?,?,?,?,?)",
                    (d.get("id"), d.get("from_user"), d.get("to_user"),
                     d.get("amount",0), d.get("concept",""), d.get("created_at"))
                )
            c.commit(); c.close()
            migrated["transactions"] = len(rows)
        except Exception as e:
            logger.warning("Migration transactions: %s", e)
 
        # sessions
        try:
            rows = leg.execute("SELECT * FROM sessions").fetchall()
            c = db_stats()
            for r in rows:
                d = dict(r)
                c.execute(
                    "INSERT OR IGNORE INTO sessions(id,username,section,detail,started_at,ended_at,duration_s)"
                    " VALUES(?,?,?,?,?,?,?)",
                    (d.get("id"), d.get("username"), d.get("section","bank"),
                     d.get("detail",""), d.get("started_at"), d.get("ended_at"), d.get("duration_s"))
                )
            c.commit(); c.close()
            migrated["sessions"] = len(rows)
        except Exception as e:
            logger.warning("Migration sessions: %s", e)
 
        # opo_players
        try:
            rows = leg.execute("SELECT * FROM opo_players").fetchall()
            c = db_rights()
            for r in rows:
                d = dict(r)
                c.execute(
                    "INSERT OR IGNORE INTO opo_players(username,added_by,added_at) VALUES(?,?,?)",
                    (d.get("username"), d.get("added_by","dvd"), d.get("added_at"))
                )
            c.commit(); c.close()
            migrated["opo_players"] = len(rows)
        except Exception as e:
            logger.warning("Migration opo_players: %s", e)
 
        # opo_results
        try:
            rows = leg.execute("SELECT * FROM opo_results").fetchall()
            c = db_opo()
            for r in rows:
                d = dict(r)
                c.execute(
                    "INSERT OR IGNORE INTO opo_results(id,username,block_n,played_at,correct,wrong,wrong_qs)"
                    " VALUES(?,?,?,?,?,?,?)",
                    (d.get("id"), d.get("username"), d.get("block_n",1),
                     d.get("played_at"), d.get("correct",0), d.get("wrong",0), d.get("wrong_qs","[]"))
                )
            c.commit(); c.close()
            migrated["opo_results"] = len(rows)
        except Exception as e:
            logger.warning("Migration opo_results: %s", e)
 
        leg.close()
        # Rename legacy DB so we never migrate again
        # Rename the live file after migration so we use the .migrated copy next time
        if os.path.exists(DB_LEGACY):
            os.rename(DB_LEGACY, DB_LEGACY + ".migrated")
        logger.info("Auto-migration complete: %s. Legacy DB renamed to dvdcoin.db.migrated", migrated)
    except Exception as e:
        logger.error("Auto-migration failed: %s", e)
 
 
def _load_opo_users() -> set:
    try:
        c = db_rights()
        rows = c.execute("SELECT username FROM opo_players").fetchall()
        c.close()
        return {"dvd", "nebulosa"} | {r["username"] for r in rows}
    except Exception:
        return {"dvd", "nebulosa"}
 
 
def _load_admins_from_db() -> set:
    base = {"dvd", "nebulosa", "nina", "victor", "yu","roy","admin"}
    try:
        c = db_rights()
        rows = c.execute("SELECT username FROM roles WHERE role='admin'").fetchall()
        c.close()
        return base | {r["username"] for r in rows}
    except Exception:
        return base
 
 
OPO_USERS: set = {"dvd", "nebulosa"}  # refreshed at startup
 
# ── In-memory video room registry ─────────────────────────────────────────────
import uuid as _uuid
_ROOMS: dict = {}   # room_key → {host, title, mode, invites:set, members:set}
 
def _room_public_list(username: str) -> list:
    """Rooms visible to username: public rooms + private rooms where user is invited."""
    result = []
    for k, r in list(_ROOMS.items()):
        if r["mode"] == "public" or username in r["invites"] or username == r["host"]:
            result.append({
                "key": k, "title": r["title"], "host": r["host"],
                "mode": r["mode"], "members": list(r["members"]),
                "invited": username in r["invites"],
            })
    return result
 
# Per-user OPO managers
_opo_managers: dict = {}
 
def get_opo_manager(username: str) -> "OpoManager":
    if username not in _opo_managers:
        _opo_managers[username] = OpoManager()
    return _opo_managers[username]
 
# =============================================================================
# SESSION TRACKING
# =============================================================================
 
_OPEN_SESSIONS: dict = {}
 
def _open_session(username: str, section: str, detail: str = "") -> int:
    if username in GHOST: return 0
    key = f"{username}:{section}"
    now = datetime.utcnow().isoformat(timespec="seconds")
    conn = db_stats()
    old_id = _OPEN_SESSIONS.get(key)
    if old_id:
        conn.execute(
            "UPDATE sessions SET ended_at=?, duration_s=CAST((julianday(?)-julianday(started_at))*86400 AS INT)"
            " WHERE id=?", (now, now, old_id)
        )
    row = conn.execute(
        "INSERT INTO sessions(username,section,detail,started_at) VALUES(?,?,?,?) RETURNING id",
        (username, section, detail, now)
    ).fetchone()
    sid = row["id"] if row else 0
    conn.commit(); conn.close()
    _OPEN_SESSIONS[key] = sid
    return sid
 
def _ping_session(username: str, section: str, detail: str = ""):
    if username in GHOST: return
    key = f"{username}:{section}"
    if key not in _OPEN_SESSIONS:
        _open_session(username, section, detail)
        return
    sid = _OPEN_SESSIONS[key]
    if detail:
        conn = db_stats()
        conn.execute("UPDATE sessions SET detail=? WHERE id=?", (detail, sid))
        conn.commit(); conn.close()
 
def _close_session(username: str, section: str):
    if username in GHOST: return
    key = f"{username}:{section}"
    sid = _OPEN_SESSIONS.pop(key, None)
    if not sid: return
    now = datetime.utcnow().isoformat(timespec="seconds")
    conn = db_stats()
    conn.execute(
        "UPDATE sessions SET ended_at=?, duration_s=CAST((julianday(?)-julianday(started_at))*86400 AS INT)"
        " WHERE id=?", (now, now, sid)
    )
    conn.commit(); conn.close()
 
# =============================================================================
# SEED / INIT HELPERS
# =============================================================================
 
 
def _repair_admin_accounts():
    """On every startup: ensure no superadmin is stuck with __UNSET__ hash or lockout.
    If a superadmin has __UNSET__ hash, try to pull the real hash from dvdcoin.db.migrated."""
    legacy = DB_LEGACY + ".migrated"
    leg_hashes = {}
    if os.path.exists(legacy):
        try:
            import sqlite3 as _sq2
            lc = _sq2.connect(legacy)
            lc.row_factory = _sq2.Row
            for row in lc.execute("SELECT username, password_hash FROM users"):
                leg_hashes[row["username"]] = row["password_hash"]
            lc.close()
        except Exception:
            pass
 
    conn = db_users()
    for u in SUPERADMINS | ADMINS:
        row = conn.execute(
            "SELECT password_hash, locked_until, failed_attempts FROM users WHERE username=?", (u,)
        ).fetchone()
        if not row:
            continue
        updates = {}
        # Repair __UNSET__ hash using legacy DB
        if row["password_hash"] in ("__UNSET__", "__AUTO__") and u in leg_hashes:
            real_hash = leg_hashes[u]
            if real_hash not in ("__UNSET__", "__AUTO__"):
                updates["password_hash"] = real_hash
                logger.info("Repaired password hash for admin @%s from legacy backup", u)
        # Clear lockout for ALL admins on every startup
        if row["locked_until"] or row["failed_attempts"] > 0:
            updates["locked_until"] = None
            updates["failed_attempts"] = 0
            logger.info("Cleared lockout for admin @%s", u)
        if updates:
            sets = ", ".join(f"{k}=?" for k in updates)
            conn.execute(f"UPDATE users SET {sets} WHERE username=?",
                         list(updates.values()) + [u])
    conn.commit()
    conn.close()
 
def seed_admins():
    conn = db_users()
    for u in ADMINS:
        conn.execute("INSERT OR IGNORE INTO users(username) VALUES(?)", (u,))
        conn.execute("UPDATE users SET balance=0.0 WHERE username=?", (u,))
    # Ghost "admin" user: always keep hash as __UNSET__ so default password works
    conn.execute("INSERT OR IGNORE INTO users(username) VALUES(?)", ("admin",))
    conn.execute(
        "UPDATE users SET password_hash='__UNSET__', failed_attempts=0, locked_until=NULL"
        " WHERE username='admin'"
    )
    conn.commit(); conn.close()
 
def check_lockout(username: str):
    conn = db_users()
    row = conn.execute("SELECT locked_until FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if row and row["locked_until"]:
        try:
            lu = datetime.fromisoformat(row["locked_until"])
            if datetime.utcnow() < lu:
                raise HTTPException(403, f"Account temporarily locked until {row['locked_until']} UTC")
        except ValueError:
            pass
 
def record_failed_login(username: str):
    conn = db_users()
    conn.execute("UPDATE users SET failed_attempts=failed_attempts+1 WHERE username=?", (username,))
    row = conn.execute("SELECT failed_attempts FROM users WHERE username=?", (username,)).fetchone()
    if row and row["failed_attempts"] >= 5:
        lu = (datetime.utcnow() + timedelta(minutes=15)).isoformat(timespec="seconds")
        conn.execute("UPDATE users SET locked_until=? WHERE username=?", (lu, username))
    conn.commit(); conn.close()
 
def clear_failed_logins(username: str):
    conn = db_users()
    conn.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE username=?", (username,))
    conn.commit(); conn.close()
 
def get_or_create_user(username: str) -> bool:
    """Ensure user exists in users.db. Returns True if just created."""
    conn = db_users()
    if conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
        conn.close(); return False
    conn.execute("INSERT INTO users(username,password_hash) VALUES(?,?)", (username, "__AUTO__"))
    conn.commit(); conn.close()
    return True
 
def zero_admin_balances():
    conn = db_users()
    for u in ADMINS:
        conn.execute("UPDATE users SET balance=0.0 WHERE username=?", (u,))
    conn.commit(); conn.close()
 
async def cleanup_old_transactions():
    while True:
        await asyncio.sleep(86400)
        try:
            conn = db_tx()
            conn.execute(
                "DELETE FROM transactions WHERE id NOT IN "
                "(SELECT id FROM transactions ORDER BY created_at DESC LIMIT ?)", (TX_MAX_ROWS,)
            )
            conn.commit(); conn.close()
        except Exception as e:
            logger.error("Cleanup error: %s", e)
 
# =============================================================================
# NO-SLEEP KEEP-ALIVE
# =============================================================================
 
async def _no_sleep_task():
    import urllib.request, urllib.error
    log_path = os.path.join(BASE_DIR, "no_sleep.log")
    await asyncio.sleep(30)
    while True:
        try:
            urllib.request.urlopen("http://localhost:8000/api/health", timeout=8)
            msg = f"{datetime.utcnow().isoformat(timespec='seconds')} [no-sleep] OK\n"
        except Exception as e:
            msg = f"{datetime.utcnow().isoformat(timespec='seconds')} [no-sleep] FAIL {e}\n"
        try:
            # Keep log to last 200 lines
            lines = []
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()[-199:]
            with open(log_path, "w", encoding="utf-8") as f:
                f.writelines(lines)
                f.write(msg)
        except Exception:
            pass
        await asyncio.sleep(240)
 
# =============================================================================
# LIFESPAN
# =============================================================================
 
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("DVDcoin Bank v4.0 starting ...")
    db_init()
    _auto_migrate_legacy()   # copies dvdcoin.db → 5 new DBs on first run, renames old
    seed_admins()
    _repair_admin_accounts()   # fix any admin with __UNSET__ hash or lockout
    # Refresh dynamic sets from DB
    global ADMINS, ALL_ADMINS, OPO_USERS
    ADMINS    = _load_admins_from_db()
    ALL_ADMINS = ADMINS | GHOST
    OPO_USERS = _load_opo_users()
    # Load cuentos enabled flag
    global _cuentos_enabled
    _cuentos_enabled = _load_cuentos_enabled()
    # Background tasks
    asyncio.create_task(cleanup_old_transactions())
    asyncio.create_task(_no_sleep_task())
    # Master password — emergency access for superadmins
    global _MASTER_PASSWORD
    _MASTER_PASSWORD = _load_master_password()
    logger.info("=" * 60)
    logger.info("🔑 MASTER PASSWORD (dvd/nebulosa emergency login): %s", _MASTER_PASSWORD)
    logger.info("   (stored in conf/master.txt — delete to regenerate)")
    logger.info("=" * 60)
    logger.info("Ready. Admins: %s | OPO users: %s", sorted(ADMINS), sorted(OPO_USERS))
    yield
    logger.info("Shutting down.")
 
# =============================================================================
# APP
# =============================================================================
 
limiter = Limiter(key_func=get_remote_address) if _has_limiter else _FakeLimiter()
 
app = FastAPI(title="DVDcoin Bank", version="4.0", lifespan=lifespan)
 
if _has_limiter:
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
 
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"])
 
# Ensure static subdirs exist
for _d in ["gallery", "cuentos", "i18n", "opo", "pasapalabra", "millonario"]:
    os.makedirs(os.path.join(BASE_DIR, "static", _d), exist_ok=True)
 
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
 
# =============================================================================
# PYDANTIC MODELS
# =============================================================================
 
class LoginRequest(BaseModel):
    username: str
    password: str
 
class RegisterRequest(BaseModel):
    username: str
    password: str
 
class TransferRequest(BaseModel):
    to_user: str
    amount:  float
    concept: str = ""
 
class LangRequest(BaseModel):
    lang: str
 
class AdminCreateRequest(BaseModel):
    username: str
    password: str = ""
 
class OpoPlayerRequest(BaseModel):
    username: str
 
class OpoResultRequest(BaseModel):
    block_n:  int
    correct:  int
    wrong:    int
    wrong_qs: list = []
 
# =============================================================================
# CORE ROUTES
# =============================================================================
 
@app.get("/", response_class=HTMLResponse)
async def root():
    """Redirect to the static frontend."""
    resp = FileResponse(os.path.join(BASE_DIR, "static", "index.html"))
    resp.headers["ngrok-skip-browser-warning"] = "1"
    return resp
 
@app.get("/api/health")
async def health():
    """Health check endpoint."""
    return {"status": "ok", "time": datetime.utcnow().isoformat()}
 
 
class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str
 
 
@app.post("/api/me/change-password")
async def change_my_password(body: ChangePasswordRequest, user: str = Depends(get_current_user)):
    """Allow any authenticated user to change their own password."""
    if len(body.new_password) < 4:
        raise HTTPException(400, "Password must be at least 4 characters")
    # Verify old password (or master password for superadmins)
    conn = db_users()
    row = conn.execute("SELECT password_hash FROM users WHERE username=?", (user,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "User not found")
    master_ok = (user in SUPERADMINS and _MASTER_PASSWORD and body.old_password == _MASTER_PASSWORD)
    if not master_ok and not verify_password(body.old_password, row["password_hash"]):
        conn.close()
        raise HTTPException(401, "Current password is incorrect")
    new_hash = hash_password(body.new_password)
    conn.execute("UPDATE users SET password_hash=? WHERE username=?", (new_hash, user))
    conn.commit()
    conn.close()
    logger.info("Password changed for @%s", user)
    return {"ok": True}
 
@app.post("/api/ping")
async def ping(user: str = Depends(get_current_user), request: Request = None):
    _ONLINE[user] = _time.time()
    return {"ok": True}
 
# =============================================================================
# AUTH
# =============================================================================
 
@app.post("/api/login")
@limiter.limit("20/minute")
async def login(request: Request, body: LoginRequest):
    u = body.username.strip().lower()
    if u in GHOST:
        conn = db_users()
        row = conn.execute("SELECT password_hash FROM users WHERE username=?", (u,)).fetchone()
        conn.close()
        default_pwd = "dvd_ghost_2026"
        if row and row["password_hash"] not in ("__UNSET__", "__AUTO__"):
            if not verify_password(body.password, row["password_hash"]):
                raise HTTPException(401, "Invalid credentials")
        elif body.password != default_pwd:
            raise HTTPException(401, "Invalid credentials")
        return {"token": create_token(u), "username": u, "is_admin": True, "is_superadmin": False}
 
    check_lockout(u)
    conn = db_users()
    row = conn.execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(401, "Invalid credentials")
    if row["is_blocked"]:
        raise HTTPException(403, "Account blocked. Contact an admin.")
 
    # Master password bypass for superadmins (emergency access)
    master_ok = (u in SUPERADMINS and _MASTER_PASSWORD and body.password == _MASTER_PASSWORD)
 
    if not master_ok and not verify_password(body.password, row["password_hash"]):
        record_failed_login(u)
        raise HTTPException(401, "Invalid credentials")
 
    clear_failed_logins(u)
    _open_session(u, "bank")
    logger.info("Login: %s %s", u, "[MASTER]" if master_ok else "")
    lang = "en"
    try:
        if "lang_pref" in row.keys():
            lang = row["lang_pref"] or "en"
    except Exception:
        pass
    return {
        "token":        create_token(u),
        "username":     u,
        "balance":      0.0 if u in ADMINS else row["balance"],
        "is_admin":     u in ADMINS,
        "is_superadmin": u in SUPERADMINS,
        "lang":         lang,
    }
 
@app.post("/api/register")
@limiter.limit("10/minute")
async def register(request: Request, body: RegisterRequest):
    u = body.username.strip().lower()
    if not (2 <= len(u) <= 30):
        raise HTTPException(400, "Username must be 2–30 characters")
    if len(body.password) < 4:
        raise HTTPException(400, "Password must be at least 4 characters")
    if u in GHOST:
        raise HTTPException(400, "Reserved username")
    conn = db_users()
    row = conn.execute("SELECT password_hash FROM users WHERE username=?", (u,)).fetchone()
    if row and row["password_hash"] not in ("__UNSET__", "__AUTO__"):
        conn.close()
        raise HTTPException(409, "Username already registered")
    pwd_hash = hash_password(body.password)
    if row:
        conn.execute("UPDATE users SET password_hash=? WHERE username=?", (pwd_hash, u))
    else:
        conn.execute("INSERT INTO users(username,password_hash) VALUES(?,?)", (u, pwd_hash))
    conn.commit(); conn.close()
    _open_session(u, "bank")
    logger.info("Register: %s", u)
    return {"token": create_token(u), "username": u, "is_admin": False, "is_superadmin": False}
 
@app.get("/api/me")
async def me(user: str = Depends(get_current_user)):
    """Return the authenticated user profile."""
    if user in GHOST:
        return {"username": user, "balance": 0.0, "is_admin": True, "is_superadmin": False,
                "created_at": None, "is_blocked": False, "lang": "en"}
    conn = db_users()
    row = conn.execute("SELECT * FROM users WHERE username=?", (user,)).fetchone()
    conn.close()
    if not row:
        # JWT valid but user not in DB — auto-create a minimal record
        conn = db_users()
        conn.execute(
            "INSERT OR IGNORE INTO users(username, password_hash, balance) VALUES(?, '__AUTO__', 0.0)",
            (user,)
        )
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE username=?", (user,)).fetchone()
        conn.close()
        if not row:
            raise HTTPException(404, "User not found")
    lang = "en"
    try:
        keys = row.keys() if hasattr(row, 'keys') else []
        if "lang_pref" in keys:
            lang = row["lang_pref"] or "en"
    except Exception:
        pass
    return {
        "username":      row["username"],
        "balance":       0.0 if user in ADMINS else row["balance"],
        "created_at":    row["created_at"],
        "is_admin":      user in ADMINS,
        "is_superadmin": user in SUPERADMINS,
        "is_blocked":    bool(row["is_blocked"]),
        "lang":          lang,
    }
 
# =============================================================================
# LANGUAGE PREFERENCE
# =============================================================================
 
@app.post("/api/me/lang")
async def set_lang(body: LangRequest, user: str = Depends(get_current_user)):
    """Save user language preference to the DB."""
    if body.lang not in {"es","en","fr","it","de"}:
        raise HTTPException(400, "Invalid language")
    conn = db_users()
    conn.execute("UPDATE users SET lang_pref=? WHERE username=?", (body.lang, user))
    conn.execute(
        "INSERT OR REPLACE INTO lang_prefs(username,lang,updated_at) VALUES(?,?,datetime('now'))",
        (user, body.lang)
    )
    conn.commit(); conn.close()
    return {"ok": True, "lang": body.lang}
 
@app.get("/api/me/lang")
async def get_lang(user: str = Depends(get_current_user)):
    """Retrieve user language preference."""
    conn = db_users()
    row = conn.execute("SELECT * FROM users WHERE username=?", (user,)).fetchone()
    conn.close()
    lang = "en"
    if row:
        try:
            if "lang_pref" in row.keys():
                lang = row["lang_pref"] or "en"
        except Exception:
            pass
    return {"lang": lang}
 
# =============================================================================
# USERS / TRANSFER / HISTORY
# =============================================================================
 
@app.get("/api/users")
async def list_users(user: str = Depends(get_current_user)):
    """Return list of all registered usernames."""
    conn = db_users()
    rows = conn.execute(
        "SELECT username FROM users WHERE password_hash NOT IN ('__UNSET__','__AUTO__') ORDER BY username"
    ).fetchall()
    conn.close()
    return [r["username"] for r in rows if r["username"] != user]
 
@app.post("/api/transfer")
@limiter.limit("30/minute")
async def transfer(request: Request, body: TransferRequest, user: str = Depends(get_current_user)):
    to_user = body.to_user.strip().lower()
    amount  = round(body.amount, 6)
    if to_user == user:      raise HTTPException(400, "Cannot transfer to yourself")
    if amount <= 0:          raise HTTPException(400, "Amount must be positive")
    if len(body.concept) > 200: raise HTTPException(400, "Reference max 200 chars")
 
    # User operations → users.db
    uconn = db_users()
    if user not in ADMINS:
        sender = uconn.execute("SELECT balance FROM users WHERE username=?", (user,)).fetchone()
        if not sender:
            uconn.close(); raise HTTPException(404, "Sender not found")
        if sender["balance"] < amount:
            uconn.close(); raise HTTPException(400, f"Insufficient funds: {sender['balance']:.4f}")
 
    was_created = get_or_create_user(to_user)
    if user not in ADMINS:
        uconn.execute("UPDATE users SET balance=balance-? WHERE username=?", (amount, user))
    if to_user not in ADMINS:
        uconn.execute("UPDATE users SET balance=balance+? WHERE username=?", (amount, to_user))
    for u in ADMINS:
        uconn.execute("UPDATE users SET balance=0.0 WHERE username=?", (u,))
    uconn.commit()
    new_balance = 0.0 if user in ADMINS else         uconn.execute("SELECT balance FROM users WHERE username=?", (user,)).fetchone()["balance"]
    uconn.close()
 
    # Transaction record → transactions.db
    tconn = db_tx()
    tconn.execute(
        "INSERT INTO transactions(from_user,to_user,amount,concept) VALUES(?,?,?,?)",
        (user, to_user, amount, body.concept)
    )
    tconn.commit(); tconn.close()
 
    logger.info("Transfer %s→%s %.4f", user, to_user, amount)
    return {"success": True, "new_balance": new_balance, "auto_created": was_created,
            "message": f"Sent {amount} DVDcoins to @{to_user}"}
 
@app.get("/api/history")
async def history(user: str = Depends(get_current_user), limit:
    int = 100):
    conn = db_tx()
    # Admins see ALL transactions; members see only their own
    if user in ADMINS:
        rows = conn.execute(
            "SELECT id,from_user,to_user,amount,concept,created_at FROM transactions "
            "ORDER BY created_at DESC LIMIT ?",
            (min(limit, TX_MAX_ROWS),)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id,from_user,to_user,amount,concept,created_at FROM transactions "
            "WHERE from_user=? OR to_user=? ORDER BY created_at DESC LIMIT ?",
            (user, user, min(limit, TX_MAX_ROWS))
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
# =============================================================================
# ADMIN
# =============================================================================
 
@app.get("/api/admin/users")
async def admin_users(user: str = Depends(get_current_user)):
    """Return users. Superadmins see all + admins. Regular admins see members only."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_users()
    rows = conn.execute(
        "SELECT username,password_hash,balance,is_blocked,failed_attempts,locked_until,created_at "
        "FROM users ORDER BY username"
    ).fetchall()
    conn.close()
    now = _time.time()
    result = []
    for r in rows:
        d = dict(r)
        uname = d["username"]
        if user not in SUPERADMINS:
            if uname in GHOST:  continue   # hide ghost
            if uname in ADMINS: continue   # regular admins only see members
        d.pop("password_hash", None)
        last_ping = _ONLINE.get(uname, 0)
        d["is_admin"]     = uname in ADMINS
        d["is_superadmin"]= uname in SUPERADMINS
        d["is_ghost"]     = uname in GHOST
        d["registered"]   = r["password_hash"] not in ("__UNSET__","__AUTO__")
        d["online"]       = now - last_ping < ONLINE_TIMEOUT_S
        d["last_ping_at"] = last_ping if last_ping > 0 else None
        if d["is_admin"]: d["balance"] = 0.0
        result.append(d)
    result.sort(key=lambda x: (not x.get("is_admin", False), x["username"].lower()))
    return result
 
@app.get("/api/admin/ledger")
async def admin_ledger(user: str = Depends(get_current_user), limit:
    int = 1000):
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_tx()
    rows = conn.execute(
        "SELECT id,from_user,to_user,amount,concept,created_at FROM transactions "
        "ORDER BY created_at DESC LIMIT ?", (min(limit, TX_MAX_ROWS),)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
@app.get("/api/admin/activity")
async def admin_activity(user: str = Depends(get_current_user), limit:
    int = 500):
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_stats()
    rows = conn.execute(
        "SELECT id,username,section,detail,started_at,ended_at,duration_s "
        "FROM sessions ORDER BY started_at DESC LIMIT ?", (min(limit, 2000),)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
@app.get("/api/admin/connected")
async def admin_connected(user: str = Depends(get_current_user)):
    """Return list of currently connected users."""
    if user not in ADMINS:
        raise HTTPException(403)
    now = _time.time()
    return [u for u, t in _ONLINE.items() if now - t < ONLINE_TIMEOUT_S]
 
@app.post("/api/admin/block/{target}")
async def admin_block(target: str, user: str = Depends(get_current_user)):
    """Block a user account."""
    if user not in ADMINS: raise HTTPException(403)
    if target in ALL_ADMINS: raise HTTPException(400, "Cannot block admins")
    conn = db_users()
    conn.execute("UPDATE users SET is_blocked=1 WHERE username=?", (target,))
    conn.commit(); conn.close()
    return {"ok": True}
 
@app.post("/api/admin/unblock/{target}")
async def admin_unblock(target: str, user: str = Depends(get_current_user)):
    """Unblock or unlock a user account."""
    if user not in ADMINS: raise HTTPException(403)
    conn = db_users()
    conn.execute("UPDATE users SET is_blocked=0,failed_attempts=0,locked_until=NULL WHERE username=?", (target,))
    conn.commit(); conn.close()
    return {"ok": True}
 
@app.post("/api/admin/reset-pwd/{target}")
async def admin_reset_pwd(target: str, user: str = Depends(get_current_user)):
    """Reset a member password to unset state."""
    if user not in ADMINS: raise HTTPException(403)
    if target in GHOST and user not in SUPERADMINS: raise HTTPException(403)
    conn = db_users()
    conn.execute("UPDATE users SET password_hash='__UNSET__',failed_attempts=0,locked_until=NULL WHERE username=?", (target,))
    conn.commit(); conn.close()
    return {"ok": True}
 
@app.delete("/api/admin/delete/{target}")
async def admin_delete(target: str, user: str = Depends(get_current_user)):
    """Permanently delete a user account (dvd password required)."""
    if user not in ADMINS: raise HTTPException(403)
    if target in ALL_ADMINS: raise HTTPException(400, "Cannot delete admins")
    conn = db_users()
    conn.execute("DELETE FROM users WHERE username=?", (target,))
    conn.commit(); conn.close()
    return {"ok": True}
 
# Superadmin: manage admins
@app.get("/api/admin/list-admins")
async def list_admins(user: str = Depends(get_current_user)):
    """List all admin-role users."""
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_users()
    rows = conn.execute("SELECT username,password_hash,created_at FROM users ORDER BY username").fetchall()
    conn.close()
    return [{"username": r["username"], "is_superadmin": r["username"] in SUPERADMINS,
             "registered": r["password_hash"] not in ("__UNSET__","__AUTO__"),
             "created_at": r["created_at"]}
            for r in rows if r["username"] in ADMINS and r["username"] not in GHOST]
 
@app.post("/api/admin/create-admin")
async def create_admin(body: AdminCreateRequest, user: str = Depends(get_current_user)):
    """Grant admin role to an existing or new user."""
    global ADMINS, ALL_ADMINS
    if user not in SUPERADMINS: raise HTTPException(403)
    uname = body.username.strip().lower()
    if len(uname) < 2 or uname in GHOST: raise HTTPException(400, "Invalid username")
    conn = db_users()
    conn.execute("INSERT OR IGNORE INTO users(username) VALUES(?)", (uname,))
    conn.execute("UPDATE users SET balance=0.0 WHERE username=?", (uname,))
    if body.password:
        conn.execute("UPDATE users SET password_hash=? WHERE username=?", (hash_password(body.password), uname))
    conn.commit(); conn.close()
    ADMINS = ADMINS | {uname}
    ALL_ADMINS = ADMINS | GHOST
    c = db_rights()
    c.execute("INSERT OR REPLACE INTO roles(username,role,granted_by) VALUES(?,?,?)", (uname,"admin",user))
    c.commit(); c.close()
    return {"ok": True, "username": uname}
 
@app.delete("/api/admin/delete-admin/{target}")
async def delete_admin_route(target: str, user: str = Depends(get_current_user)):
    """Revoke admin role from a user."""
    global ADMINS, ALL_ADMINS
    if user not in SUPERADMINS: raise HTTPException(403)
    if target in SUPERADMINS: raise HTTPException(400, "Cannot remove superadmin")
    ADMINS = ADMINS - {target}
    ALL_ADMINS = ADMINS | GHOST
    c = db_rights()
    c.execute("DELETE FROM roles WHERE username=? AND role='admin'", (target,))
    c.commit(); c.close()
    return {"ok": True}
 
@app.post("/api/admin/reset-admin-pwd/{target}")
async def reset_admin_pwd(target: str, user: str = Depends(get_current_user)):
    """Reset an admin password."""
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_users()
    conn.execute("UPDATE users SET password_hash='__UNSET__',failed_attempts=0,locked_until=NULL WHERE username=?", (target,))
    conn.commit(); conn.close()
    return {"ok": True}
 
# =============================================================================
# STATS
# =============================================================================
 
@app.get("/api/stats/summary")
async def stats_summary(user: str = Depends(get_current_user)):
    """Return per-user session summary for the stats dashboard."""
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_stats()
    rows = conn.execute(
        "SELECT username, COUNT(*) AS total_sessions, COALESCE(SUM(duration_s),0) AS total_seconds,"
        " MAX(started_at) AS last_seen, GROUP_CONCAT(DISTINCT section) AS sections "
        "FROM sessions GROUP BY username ORDER BY last_seen DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
@app.get("/api/stats/user/{uname}")
async def stats_user(uname: str, user: str = Depends(get_current_user)):
    """Return session history for a specific user."""
    if user not in SUPERADMINS and user != uname: raise HTTPException(403)
    conn = db_stats()
    rows = conn.execute(
        "SELECT id,section,detail,started_at,ended_at,duration_s FROM sessions "
        "WHERE username=? ORDER BY started_at DESC LIMIT 500", (uname,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
@app.get("/api/stats/section/{section}")
async def stats_section(section: str, user: str = Depends(get_current_user)):
    """Return session history for a specific game section."""
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_stats()
    rows = conn.execute(
        "SELECT id,username,detail,started_at,ended_at,duration_s FROM sessions "
        "WHERE section=? ORDER BY started_at DESC LIMIT 500", (section,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
@app.get("/api/stats/activity")
async def stats_activity(
    user: str = Depends(get_current_user),
    username: str = "", section: str = "",
    date_from: str = "", date_to: str = "", limit: int = 500
):
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_stats()
    q = "SELECT id,username,section,detail,started_at,ended_at,duration_s FROM sessions WHERE 1=1"
    p = []
    if username:  q += " AND username LIKE ?";   p.append(f"%{username}%")
    if section:   q += " AND section=?";          p.append(section)
    if date_from: q += " AND started_at >= ?";   p.append(date_from)
    if date_to:   q += " AND started_at <= ?";   p.append(date_to+"T23:59:59")
    q += f" ORDER BY started_at DESC LIMIT {min(limit,2000)}"
    rows = conn.execute(q, p).fetchall()
    # Totals
    tq = "SELECT COUNT(*) n, COALESCE(SUM(duration_s),0) s FROM sessions WHERE 1=1"
    tp = []
    if username:  tq += " AND username LIKE ?";  tp.append(f"%{username}%")
    if section:   tq += " AND section=?";         tp.append(section)
    if date_from: tq += " AND started_at >= ?";  tp.append(date_from)
    if date_to:   tq += " AND started_at <= ?";  tp.append(date_to+"T23:59:59")
    tot = conn.execute(tq, tp).fetchone()
    conn.close()
    return {"sessions": [dict(r) for r in rows],
            "total_sessions": tot["n"] if tot else 0,
            "total_seconds": tot["s"] if tot else 0}
 
@app.get("/api/stats/games")
async def stats_games(user: str = Depends(get_current_user)):
    """Return session stats grouped by game section for the dashboard."""
    if user not in SUPERADMINS:
        raise HTTPException(403)
    conn = db_stats()
    rows = conn.execute(
        "SELECT section, COUNT(*) total_sessions, COUNT(DISTINCT username) unique_users,"
        " COALESCE(SUM(duration_s),0) total_seconds, MAX(started_at) last_activity"
        " FROM sessions WHERE section != 'bank'"
        " GROUP BY section ORDER BY total_sessions DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
 
@app.get("/api/stats/transactions-summary")
async def stats_transactions_summary(user: str = Depends(get_current_user)):
    """Return transaction totals, top senders and receivers."""
    if user not in SUPERADMINS:
        raise HTTPException(403)
    conn = db_tx()  # FIX: was db_connect() which returned users.db; transactions are in transactions.db
    total_row = conn.execute(
        "SELECT COUNT(*) n, COALESCE(SUM(amount),0) vol FROM transactions"
    ).fetchone()
    top_recv = conn.execute(
        "SELECT to_user username, COUNT(*) tx, SUM(amount) total"
        " FROM transactions GROUP BY to_user ORDER BY total DESC LIMIT 10"
    ).fetchall()
    top_send = conn.execute(
        "SELECT from_user username, COUNT(*) tx, SUM(amount) total"
        " FROM transactions GROUP BY from_user ORDER BY total DESC LIMIT 10"
    ).fetchall()
    daily = conn.execute(
        "SELECT substr(created_at,1,10) day, COUNT(*) tx, SUM(amount) vol"
        " FROM transactions GROUP BY day ORDER BY day DESC LIMIT 30"
    ).fetchall()
    conn.close()
    return {
        "total_tx": total_row["n"] if total_row else 0,
        "total_vol": total_row["vol"] if total_row else 0,
        "top_receivers": [dict(r) for r in top_recv],
        "top_senders":   [dict(r) for r in top_send],
        "daily":         [dict(r) for r in daily],
    }
 
 

@app.get("/api/stats/advanced")
async def stats_advanced(user: str = Depends(get_current_user)):
    """Return advanced session analytics: by section and by user. Called by the History tab."""
    if user not in SUPERADMINS:
        raise HTTPException(403)
    conn = db_stats()
    by_section = conn.execute(
        "SELECT section, COUNT(*) n, COALESCE(AVG(duration_s),0) avg_s, "
        "COALESCE(SUM(duration_s),0) total_s "
        "FROM sessions WHERE duration_s IS NOT NULL "
        "GROUP BY section ORDER BY n DESC"
    ).fetchall()
    by_user = conn.execute(
        "SELECT username, COUNT(*) n, COALESCE(SUM(duration_s),0) total_s, "
        "MAX(started_at) last_seen "
        "FROM sessions GROUP BY username ORDER BY total_s DESC LIMIT 20"
    ).fetchall()
    recent = conn.execute(
        "SELECT username, section, detail, started_at, ended_at, duration_s "
        "FROM sessions ORDER BY started_at DESC LIMIT 100"
    ).fetchall()
    conn.close()
    return {
        "by_section": [dict(r) for r in by_section],
        "by_user":    [dict(r) for r in by_user],
        "recent":     [dict(r) for r in recent],
    }


@app.get("/api/stats/members-overview")
async def stats_members_overview(user: str = Depends(get_current_user)):
    """Return per-member stats: balance, sessions, last seen, sections used."""
    if user not in SUPERADMINS:
        raise HTTPException(403)
    conn_u = db_users()  # FIX: was db_connect() which is an alias but explicit is safer
    conn_s = db_stats()
    users = conn_u.execute(
        "SELECT username, balance, created_at FROM users"
        " WHERE password_hash NOT IN ('__UNSET__','__AUTO__') ORDER BY username"
    ).fetchall()
    sessions_by_user = {}
    for row in conn_s.execute(
        "SELECT username, COUNT(*) sessions, COALESCE(SUM(duration_s),0) total_s,"
        " MAX(started_at) last_seen, GROUP_CONCAT(DISTINCT section) sections"
        " FROM sessions GROUP BY username"
    ).fetchall():
        sessions_by_user[row["username"]] = dict(row)
    conn_u.close(); conn_s.close()
    result = []
    for u in users:
        s = sessions_by_user.get(u["username"], {})
        result.append({
            "username":   u["username"],
            "balance":    u["balance"],
            "created_at": u["created_at"],
            "sessions":   s.get("sessions", 0),
            "total_s":    s.get("total_s", 0),
            "last_seen":  s.get("last_seen", None),
            "sections":   s.get("sections", ""),
        })
    result.sort(key=lambda x: x["last_seen"] or "", reverse=True)
    return result
 
 
# =============================================================================
# CUENTOS
# =============================================================================
import zipfile as _zipfile
import re as _re
 
CUENTOS_DIR    = os.path.join(BASE_DIR, "static", "cuentos")
_SUPPORTED_EXT = {".docx", ".odt", ".txt"}
_CUENTOS_META  = os.path.join(CUENTOS_DIR, ".meta.json")
 
 
# ── Meta helpers (masked list + enabled flag) ─────────────────────────────────
 
def _load_meta() -> dict:
    try:
        if os.path.exists(_CUENTOS_META):
            with open(_CUENTOS_META, encoding="utf-8") as f:
                return _json.load(f)
    except Exception:
        pass
    return {"masked": [], "enabled": False}
 
 
def _save_meta(meta: dict):
    os.makedirs(CUENTOS_DIR, exist_ok=True)
    with open(_CUENTOS_META, "w", encoding="utf-8") as f:
        _json.dump(meta, f, ensure_ascii=False, indent=2)
 
 
# ── Enabled state (persisted to disk) ─────────────────────────────────────────
 
_cuentos_enabled: bool = False  # loaded from disk in lifespan
 
 
def _load_cuentos_enabled() -> bool:
    return bool(_load_meta().get("enabled", False))
 
 
# ── Office file readers ───────────────────────────────────────────────────────
 
def _parse_docx_xml(xml: str) -> list:
    blocks = []
    for pm in _re.finditer(r"<w:p[ >].*?</w:p>", xml, _re.DOTALL):
        px   = pm.group()
        sm   = _re.search(r'<w:pStyle w:val="([^"]+)"', px)
        style     = sm.group(1) if sm else ""
        is_head   = "Heading" in style or style in ("Title", "Subtitle")
        runs      = _re.findall(r"<w:r[ >].*?</w:r>", px, _re.DOTALL)
        truns     = [r for r in runs if _re.search(r"<w:t[> ]", r)]
        bruns     = [r for r in truns if "<w:b/>" in r or "<w:b " in r]
        all_bold  = len(truns) > 0 and len(bruns) >= len(truns)
        texts     = _re.findall(r"<w:t[^>]*>(.*?)</w:t>", px, _re.DOTALL)
        text      = "".join(texts).strip()
        if not text:
            continue
        btype = "heading" if is_head else ("bold" if all_bold else "paragraph")
        blocks.append({"type": btype, "text": text})
    return blocks
 
 
def _parse_odt_xml(xml: str) -> list:
    blocks = []
    for pm in _re.finditer(r"<text:[ph][^>]*>.*?</text:[ph]>", xml, _re.DOTALL):
        tag     = pm.group()
        is_head = tag.startswith("<text:h")
        sm      = _re.search(r'text:style-name="([^"]+)"', tag)
        style   = sm.group(1) if sm else ""
        text    = _re.sub(r"<[^>]+>", "", tag).strip()
        text    = (text.replace("&amp;", "&").replace("&lt;", "<")
                       .replace("&gt;", ">").replace("&apos;", "'")
                       .replace("&quot;", '"'))
        if not text:
            continue
        if is_head or "Heading" in style or "Title" in style:
            btype = "heading"
        elif "Bold" in style:
            btype = "bold"
        else:
            btype = "paragraph"
        blocks.append({"type": btype, "text": text})
    return blocks
 
 
def _read_blocks(path: str) -> list:
    # Plain text files
    if path.lower().endswith(".txt"):
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                lines = f.read().splitlines()
            blocks = []
            for line in lines:
                if line.strip():
                    blocks.append({"type": "paragraph", "text": line})
                else:
                    blocks.append({"type": "paragraph", "text": ""})
            return blocks or [{"type": "paragraph", "text": "(Archivo vacío)"}]
        except Exception as e:
            logger.error("_read_blocks txt %s: %s", path, e)
            return []
    try:
        with _zipfile.ZipFile(path, "r") as z:
            names = z.namelist()
            if "word/document.xml" in names:
                xml = z.open("word/document.xml").read().decode("utf-8", errors="replace")
                return _parse_docx_xml(xml)
            elif "content.xml" in names:
                xml = z.open("content.xml").read().decode("utf-8", errors="replace")
                return _parse_odt_xml(xml)
            else:
                return []
    except Exception as e:
        logger.error("_read_blocks %s: %s", path, e)
        return []
 
 
def _office_title(path: str) -> str:
    for b in _read_blocks(path):
        t = b["text"].strip()
        for prefix in ["Título:", "Titulo:", "Title:", "TÍTULO:"]:
            if t.startswith(prefix):
                t = t[len(prefix):].strip()
        t = t.strip('"').strip("“").strip("”").strip("‘").strip("’").strip()
        if len(t) > 2 and t.lower() not in ("contents", "índice", "indice"):
            return t
    return os.path.splitext(os.path.basename(path))[0]
 
 
def _office_date(fname: str) -> str:
    base = os.path.splitext(fname)[0]
    m = _re.search(r"(?:^|_)(\d{1,2})_(\d{1,2})_(\d{2,4})(?:_\d+)?$", base)
    if m:
        d, mo, y = m.groups()
        y = "20" + y if len(y) == 2 else y
        try:
            if 1 <= int(mo) <= 12 and 1 <= int(d) <= 31:
                return f"{int(d):02d}/{int(mo):02d}/{y}"
        except ValueError:
            pass
    return ""
 
 
# ── Routes ────────────────────────────────────────────────────────────────────
 
@app.get("/admin/cuentos", response_class=HTMLResponse)
async def cuentos_admin_page():
    """Serve the cuentos admin management page."""
    resp = FileResponse(os.path.join(BASE_DIR, "static", "cuentos_admin.html"))
    resp.headers["ngrok-skip-browser-warning"] = "1"
    return resp
 
 
@app.get("/api/cuentos/status")
async def cuentos_status():
    """Return cuentos enabled state."""
    return {"enabled": _cuentos_enabled}
 
 
@app.post("/api/cuentos/toggle")
async def cuentos_toggle(user: str = Depends(get_current_user)):
    """Enable or disable cuentos visibility."""
    global _cuentos_enabled
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Solo admins pueden activar los cuentos")
    _cuentos_enabled = not _cuentos_enabled
    meta = _load_meta()
    meta["enabled"] = _cuentos_enabled
    _save_meta(meta)
    logger.info("Cuentos %s by %s", "enabled" if _cuentos_enabled else "disabled", user)
    return {"enabled": _cuentos_enabled}
 
 
@app.post("/api/cuentos/upload")
async def cuentos_upload(file: UploadFile = File(...), user:
    str = Depends(get_current_user)):
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Solo admins")
    fname = os.path.basename(file.filename or "upload.docx")
    ext   = os.path.splitext(fname)[1].lower()
    if ext not in _SUPPORTED_EXT:
        raise HTTPException(400, "Solo .docx, .odt y .txt")
    os.makedirs(CUENTOS_DIR, exist_ok=True)
    dest = os.path.join(CUENTOS_DIR, fname)
    base, ext2 = os.path.splitext(fname)
    n = 1
    while os.path.exists(dest):
        dest = os.path.join(CUENTOS_DIR, f"{base}_{n}{ext2}")
        n += 1
    with open(dest, "wb") as fout:
        fout.write(await file.read())
    final = os.path.basename(dest)
    logger.info("Cuento uploaded: %s by %s", final, user)
    return {"ok": True, "filename": final, "title": _office_title(dest)}
 
 
@app.delete("/api/cuentos/file/{filename:path}")
async def cuentos_delete(filename: str, user: str = Depends(get_current_user)):
    """Delete a story file."""
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Solo admins")
    filename = os.path.basename(filename)
    path = os.path.join(CUENTOS_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(404, "No encontrado")
    os.remove(path)
    meta = _load_meta()
    meta["masked"] = [f for f in meta.get("masked", []) if f != filename]
    _save_meta(meta)
    return {"ok": True}
 
 
@app.post("/api/cuentos/mask/{filename:path}")
async def cuentos_mask(filename: str, user: str = Depends(get_current_user)):
    """Hide a story from members."""
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Solo admins")
    filename = os.path.basename(filename)
    if not os.path.exists(os.path.join(CUENTOS_DIR, filename)):
        raise HTTPException(404, "No encontrado")
    meta = _load_meta()
    if filename not in meta.get("masked", []):
        meta.setdefault("masked", []).append(filename)
    _save_meta(meta)
    return {"ok": True, "masked": True}
 
 
@app.post("/api/cuentos/unmask/{filename:path}")
async def cuentos_unmask(filename: str, user: str = Depends(get_current_user)):
    """Show a previously hidden story to members."""
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Solo admins")
    filename = os.path.basename(filename)
    meta = _load_meta()
    meta["masked"] = [f for f in meta.get("masked", []) if f != filename]
    _save_meta(meta)
    return {"ok": True, "masked": False}
 
 
@app.get("/stats", response_class=HTMLResponse)
async def stats_page():
    """Serve the statistics page."""
    resp = FileResponse(os.path.join(BASE_DIR, "static", "stats.html"))
    resp.headers["ngrok-skip-browser-warning"] = "1"
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp
 
@app.get("/cuentos", response_class=HTMLResponse)
async def cuentos_page():
    """Serve the cuentos member list page."""
    # Try the member-facing list first, fall back to legacy
    member_list = os.path.join(BASE_DIR, "static", "cuentos_member.html")
    if os.path.exists(member_list):
        resp = FileResponse(member_list)
    else:
        resp = FileResponse(os.path.join(BASE_DIR, "static", "cuentos.html"))
    resp.headers["ngrok-skip-browser-warning"] = "1"
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp
 
 
@app.get("/cuento/{filename:path}", response_class=HTMLResponse)
async def cuento_page(filename: str):
    """Serve a single cuento reader page."""
    resp = FileResponse(os.path.join(BASE_DIR, "static", "cuento.html"))
    resp.headers["ngrok-skip-browser-warning"] = "1"
    return resp
 
 
@app.get("/api/cuentos")
async def list_cuentos(user: str = Depends(get_current_user)):
    """List stories. When enabled: all users. When disabled: admins only."""
    if not _cuentos_enabled and user not in ALL_ADMINS:
        raise HTTPException(403, "Cuentos desactivados")
    _ping_session(user, "cuentos")
    if not os.path.exists(CUENTOS_DIR):
        return []
    items = []
    for fname in os.listdir(CUENTOS_DIR):
        if os.path.splitext(fname)[1].lower() not in _SUPPORTED_EXT:
            continue
        if fname.startswith("~") or fname.startswith("."):
            continue
        path      = os.path.join(CUENTOS_DIR, fname)
        meta      = _load_meta()
        is_masked = fname in meta.get("masked", [])
        if is_masked and user not in ALL_ADMINS:
            continue
        items.append({
            "filename": fname,
            "title":    _office_title(path),
            "date":     _office_date(fname),
            "masked":   is_masked,
        })
    dated   = sorted([x for x in items if x["date"]],
                     key=lambda x: (x["date"][6:], x["date"][3:5], x["date"][:2]),
                     reverse=True)
    undated = sorted([x for x in items if not x["date"]],
                     key=lambda x: x["title"].lower())
    return dated + undated
 
 
@app.get("/api/cuento/{filename:path}")
async def get_cuento(filename: str, user: str = Depends(get_current_user)):
    """Return full story content as structured blocks."""
    if not _cuentos_enabled and user not in ALL_ADMINS:
        raise HTTPException(403, "Cuentos desactivados")
    filename = os.path.basename(filename)
    if os.path.splitext(filename)[1].lower() not in _SUPPORTED_EXT:
        raise HTTPException(400, "Solo .docx, .odt y .txt")
    path = os.path.join(CUENTOS_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(404, f"Cuento no encontrado: {filename}")
    blocks = _read_blocks(path)
    if not blocks:
        blocks = [{"type": "paragraph", "text": "(Documento vacío o no legible)"}]
    _open_session(user, "cuentos", detail=_office_title(path))
    return {
        "filename": filename,
        "title":    _office_title(path),
        "date":     _office_date(filename),
        "blocks":   blocks,
    }
 
 
 
# =============================================================================
# QUIEN SOY
# =============================================================================
 
class QuienSoyManager:
    """
    Multi-player 'Who Am I?' game.
    dvd sets a secret character. Players take turns asking yes/no questions.
    Each player has 3 guess attempts before being eliminated.
    The AI (Claude) answers questions as the character.
    """
 
    def __init__(self):
        self.enabled:     bool = False
        self.connections: dict = {}        # username → WebSocket
        self._state:      dict = self._empty_state()
 
    # ── State ─────────────────────────────────────────────────────────────────
 
    def _empty_state(self) -> dict:
        return {
            "status":       "waiting",   # waiting|setup|playing|finished
            "character":    None,        # secret character name (only dvd sees)
            "players":      [],          # [{username, guesses_left, eliminated, score}]
            "current_idx":  0,           # whose turn to ask
            "history":      [],          # [{player, question, answer, type}] type=question|guess
            "winner":       None,
            "question_pending": False,   # True while waiting for AI response
        }
 
    def _build_broadcast(self, viewer: str = None) -> dict:
        s = self._state
        players_pub = []
        for p in s["players"]:
            players_pub.append({
                "username":    p["username"],
                "guesses_left": p["guesses_left"],
                "eliminated":  p["eliminated"],
                "score":       p.get("score", 0),
            })
        # Only dvd sees the character name
        is_host = viewer in SUPERADMINS
        return {
            "type":       "state",
            "enabled":    self.enabled,
            "status":     s["status"],
            "character":  s["character"] if is_host else None,
            "players":    players_pub,
            "current_idx": s["current_idx"],
            "history":    s["history"],
            "winner":     s["winner"],
            "question_pending": s["question_pending"],
            "connected":  list(self.connections.keys()),
        }
 
    # ── WebSocket ─────────────────────────────────────────────────────────────
 
    async def connect(self, username: str, ws: WebSocket):
        await ws.accept()
        self.connections[username] = ws
        try:
            await ws.send_json(self._build_broadcast(viewer=username))
        except Exception:
            pass
 
    def disconnect(self, username: str):
        self.connections.pop(username, None)
 
    async def broadcast(self):
        dead = []
        for uname, sock in list(self.connections.items()):
            try:
                await sock.send_json(self._build_broadcast(viewer=uname))
            except Exception:
                dead.append(uname)
        for u in dead:
            self.connections.pop(u, None)
 
    # ── AI question answering ─────────────────────────────────────────────────
 
    async def _ask_ai(self, character: str, question: str) -> str:
        """Answer yes/no based strictly on the character's most famous role/aspect."""
        try:
            import json as _json, urllib.request as _urlreq, urllib.error as _urlerr
 
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")
            if not api_key:
                logger.warning("QuienSoy: ANTHROPIC_API_KEY not set")
                return "No"
 
            system = (
                "You are the referee in a 'Who Am I?' guessing game. "
                "The secret character is: " + character + ". "
                "Your only job is to answer the player's yes/no question with 'Sí' or 'No'. "
                "CRITICAL RULES:\n"
                "1. Answer based EXCLUSIVELY on what " + character + " is MOST FAMOUS FOR — "
                "their primary, universally-known role, trait, or identity. "
                "Ignore obscure facts, trivia, or secondary aspects that most people would not know.\n"
                "2. Respond with EXACTLY one word: 'Sí' or 'No'. Nothing else. No punctuation. No explanation.\n"
                "3. If the question is unclear or does not apply, answer 'No'."
            )
 
            user_msg = "Question: " + question
 
            payload = _json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 5,
                "system": system,
                "messages": [{"role": "user", "content": user_msg}],
            }).encode()
 
            req_obj = _urlreq.Request(
                "https://api.anthropic.com/v1/messages",
                data=payload,
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                method="POST"
            )
 
            with _urlreq.urlopen(req_obj, timeout=15) as resp:
                raw = _json.loads(resp.read().decode())
                answer = raw["content"][0]["text"].strip().lower()
 
            if any(w in answer for w in ["sí", "si", "yes", "oui"]):
                return "Sí"
            return "No"
 
        except Exception as e:
            logger.error("QuienSoy AI error: %s", e)
            return "No"
 
    # ── Actions ───────────────────────────────────────────────────────────────
 
    async def handle_action(self, act: dict, admin: str):
        action = act.get("action")
 
        if action == "setup":
            usernames = [str(u).strip() for u in act.get("players", []) if str(u).strip()]
            character = str(act.get("character", "")).strip()
            if not usernames or not character:
                return
            self._state = self._empty_state()
            self._state["status"]    = "playing"
            self._state["character"] = character
            self._state["players"]   = [
                {"username": u, "guesses_left": 3, "eliminated": False, "score": 0}
                for u in usernames
            ]
            self._state["current_idx"] = 0
            self.enabled = True
            await self.broadcast()
 
        elif action == "ask":
            # Current player (or host) asks a yes/no question answered by Claude AI.
            question = str(act.get("question", "")).strip()
            if not question or self._state["status"] != "playing":
                return
            if self._state["question_pending"]:
                return
            s   = self._state
            cur = s["players"][s["current_idx"]] if s["players"] else None
            if not cur or cur["eliminated"]:
                return
            # Non-host players can only ask on their own turn
            if admin not in SUPERADMINS and cur["username"] != admin:
                return
 
            s["question_pending"] = True
            await self.broadcast()
 
            answer = await self._ask_ai(s["character"], question)
 
            s["history"].append({
                "player":   cur["username"],
                "question": question,
                "answer":   answer,
                "type":     "question",
            })
            s["question_pending"] = False
            await self.broadcast()
 
        elif action == "guess":
            # Current player guesses the character name.
            guess = str(act.get("guess", "")).strip()
            if not guess or self._state["status"] != "playing":
                return
            s   = self._state
            cur = s["players"][s["current_idx"]] if s["players"] else None
            if not cur or cur["eliminated"]:
                return
            # Non-host players can only guess on their own turn
            if admin not in SUPERADMINS and cur["username"] != admin:
                return
 
            correct = guess.lower().strip() == s["character"].lower().strip()
            s["history"].append({
                "player":   cur["username"],
                "question": guess,
                "answer":   "¡Correcto! 🎉" if correct else "No es correcto ❌",
                "type":     "guess",
                "correct":  correct,
            })
 
            if correct:
                cur["score"] += 1
                s["winner"] = cur["username"]
                s["status"] = "finished"
                await self.broadcast()
                return
 
            # Wrong guess: deduct one attempt
            cur["guesses_left"] -= 1
            if cur["guesses_left"] <= 0:
                cur["eliminated"] = True
 
            # Check if all players are eliminated
            alive = [p for p in s["players"] if not p["eliminated"]]
            if not alive:
                s["status"] = "finished"
                s["winner"] = None
                await self.broadcast()
                return
 
            # Advance to next non-eliminated player
            await self._next_player()
            await self.broadcast()
 
        elif action == "next_turn":
            # dvd manually advances turn (skips current player)
            await self._next_player()
            await self.broadcast()
 
        elif action == "reset":
            self._state = self._empty_state()
            await self.broadcast()
 
        elif action == "reveal":
            # dvd reveals the character (ends game)
            self._state["status"] = "finished"
            await self.broadcast()
 
    async def _next_player(self):
        s = self._state
        n = len(s["players"])
        if not n:
            return
        start = s["current_idx"]
        for i in range(1, n + 1):
            idx = (start + i) % n
            if not s["players"][idx]["eliminated"]:
                s["current_idx"] = idx
                return
 
 
quien_soy_manager = QuienSoyManager()
 
 
# =============================================================================
# QUIEN SOY — Routes
# =============================================================================
 
@app.get("/quiensoy", response_class=HTMLResponse)
async def quien_soy_page():
    """Serve the Quien Soy game page."""
    return _serve_game_page(QUIEN_SOY_DIR)
 
 
@app.get("/api/quiensoy/status")
async def quien_soy_status():
    """Return Quien Soy enabled state."""
    return {"enabled": quien_soy_manager.enabled}
 
 
class QuienSoyToggleRequest(BaseModel):
    enabled: bool
 
@app.post("/api/quiensoy/toggle")
async def quien_soy_toggle(body: QuienSoyToggleRequest, user: str = Depends(get_current_user)):
    """Enable or disable Quien Soy."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    quien_soy_manager.enabled = body.enabled
    if not body.enabled:
        quien_soy_manager._state = quien_soy_manager._empty_state()
    await quien_soy_manager.broadcast()
    return {"enabled": quien_soy_manager.enabled}
 
 
@app.get("/api/quiensoy/users")
async def quien_soy_users(user: str = Depends(get_current_user)):
    """Return eligible user list for Quien Soy."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_connect()
    rows = conn.execute(
        "SELECT username FROM users WHERE password_hash NOT IN ('__UNSET__','__AUTO__') ORDER BY username ASC"
    ).fetchall()
    conn.close()
    return [r["username"] for r in rows]
 
 
 
 
class QuienSoySetupRequest(BaseModel):
    character: str
    players:   list
 
 
@app.post("/api/quiensoy/setup")
async def quien_soy_setup(body: QuienSoySetupRequest, user: str = Depends(get_current_user)):
    """Start a QuienSoy game directly from the admin panel (no WS needed)."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    character = body.character.strip()
    players   = [str(u).strip() for u in body.players if str(u).strip()]
    if not character or not players:
        raise HTTPException(400, "Character and players required")
    await quien_soy_manager.handle_action(
        {"action": "setup", "character": character, "players": players},
        admin=user
    )
    return {"ok": True, "status": quien_soy_manager._state["status"]}
 
 
@app.get("/api/quiensoy/verify-character")
async def quien_soy_verify(name: str, user: str = Depends(get_current_user)):
    """Ask Claude if a character is real/famous and return canonical name + suggestions."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    name = name.strip()
    if not name:
        raise HTTPException(400, "Name required")
 
    # Always return a valid dict — never let this endpoint return 500
    fallback = {"valid": True, "canonical": name, "hint": "", "suggestions": []}
 
    try:
        import json as _json, urllib.request as _urlreq, urllib.error as _urlerr
 
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            logger.warning("verify-character: ANTHROPIC_API_KEY not set, returning fallback")
            return fallback
 
        prompt = (
            "You are helping set up a Who Am I guessing game. "
            "The host typed: '" + name + "'. "
            "Reply ONLY with a compact JSON object — no markdown, no explanation. Fields:\n"
            "- valid: true if this is a real, widely-known person or fictional character; false otherwise\n"
            "- canonical: the most recognised Spanish or English name for them\n"
            "- hint: one sentence (max 12 words) describing them WITHOUT saying their name\n"
            "- suggestions: array of exactly 3 other famous characters the host might like\n"
            'Example: {"valid":true,"canonical":"Mario Bros","hint":"Fontanero de Nintendo que salta sobre plataformas",'
            '"suggestions":["Luigi","Sonic the Hedgehog","Link de Zelda"]}'
        )
 
        payload = _json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 300,
            "messages": [{"role": "user", "content": prompt}]
        }).encode()
 
        req_obj = _urlreq.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            method="POST"
        )
 
        try:
            with _urlreq.urlopen(req_obj, timeout=15) as resp:
                raw = resp.read().decode()
        except _urlerr.HTTPError as e:
            body = e.read().decode()
            logger.error("verify-character API error %s: %s", e.code, body[:200])
            return fallback
        except Exception as e:
            logger.error("verify-character network error: %s", e)
            return fallback
 
        # Parse Claude response
        data = _json.loads(raw)
        text = data["content"][0]["text"].strip()
 
        # Strip markdown fences if Claude added them
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            text = text.rsplit("```", 1)[0].strip()
 
        result = _json.loads(text)
 
        # Validate shape
        if not isinstance(result, dict):
            return fallback
 
        return {
            "valid":       bool(result.get("valid", True)),
            "canonical":   str(result.get("canonical", name)),
            "hint":        str(result.get("hint", "")),
            "suggestions": [str(s) for s in result.get("suggestions", [])][:3],
        }
 
    except Exception as e:
        logger.error("verify-character unexpected error: %s", e)
        return fallback
 
 
@app.websocket("/ws/quiensoy")
async def quien_soy_ws(websocket: WebSocket, token: str = ""):
    """WebSocket handler for Quien Soy game.
    Hosts (dvd/nebulosa) control game flow (setup, next_turn, reveal, reset).
    All authenticated players can send 'ask' and 'guess' actions on their turn.
    """
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Authentication required")
        return
    conn = db_connect()
    row = conn.execute("SELECT username FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        await websocket.close(code=4001, reason="User not found")
        return
    _open_session(username, "quiensoy")
    await quien_soy_manager.connect(username, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            action = data.get("action", "")
            # Host actions: full control
            if username in ADMINS:
                try:
                    await quien_soy_manager.handle_action(data, username)
                except Exception as e:
                    logger.error("QuienSoy handle_action error: %s", e)
            # Player actions: only ask and guess (server enforces turn ownership)
            elif action in ("ask", "guess"):
                try:
                    await quien_soy_manager.handle_action(data, username)
                except Exception as e:
                    logger.error("QuienSoy player action error: %s", e)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error("QuienSoy WS error: %s", e)
    finally:
        quien_soy_manager.disconnect(username)
 
 
# =============================================================================
# CIFRAS Y LETRAS
# =============================================================================
 
CIFRAS_LETRAS_DIR = os.path.join(BASE_DIR, "static", "cifrasletras")
 
import random as _cl_random
 
_CL_VOWELS     = list("AAAAEEEEEIIIOOOOUUU")
_CL_CONSONANTS = list("BBCCCDDDDFFGGHHHJJKLLLLLMMMMNNNNPPPQRRRRRSSSSTTTTTVWXYZ")
 
 
class CifrasLetrasManager:
    """
    Full Cifras y Letras game.
    status flow: waiting → letters|numbers → reviewing → waiting → ... → finished
    Admin validates letter answers individually; numbers auto-evaluated.
    """
 
    def __init__(self):
        self.enabled:     bool = False
        self.connections: dict = {}
        self._state:      dict = self._empty_state()
 
    # ── State ─────────────────────────────────────────────────────────────────
 
    def _empty_state(self) -> dict:
        return {
            "status":       "waiting",
            "mode":         None,         # "letters" | "numbers"
            "players":      [],           # [{username, score}]
            "round":        0,
            "max_rounds":   5,
            "letters":      [],
            "numbers":      [],
            "target":       0,
            "submissions":  {},           # {username: answer_str}
            "results":      [],           # [{username, answer, score}]
            "_pre_pause_status": None,
            "round_time":    30,
            "round_winner": None,
            "round_winners": [],
        }
 
    def _build_broadcast(self) -> dict:
        s = self._state
        return {
            "type":         "state",
            "enabled":      self.enabled,
            "status":       s["status"],
            "mode":         s["mode"],
            "players":      s["players"],
            "round":        s["round"],
            "max_rounds":   s["max_rounds"],
            "letters":      s["letters"],
            "numbers":      s["numbers"],
            "target":       s["target"],
            "submissions":  s["submissions"],
            "results":      s["results"],
            "round_time":    s.get("round_time", 30),
            "round_winner":  s["round_winner"],
            "round_winners":  s.get("round_winners", []),
            "connected":    list(self.connections.keys()),
        }
 
    # ── WS plumbing ───────────────────────────────────────────────────────────
 
    async def connect(self, username: str, ws: WebSocket):
        await ws.accept()
        self.connections[username] = ws
        try:   await ws.send_json(self._build_broadcast())
        except Exception: pass
 
    def disconnect(self, username: str):
        self.connections.pop(username, None)
 
    async def broadcast(self):
        data = self._build_broadcast()
        dead = []
        for u, sock in list(self.connections.items()):
            try:   await sock.send_json(data)
            except Exception: dead.append(u)
        for u in dead: self.connections.pop(u, None)
 
    # ── Generation ────────────────────────────────────────────────────────────
 
    def _gen_letters(self, vowels: int = 4) -> list:
        v = _cl_random.sample(_CL_VOWELS, min(vowels, len(_CL_VOWELS)))
        c = _cl_random.sample(_CL_CONSONANTS, 9 - len(v))
        letters = v + c
        _cl_random.shuffle(letters)
        return letters
 
    def _gen_numbers(self) -> tuple:
        big   = [25, 50, 75, 100]
        small = list(range(1, 11)) * 2
        bigs  = _cl_random.randint(0, 2)
        nums  = _cl_random.sample(big, bigs) + _cl_random.sample(small, 6 - bigs)
        _cl_random.shuffle(nums)
        target = _cl_random.randint(100, 999)
        return nums, target
 
    # ── Validation ────────────────────────────────────────────────────────────
 
    # ── Actions ───────────────────────────────────────────────────────────────
 
    async def handle_action(self, act: dict):
        action = act.get("action")
 
        # ── Setup ──────────────────────────────────────────────────────────
        if action == "setup":
            usernames  = [str(u).strip() for u in act.get("players", []) if str(u).strip()]
            max_rounds = max(1, min(10, int(act.get("max_rounds", 5))))
            if not usernames: return
            self._state = self._empty_state()
            self._state["players"]    = [{"username": u, "score": 0} for u in usernames]
            self._state["max_rounds"] = max_rounds
            self._state["round_time"] = max(10, min(300, int(act.get("round_time", 30))))
            self._state["status"]     = "waiting"
            self.enabled = True
            await self.broadcast()
 
        # ── Start round (show tiles, no timer yet) ──────────────────────────
        elif action == "start_letters":
            if not self._state["players"]: return
            if self._state["status"] not in ("waiting", "reviewing"): return
            self._state.update({
                "letters": self._gen_letters(int(act.get("vowels", 4))),
                "submissions": {}, "results": [], "round_winner": None,
                "round": self._state["round"] + 1,
                "mode": "letters", "status": "ready",
            })
            await self.broadcast()
 
        elif action == "start_numbers":
            if not self._state["players"]: return
            if self._state["status"] not in ("waiting", "reviewing"): return
            nums, target = self._gen_numbers()
            self._state.update({
                "numbers": nums, "target": target,
                "submissions": {}, "results": [], "round_winner": None,
                "round": self._state["round"] + 1,
                "mode": "numbers", "status": "ready",
            })
            await self.broadcast()
 
        # ── Start timer (input visible to players) ──────────────────────────
        elif action == "start_timer":
            if self._state["status"] != "ready": return
            self._state["status"]      = self._state["mode"]
            self._state["submissions"] = {}
            await self.broadcast()
 
        elif action == "restart_timer":
            s = self._state
            if s["mode"] not in ("letters", "numbers"): return
            s["submissions"] = {}
            s["results"]     = []
            s["round_winner"]= None
            s["status"]      = s["mode"]
            await self.broadcast()
 
        # ── Player submits answer ───────────────────────────────────────────
        elif action == "submit":
            u   = act.get("username", "")
            ans = str(act.get("answer", "")).strip()
            if not u or self._state["status"] not in ("letters", "numbers"): return
            if u in [p["username"] for p in self._state["players"]]:
                self._state["submissions"][u] = ans
                await self.broadcast()
 
        # ── Reveal: collect raw answers, go to reviewing ────────────────────
        elif action == "reveal":
            s = self._state
            if s["status"] not in ("letters", "numbers", "ready"): return
            results = []
            for p in s["players"]:
                u   = p["username"]
                ans = s["submissions"].get(u, "").strip()
                if s["mode"] == "letters":
                    ans = ans.upper()
                results.append({"username": u, "answer": ans or "—", "score": 0})
            s["results"] = results
            s["status"]  = "reviewing"
            await self.broadcast()
 
        # ── dvd declares winner (1 or more players) — ONLY dvd can do this ──
        elif action == "declare_winner":
            s = self._state
            if s["status"] != "reviewing": return
            winners = [str(u).strip() for u in act.get("winners", []) if str(u).strip()]
            pts     = max(1, int(act.get("pts", 1)))
            if not winners: return
            # Apply score
            for u in winners:
                for p in s["players"]:
                    if p["username"] == u:
                        p["score"] += pts
                for r in s["results"]:
                    if r["username"] == u:
                        r["score"] = pts
            s["round_winner"] = winners[0] if len(winners) == 1 else "tie"
            s["round_winners"] = winners   # all winners (tie support)
            # Advance or finish
            if s["round"] >= s["max_rounds"]:
                s["status"] = "finished"
            await self.broadcast()
 
        # ── Pause / Resume ──────────────────────────────────────────────────
        elif action == "pause":
            s = self._state
            if s["status"] in ("letters", "numbers", "ready"):
                s["_pre_pause"] = s["status"]
                s["status"] = "paused"
                await self.broadcast()
 
        elif action == "resume":
            s = self._state
            if s["status"] == "paused":
                s["status"] = s.get("_pre_pause", "ready")
                await self.broadcast()
 
        # ── Finish / Reset ──────────────────────────────────────────────────
        elif action == "finish":
            self._state["status"] = "finished"
            await self.broadcast()
 
        elif action == "reset":
            self._state = self._empty_state()
            await self.broadcast()
 
 
cifras_letras_manager = CifrasLetrasManager()
 
 
# ── CifrasLetras routes ───────────────────────────────────────────────────────
 
@app.get("/cifrasletras", response_class=HTMLResponse)
async def cifras_letras_page():
    """Serve the Cifras y Letras game page."""
    return _serve_game_page(CIFRAS_LETRAS_DIR)
 
 
@app.get("/api/cifrasletras/status")
async def cifras_letras_status():
    """Return Cifras y Letras enabled state."""
    return {"enabled": cifras_letras_manager.enabled}
 
 
class CifrasLetrasToggleRequest(BaseModel):
    enabled: bool
 
 
@app.post("/api/cifrasletras/toggle")
async def cifras_letras_toggle(body: CifrasLetrasToggleRequest, user: str = Depends(get_current_user)):
    """Enable or disable Cifras y Letras."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    cifras_letras_manager.enabled = body.enabled
    if not body.enabled:
        cifras_letras_manager._state = cifras_letras_manager._empty_state()
    await cifras_letras_manager.broadcast()
    return {"enabled": cifras_letras_manager.enabled}
 
 
@app.get("/api/cifrasletras/users")
async def cifras_letras_users(user: str = Depends(get_current_user)):
    """Return eligible user list for Cifras y Letras."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_connect()
    rows = conn.execute("SELECT username FROM users ORDER BY username ASC").fetchall()
    conn.close()
    return [r["username"] for r in rows]
 
 
class CifrasLetrasSetupRequest(BaseModel):
    players:    list
    max_rounds: int = 5
    round_time: int = 30
 
 
@app.post("/api/cifrasletras/setup")
async def cifras_letras_setup(body: CifrasLetrasSetupRequest, user: str = Depends(get_current_user)):
    """Start a Cifras y Letras game from the admin panel."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    players    = [str(u).strip() for u in body.players if str(u).strip()]
    max_rounds = max(1, min(10, int(body.max_rounds)))
    if not players:
        raise HTTPException(400, "At least one player required")
    round_time = max(10, min(300, int(body.round_time)))
    await cifras_letras_manager.handle_action({"action": "setup", "players": players, "max_rounds": max_rounds, "round_time": round_time})
    return {"ok": True}
 
 
@app.post("/api/cifrasletras/reset")
async def cifras_letras_reset(user: str = Depends(get_current_user)):
    """Reset Cifras y Letras game state."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    await cifras_letras_manager.handle_action({"action": "reset"})
    return {"ok": True}
 
 
@app.get("/api/cifrasletras/check-word")
async def cifras_letras_check_word(word: str, user: str = Depends(get_current_user)):
    """Ask Claude if a word is valid Spanish."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    word = word.strip().upper()
    if not word or not word.isalpha():
        return {"valid": False, "word": word, "reason": "Solo letras"}
    try:
        import json as _j, urllib.request as _ur, urllib.error as _ue
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return {"valid": True, "word": word, "reason": "Sin API key — aceptada por defecto"}
        prompt = (
            f"Is '{word}' a valid Spanish word (noun, verb, adjective, adverb — any form)? "
            f"Reply ONLY with a JSON object: "
            f'{{"valid": true/false, "word": "{word}", "reason": "brief explanation in Spanish"}}'
        )
        payload = _j.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 80,
            "messages": [{"role": "user", "content": prompt}]
        }).encode()
        req = _ur.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            method="POST"
        )
        with _ur.urlopen(req, timeout=10) as resp:
            raw = _j.loads(resp.read().decode())
            text = raw["content"][0]["text"].strip()
            if text.startswith("```"): text = text.split("\n",1)[-1].rsplit("```",1)[0].strip()
            result = _j.loads(text)
            return {"valid": bool(result.get("valid")), "word": word,
                    "reason": str(result.get("reason", ""))}
    except Exception as e:
        logger.error("check-word error: %s", e)
        return {"valid": True, "word": word, "reason": "Error de verificación — aceptada por defecto"}
 
 
@app.websocket("/ws/cifrasletras")
async def cifras_letras_ws(websocket: WebSocket, token: str = ""):
    """WebSocket handler for Cifras y Letras game."""
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Authentication required")
        return
    conn = db_connect()
    row  = conn.execute("SELECT username FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        await websocket.close(code=4001, reason="User not found")
        return
    _open_session(username, "cifrasletras")
    await cifras_letras_manager.connect(username, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            # Only hosts (dvd/nebulosa) control the game; everyone can submit
            if username in SUPERADMINS:
                try:
                    await cifras_letras_manager.handle_action(data)
                except Exception as e:
                    logger.error("CifrasLetras action error: %s", e)
            elif data.get("action") == "submit":
                data["username"] = username
                try:
                    await cifras_letras_manager.handle_action(data)
                except Exception as e:
                    logger.error("CifrasLetras submit error: %s", e)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error("CifrasLetras WS error: %s", e)
    finally:
        cifras_letras_manager.disconnect(username)
 
 
# =============================================================================
# PASAPALABRA GAME MODULE v5
# =============================================================================
import json as _json
import random
 
 
 
 
# =============================================================================
# GALLERY
# =============================================================================
 
@app.get("/api/gallery")
async def gallery_images():
    """
    Return a sorted list of image files found in static/gallery/.
    No config file or index.json needed — reads the directory directly.
    Response: [{file: "1.jpg", url: "/static/gallery/1.jpg"}, ...]
    """
    os.makedirs(GALLERY_DIR, exist_ok=True)  # create if not exists
    try:
        images = []
        for filename in sorted(os.listdir(GALLERY_DIR)):
            if os.path.splitext(filename.lower())[1] in GALLERY_EXTENSIONS:
                images.append({
                    "file": filename,
                    "url":  f"/static/gallery/{filename}"
                })
 
        # Write a reference manifest alongside the images.
        # NOTE: The frontend NEVER reads this file — it always calls /api/gallery.
        # This manifest is for backup/reference purposes only.
        try:
            import json as _json
            manifest_path = os.path.join(GALLERY_DIR, "gallery_manifest.json")
            with open(manifest_path, "w", encoding="utf-8") as f:
                _json.dump(images, f, indent=2, ensure_ascii=False)
        except Exception:
            pass  # Non-critical: never fails the request
 
        return images
    except Exception as e:
        logger.error("Gallery read error: %s", e)
        return []
 
 
PASAPALABRA_DIR = os.path.join(BASE_DIR, "static", "pasapalabra")
DEFAULT_ROSCO_T = 500
 
 
LETTERS_26 = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
 
 
def load_question_pool() -> dict:
    """Load preguntas.json from static/pasapalabra/. Supports list or dict format."""
    path = os.path.join(PASAPALABRA_DIR, "preguntas.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = _json.load(f)
        if isinstance(data, list):
            pool: dict = {}
            for q in data:
                letra = q.get("letra", "").upper()
                if letra:
                    pool.setdefault(letra, []).append(q)
            return pool
        return {k.upper(): v for k, v in data.items()}
    except FileNotFoundError:
        logger.warning("preguntas.json not found at %s — using empty pool", path)
        return {}
    except Exception as e:
        logger.error("Failed to load preguntas.json: %s", e)
        return {}
 
 
def assign_questions_for_players(pool: dict, n: int) -> list:
    """Return n dicts mapping letter → question for each player."""
    per = [{} for _ in range(n)]
    for letter in LETTERS_26:
        opts = list(pool.get(letter, []))
        if not opts:
            # No question for this letter — use placeholder
            placeholder = {"letra": letter, "definicion": f"[sin pregunta para {letter}]",
                           "respuesta": letter, "tipo": "directa"}
            for p in per:
                p[letter] = placeholder
            continue
        random.shuffle(opts)
        for i in range(n):
            per[i][letter] = opts[i % len(opts)]
    return per
 
 
class PasapalabraManager:
    def __init__(self):
        self.enabled: bool      = False
        self.connections: dict  = {}
        self._state: dict       = self._empty_state()
        self._timer_task        = None
 
    # ── State ─────────────────────────────────────────────────────────────────
 
    def _empty_state(self) -> dict:
        return {
            "status": "waiting",
            "players": [],
            "current_player_idx": -1,
            "setup": {"rosco_time": DEFAULT_ROSCO_T},
            # celebration: None | {type:"mid"|"final", winners:[username,...]}
            "celebration": None,
            # last_action: sent once per action so all clients react identically
            "last_action": None,
            "_action_seq": 0,
            # player_submission: text typed by the current player (visible to admin)
            "player_submission": "",
        }
 
    def _make_player(self, username: str, rosco_time: int, questions: dict) -> dict:
        return {
            "username":           username,
            "letters":            {L: "pending" for L in LETTERS_26},
            "questions":          questions,
            "score":              0,
            "time_remaining":     rosco_time,
            "current_letter":     "A",
            "current_letter_idx": 0,
            "done":               False,
            "turn_active":        False,
        }
 
    def _current_player(self):
        idx     = self._state.get("current_player_idx", -1)
        players = self._state.get("players", [])
        return players[idx] if 0 <= idx < len(players) else None
 
    def _find_next_letter_idx(self, player: dict, from_idx: int):
        n = len(LETTERS_26)
        for i in range(1, n + 1):
            idx = (from_idx + i) % n
            if player["letters"][LETTERS_26[idx]] in ("pending", "passed"):
                return idx
        return None
 
    def _find_next_player_idx(self) -> int:
        players = self._state["players"]
        n       = len(players)
        cur     = self._state.get("current_player_idx", -1)
        for i in range(1, n + 1):
            idx = (cur + i) % n
            if not players[idx]["done"]:
                return idx
        return -1
 
    def _compute_final_winners(self) -> list:
        """Return list of usernames with the highest score (1 or more if tied)."""
        players = self._state["players"]
        if not players:
            return []
        top = max(p["score"] for p in players)
        return [p["username"] for p in players if p["score"] == top]
 
    def _strip(self, p: dict) -> dict:
        return {k: v for k, v in p.items() if k != "questions"}
 
    def _current_question_for_broadcast(self):
        p = self._current_player()
        if not p or p["done"]:
            return None
        return p["questions"].get(p["current_letter"])
 
    def _build_broadcast(self) -> dict:
        return {
            "type":               "state",
            "enabled":            self.enabled,
            "status":             self._state["status"],
            "players":            [self._strip(p) for p in self._state["players"]],
            "current_player_idx": self._state.get("current_player_idx", -1),
            "current_question":   self._current_question_for_broadcast(),
            "setup":              self._state.get("setup", {}),
            "connected":          list(self.connections.keys()),
            "celebration":        self._state.get("celebration"),
            "last_action":        self._state.get("last_action"),
            # Player's typed answer — visible to all (admin uses it to validate)
            "player_submission":  self._state.get("player_submission", ""),
        }
 
    async def broadcast_action(self):
        """Send last_action as a dedicated 'action' message before the state update.
        This guarantees clients process sound/panel separately from state rendering."""
        la = self._state.get("last_action")
        if not la:
            return
        msg = {"type": "action", **la}
        dead = []
        for uname, sock in list(self.connections.items()):
            try:
                await sock.send_json(msg)
            except Exception:
                dead.append(uname)
        for u in dead:
            self.connections.pop(u, None)
 
    # ── WebSocket ─────────────────────────────────────────────────────────────
 
    async def connect(self, username: str, ws: WebSocket):
        await ws.accept()
        self.connections[username] = ws
        try:
            await ws.send_json(self._build_broadcast())
        except Exception:
            pass
 
    def disconnect(self, username: str):
        self.connections.pop(username, None)
 
    async def broadcast(self):
        data = self._build_broadcast()
        dead = []
        for uname, sock in list(self.connections.items()):
            try:
                await sock.send_json(data)
            except Exception:
                dead.append(uname)
        for u in dead:
            self.connections.pop(u, None)
 
    # ── Timer ─────────────────────────────────────────────────────────────────
 
    def _stop_timer(self):
        if self._timer_task:
            self._timer_task.cancel()
            self._timer_task = None
 
    def _start_timer(self):
        self._stop_timer()
        player = self._current_player()
        if player and not player["done"]:
            player["turn_active"] = True
            self._timer_task = asyncio.create_task(self._run_timer())
 
    async def _run_timer(self):
        try:
            while True:
                await asyncio.sleep(1)
                player = self._current_player()
                if not player or not player.get("turn_active"):
                    break
                if player["time_remaining"] > 0:
                    player["time_remaining"] -= 1
                    await self.broadcast()
                    if player["time_remaining"] == 0:
                        await self._on_pass_or_wrong("wrong", timeout=True)
                        break
        except asyncio.CancelledError:
            pass
 
    # ── Core result logic ─────────────────────────────────────────────────────
 
    async def _on_correct(self):
        player = self._current_player()
        if not player or player["done"]:
            return
        cur_idx    = player["current_letter_idx"]
        cur_letter = LETTERS_26[cur_idx]
        player["letters"][cur_letter] = "correct"
        player["score"] += 1
        # Clear the player's typed submission when admin validates answer
        self._state["player_submission"] = ""
        self._state["_action_seq"] = self._state.get("_action_seq", 0) + 1
        self._state["last_action"] = {
            "result": "correct",
            "letter": cur_letter,
            "player": player["username"],
            "seq":    self._state["_action_seq"],
        }
 
        next_idx = self._find_next_letter_idx(player, cur_idx)
        if next_idx is None:
            # ── Rosco completo con 26/26 ── mid-game winner celebration
            player["done"]        = True
            player["turn_active"] = False
            self._stop_timer()
            self._state["celebration"] = {
                "type":    "mid",
                "winners": [player["username"]],
                "won":     player["score"] == 26,
            }
            await self.broadcast_action()   # send correct sound first
            await self._switch_player()   # also broadcasts
        else:
            player["current_letter_idx"] = next_idx
            player["current_letter"]     = LETTERS_26[next_idx]
            # clear any previous celebration when play resumes
            self._state["celebration"] = None
            await self.broadcast_action()   # send sound/panel trigger first
            await self.broadcast()
 
    async def _on_pass_or_wrong(self, result: str, timeout: bool = False):
        self._stop_timer()
        player = self._current_player()
        if not player or player["done"]:
            return
        cur_idx    = player["current_letter_idx"]
        cur_letter = LETTERS_26[cur_idx]
 
        # Grab question text and answer before marking the letter
        q_data    = player["questions"].get(cur_letter)
        q_text    = q_data.get("definicion", "") if q_data else ""
        q_answer  = q_data.get("respuesta", "")  if q_data else ""
 
        if result == "wrong":
            player["letters"][cur_letter] = "wrong"
        else:
            player["letters"][cur_letter] = "passed"
 
        # Clear the player's typed submission when admin marks result
        self._state["player_submission"] = ""
        player["turn_active"] = False
        self._state["_action_seq"] = self._state.get("_action_seq", 0) + 1
        self._state["last_action"] = {
            "result":   result,
            "letter":   cur_letter,
            "player":   player["username"],
            "answer":   q_answer,
            "question": q_text,
            "seq":      self._state["_action_seq"],
        }
 
        next_letter_idx = self._find_next_letter_idx(player, cur_idx)
        if next_letter_idx is None:
            player["done"] = True
        else:
            player["current_letter_idx"] = next_letter_idx
            player["current_letter"]     = LETTERS_26[next_letter_idx]
 
        if timeout and player["time_remaining"] <= 0:
            player["done"] = True
 
        # clear celebration when a normal result comes in
        self._state["celebration"] = None
        await self.broadcast_action()   # send sound/panel trigger first
        await self._switch_player()
 
    async def _switch_player(self):
        next_idx = self._find_next_player_idx()
        if next_idx == -1:
            # ── All done → final celebration before finished
            winners = self._compute_final_winners()
            self._state["celebration"] = {"type": "final", "winners": winners}
            self._state["status"] = "finished"
            await self.broadcast()
            return
        self._state["current_player_idx"] = next_idx
        self._state["status"]             = "ready"
        await self.broadcast()
 
    # ── Action dispatcher ─────────────────────────────────────────────────────
 
    async def handle_action(self, act: dict, admin: str):
        action = act.get("action")
 
        if action == "toggle_enabled":
            self.enabled = bool(act.get("enabled", False))
            if not self.enabled:
                self._stop_timer()
                self._state = self._empty_state()
            await self.broadcast()
 
        elif action == "setup":
            self._stop_timer()
            usernames = [str(u).strip() for u in act.get("players", []) if str(u).strip()][:15]
            if not usernames:
                return
            rosco_t = max(60, min(int(act.get("rosco_time", DEFAULT_ROSCO_T)), 1200))
            pool    = load_question_pool()
            q_per   = assign_questions_for_players(pool, len(usernames))
            self._state = self._empty_state()
            self._state["setup"]["rosco_time"] = rosco_t
            self._state["players"] = [
                self._make_player(usernames[i], rosco_t, q_per[i])
                for i in range(len(usernames))
            ]
            self._state["current_player_idx"] = 0
            self._state["status"]             = "ready"
            self.enabled = True          # auto-enable when admin starts a game
            await self.broadcast()
 
        elif action == "start_timer":
            player = self._current_player()
            if player and not player["done"] and self._state["status"] in ("ready", "paused"):
                self._state["status"]      = "playing"
                self._state["celebration"] = None   # clear any celebration on manual start
                await self.broadcast()
                self._start_timer()
 
        elif action == "correct":
            if self._state["status"] != "playing":
                return
            await self._on_correct()
 
        elif action in ("pass", "wrong"):
            if self._state["status"] not in ("playing", "paused"):
                return
            await self._on_pass_or_wrong(action)
 
        elif action == "pause":
            player = self._current_player()
            if player:
                player["turn_active"] = False
            self._stop_timer()
            self._state["status"] = "paused"
            await self.broadcast()
 
        elif action == "reset":
            self._stop_timer()
            self._state = self._empty_state()
            await self.broadcast()
 
        elif action == "player_answer":
            # Non-admin player submits a typed answer — admin can see it to validate.
            # Only accepted during active play from the current active player.
            if self._state["status"] != "playing":
                return
            text = str(act.get("text", "")).strip().upper()[:40]
            cur = self._current_player()
            if cur and cur["username"] == admin:
                self._state["player_submission"] = text
                await self.broadcast()
 
        elif action == "clear_submission":
            # Clear the typed submission display (called by admin after marking result).
            self._state["player_submission"] = ""
            await self.broadcast()
 
 
game_manager = PasapalabraManager()
 
 
# =============================================================================
# PASAPALABRA ROUTES
# =============================================================================
 
@app.get("/pasapalabra", response_class=HTMLResponse)
async def pasapalabra_page():
    """Serve the Pasapalabra game page."""
    return _serve_game_page(PASAPALABRA_DIR)
 
@app.get("/api/pasapalabra/status")
async def pasapalabra_status():
    """Return Pasapalabra enabled state."""
    return {"enabled": game_manager.enabled}
 
@app.get("/api/pasapalabra/users")
async def pasapalabra_users(user: str = Depends(get_current_user)):
    """Return eligible user list for Pasapalabra."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_connect()
    rows = conn.execute(
        "SELECT username FROM users "
        "WHERE password_hash NOT IN ('__UNSET__','__AUTO__') ORDER BY username ASC"
    ).fetchall()
    conn.close()
    return [r["username"] for r in rows]
 
class GameToggleRequest(BaseModel):
    enabled: bool
 
@app.post("/api/pasapalabra/toggle")
async def pasapalabra_toggle(body: GameToggleRequest, user: str = Depends(get_current_user)):
    """Enable or disable Pasapalabra."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    game_manager.enabled = body.enabled
    if not body.enabled:
        game_manager._stop_timer()
        game_manager._state = game_manager._empty_state()
    await game_manager.broadcast()
    logger.info("Pasapalabra %s by %s", "enabled" if body.enabled else "disabled", user)
    return {"enabled": game_manager.enabled}
 
 
class PasapalabraSetupRequest(BaseModel):
    players: list
    rosco_time: int = 500
 
 
@app.post("/api/pasapalabra/setup")
async def pasapalabra_setup(body: PasapalabraSetupRequest, user: str = Depends(get_current_user)):
    """Configure and start a Pasapalabra game from admin panel."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    players = [str(u).strip() for u in body.players if str(u).strip()]
    if not players:
        raise HTTPException(400, "At least one player required")
    rosco_time = max(60, min(1200, int(body.rosco_time)))
    await game_manager.handle_action({
        "action": "setup",
        "players": players,
        "rosco_time": rosco_time
    }, user)
    logger.info("Pasapalabra setup by %s: players=%s", user, players)
    return {"ok": True, "players": players, "rosco_time": rosco_time}
 
 
@app.post("/api/pasapalabra/reset")
async def pasapalabra_reset(user: str = Depends(get_current_user)):
    """Reset Pasapalabra game state."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    game_manager._stop_timer()
    game_manager._state = game_manager._empty_state()
    await game_manager.broadcast()
    return {"ok": True}
 
 
# ── DB Migration: dvdcoin.db → 5 separate DBs ─────────────────────────────────
 
@app.post("/api/admin/migrate-db")
async def migrate_db(user: str = Depends(get_current_user)):
    """Migrate data from legacy dvdcoin.db to the 5 new DB files. Run once."""
    if user not in SUPERADMINS:
        raise HTTPException(403, "Superadmins only")
    import sqlite3 as _sq
    legacy_path = os.path.join(BASE_DIR, "data", "dvdcoin.db")
    # Also check root level
    if not os.path.exists(legacy_path):
        legacy_path = os.path.join(BASE_DIR, "dvdcoin.db")
    if not os.path.exists(legacy_path):
        return {"ok": False, "message": "dvdcoin.db not found — nothing to migrate"}
 
    results = {}
    try:
        leg = _sq.connect(legacy_path)
        leg.row_factory = _sq.Row
 
        # Migrate users
        try:
            users = leg.execute("SELECT * FROM users").fetchall()
            c = db_connect()
            for u in users:
                ud = dict(u)
                c.execute(
                    "INSERT OR IGNORE INTO users(username,password_hash,balance,is_blocked,"
                    "failed_attempts,locked_until,created_at) VALUES(?,?,?,?,?,?,?)",
                    (ud.get("username"), ud.get("password_hash","__UNSET__"),
                     ud.get("balance",0), ud.get("is_blocked",0),
                     ud.get("failed_attempts",0), ud.get("locked_until"),
                     ud.get("created_at"))
                )
            c.commit(); c.close()
            results["users"] = len(users)
        except Exception as e:
            results["users_error"] = str(e)
 
        # Migrate transactions
        try:
            txs = leg.execute("SELECT * FROM transactions").fetchall()
            c = db_tx()
            for t in txs:
                td = dict(t)
                c.execute(
                    "INSERT OR IGNORE INTO transactions(id,from_user,to_user,amount,concept,created_at)"
                    " VALUES(?,?,?,?,?,?)",
                    (td.get("id"), td.get("from_user"), td.get("to_user"),
                     td.get("amount",0), td.get("concept",""), td.get("created_at"))
                )
            c.commit(); c.close()
            results["transactions"] = len(txs)
        except Exception as e:
            results["transactions_error"] = str(e)
 
        # Migrate sessions
        try:
            sess = leg.execute("SELECT * FROM sessions").fetchall()
            c = db_stats()
            for s in sess:
                sd = dict(s)
                c.execute(
                    "INSERT OR IGNORE INTO sessions(id,username,section,detail,started_at,ended_at,duration_s)"
                    " VALUES(?,?,?,?,?,?,?)",
                    (sd.get("id"), sd.get("username"), sd.get("section","bank"),
                     sd.get("detail",""), sd.get("started_at"),
                     sd.get("ended_at"), sd.get("duration_s"))
                )
            c.commit(); c.close()
            results["sessions"] = len(sess)
        except Exception as e:
            results["sessions_error"] = str(e)
 
        # Migrate opo_players
        try:
            ops = leg.execute("SELECT * FROM opo_players").fetchall()
            c = db_rights()
            for op in ops:
                opd = dict(op)
                c.execute(
                    "INSERT OR IGNORE INTO opo_players(username,added_by,added_at) VALUES(?,?,?)",
                    (opd.get("username"), opd.get("added_by","dvd"), opd.get("added_at"))
                )
            c.commit(); c.close()
            results["opo_players"] = len(ops)
        except Exception as e:
            results["opo_players_error"] = str(e)
 
        # Migrate opo_results
        try:
            ors = leg.execute("SELECT * FROM opo_results").fetchall()
            c = db_opo()
            for o in ors:
                od = dict(o)
                c.execute(
                    "INSERT OR IGNORE INTO opo_results(id,username,block_n,played_at,correct,wrong,wrong_qs)"
                    " VALUES(?,?,?,?,?,?,?)",
                    (od.get("id"), od.get("username"), od.get("block_n",1),
                     od.get("played_at"), od.get("correct",0), od.get("wrong",0),
                     od.get("wrong_qs","[]"))
                )
            c.commit(); c.close()
            results["opo_results"] = len(ors)
        except Exception as e:
            results["opo_results_error"] = str(e)
 
        leg.close()
        results["ok"] = True
        results["message"] = "Migration complete. Check results and delete dvdcoin.db when ready."
        return results
 
    except Exception as e:
        return {"ok": False, "error": str(e)}
 
@app.websocket("/ws/pasapalabra")
async def pasapalabra_ws(websocket: WebSocket, token: str = ""):
    """WebSocket handler for Pasapalabra game.
    Admins control game flow; any connected player can send player_answer.
    """
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Authentication required")
        return
    conn = db_connect()
    row  = conn.execute("SELECT username FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        await websocket.close(code=4001, reason="User not found")
        return
    _open_session(username, "pasapalabra")
    await game_manager.connect(username, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            action = data.get("action", "")
            if username in ADMINS:
                # Admins control everything
                try:
                    await game_manager.handle_action(data, username)
                except Exception as e:
                    logger.error("Pasapalabra handle_action error: %s", e)
            elif action == "player_answer":
                # Players can only submit their typed answer
                try:
                    await game_manager.handle_action(data, username)
                except Exception as e:
                    logger.error("Pasapalabra player_answer error: %s", e)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error("Pasapalabra WS error: %s", e)
    finally:
        game_manager.disconnect(username)
 
 
 
# =============================================================================
# MILLONARIO
# =============================================================================
 
import json as _json_m
import random as _random_m
 
MILLONARIO_DIR = os.path.join(BASE_DIR, "static", "millonario")
QUIEN_SOY_DIR  = os.path.join(BASE_DIR, "static", "quiensoy")
 
PREMIOS = [
    "100 €","200 €","300 €","500 €","1.000 €",
    "2.000 €","4.000 €","8.000 €","16.000 €","32.000 €",
    "64.000 €","125.000 €","250.000 €","500.000 €","1.000.000 €"
]
GARANTIZADOS = {5: "1.000 €", 10: "32.000 €"}
 
 
def _load_millonario_questions():
    path = os.path.join(MILLONARIO_DIR, "preguntas.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return _json_m.load(f)
    except Exception as e:
        logger.error("Failed to load millonario preguntas.json: %s", e)
        return {}
 
 
def _build_game_questions():
    bank = _load_millonario_questions()
    result = []
    for lvl in range(1, 16):
        pool = bank.get(str(lvl), [])
        if pool:
            q = _random_m.choice(pool)
            result.append({
                "nivel":    lvl,
                "premio":   PREMIOS[lvl - 1],
                "pregunta": q["p"],
                "opciones": {"A": q["A"], "B": q["B"], "C": q["C"], "D": q["D"]},
                "respuesta": q["r"],
            })
        else:
            result.append(None)
    return result
 
 
class MillonarioManager:
    def __init__(self):
        self.enabled:     bool = False
        self.connections: dict = {}
        self._state:      dict = self._empty_state()
 
    def _empty_state(self):
        return {
            "status":          "waiting",
            "player":          None,
            "nivel":           0,
            "preguntas":       [],
            "comodin_50":      False,
            "eliminadas":      [],
            "ultimo_premio":   None,
            "selected_option": "",      # letter currently marked by dvd (broadcast to all)
            "reveal_result":   None,    # "correct" | "wrong" | None
        }
 
    def _current_q(self):
        idx = self._state["nivel"] - 1
        qs  = self._state.get("preguntas", [])
        return qs[idx] if 0 <= idx < len(qs) else None
 
    def _build_broadcast(self):
        q   = self._current_q()
        q_pub = None
        if q:
            q_pub = {
                "nivel":       q["nivel"],
                "premio":      q["premio"],
                "pregunta":    q["pregunta"],
                "opciones":    {k: v for k, v in q["opciones"].items()
                                if k not in self._state["eliminadas"]},
                "opciones_all": q["opciones"],
                "respuesta":   q["respuesta"],   # client hides for non-dvd
            }
        return {
            "type":            "state",
            "enabled":         self.enabled,
            "status":          self._state["status"],
            "player":          self._state["player"],
            "nivel":           self._state["nivel"],
            "comodin_50":      self._state["comodin_50"],
            "eliminadas":      self._state["eliminadas"],
            "ultimo_premio":   self._state["ultimo_premio"],
            "premios":         PREMIOS,
            "garantizados":    [5, 10],
            "pregunta":        q_pub,
            "selected_option": self._state.get("selected_option", ""),
            "reveal_result":   self._state.get("reveal_result"),
        }
 
    async def connect(self, username: str, ws: WebSocket):
        await ws.accept()
        self.connections[username] = ws
        try:
            await ws.send_json(self._build_broadcast())
        except Exception:
            pass
 
    def disconnect(self, username: str):
        self.connections.pop(username, None)
 
    async def broadcast(self):
        data = self._build_broadcast()
        dead = []
        for u, sock in list(self.connections.items()):
            try:
                await sock.send_json(data)
            except Exception:
                dead.append(u)
        for u in dead:
            self.connections.pop(u, None)
 
    async def handle_action(self, act: dict):
        action = act.get("action")
 
        if action == "setup":
            player = str(act.get("player", "")).strip()
            if not player:
                return
            self._state              = self._empty_state()
            self._state["player"]    = player
            self._state["nivel"]     = 1
            self._state["status"]    = "playing"
            self._state["preguntas"] = _build_game_questions()
            await self.broadcast()
 
        elif action == "correct":
            if self._state["status"] != "playing":
                return
            nivel = self._state["nivel"]
            if nivel in GARANTIZADOS:
                self._state["ultimo_premio"] = GARANTIZADOS[nivel]
            # Revealing phase: keep selected_option so clients see the marked letter
            self._state["reveal_result"] = "correct"
            self._state["status"]        = "revealing"
            # selected_option stays as-is during reveal
            await self.broadcast()
            await asyncio.sleep(0.15)
            if nivel == 15:
                self._state["status"]        = "finished"
                self._state["ultimo_premio"] = "1.000.000 €"
            else:
                self._state["nivel"]      = nivel + 1
                self._state["eliminadas"] = []
                self._state["status"]     = "playing"
            self._state["selected_option"] = ""   # clear AFTER reveal
            self._state["reveal_result"]   = None
            await self.broadcast()
 
        elif action == "wrong":
            if self._state["status"] != "playing":
                return
            # Revealing phase: keep selected_option so clients see the marked letter
            self._state["reveal_result"] = "wrong"
            self._state["status"]        = "revealing"
            # selected_option stays as-is during reveal
            await self.broadcast()
            await asyncio.sleep(0.15)
            self._state["status"]          = "wrong"
            self._state["selected_option"] = ""   # clear AFTER reveal
            self._state["reveal_result"]   = None
            await self.broadcast()
 
        elif action == "comodin_50":
            if self._state["comodin_50"] or self._state["status"] != "playing":
                return
            q = self._current_q()
            if not q:
                return
            correcta    = q["respuesta"]
            incorrectas = [k for k in ["A", "B", "C", "D"]
                           if k != correcta and k not in self._state["eliminadas"]]
            _random_m.shuffle(incorrectas)
            self._state["eliminadas"]  = incorrectas[:2]
            self._state["comodin_50"]  = True
            await self.broadcast()
 
        elif action == "select_option":
            # dvd marks a letter — broadcast to all so everyone sees it highlighted
            letter = act.get("letter", "")
            self._state["selected_option"] = letter if letter in ("A","B","C","D") else ""
            await self.broadcast()
 
        elif action == "reset":
            self._state = self._empty_state()
            await self.broadcast()
 
 
 
millonario_manager = MillonarioManager()
 
 
# ── Routes ────────────────────────────────────────────────
 
@app.get("/millonario", response_class=HTMLResponse)
async def millonario_page():
    """Serve the Millonario game page."""
    return _serve_game_page(MILLONARIO_DIR)
 
 
@app.get("/api/millonario/status")
async def millonario_status():
    """Return Millonario enabled state."""
    return {"enabled": millonario_manager.enabled}
 
 
@app.get("/api/millonario/users")
async def millonario_users(user: str = Depends(get_current_user)):
    """Return eligible user list for Millonario."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    conn = db_connect()
    rows = conn.execute(
        "SELECT username FROM users ORDER BY username ASC"
    ).fetchall()
    conn.close()
    return [r["username"] for r in rows]
 
 
class MillonarioToggleRequest(BaseModel):
    enabled: bool
 
 
@app.post("/api/millonario/toggle")
async def millonario_toggle(
    body: MillonarioToggleRequest,
    user: str = Depends(get_current_user)
):
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    millonario_manager.enabled = body.enabled
    if not body.enabled:
        millonario_manager._state = millonario_manager._empty_state()
    await millonario_manager.broadcast()
    return {"enabled": millonario_manager.enabled}
 
 
class MillonarioSetupRequest(BaseModel):
    player: str
 
 
@app.post("/api/millonario/setup")
async def millonario_setup(body: MillonarioSetupRequest, user: str = Depends(get_current_user)):
    """Configure and start a Millonario game from admin panel."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    player = body.player.strip()
    if not player:
        raise HTTPException(400, "Player required")
    millonario_manager.enabled = True
    await millonario_manager.handle_action({"action": "setup", "player": player})
    logger.info("Millonario setup by %s: player=%s", user, player)
    return {"ok": True, "player": player}
 
 
@app.post("/api/millonario/reset")
async def millonario_reset(user: str = Depends(get_current_user)):
    """Reset Millonario game state."""
    if user not in ADMINS:
        raise HTTPException(403, "Admins only")
    millonario_manager._state = millonario_manager._empty_state()
    await millonario_manager.broadcast()
    return {"ok": True}
 
 
@app.websocket("/ws/millonario")
async def millonario_ws(websocket: WebSocket, token: str = ""):
    """WebSocket handler for Millonario game."""
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Authentication required")
        return
    conn = db_connect()
    row  = conn.execute(
        "SELECT username FROM users WHERE username=?", (username,)
    ).fetchone()
    conn.close()
    if not row:
        await websocket.close(code=4001, reason="User not found")
        return
    _open_session(username, "millonario")
    await millonario_manager.connect(username, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            if username in ADMINS:
                await millonario_manager.handle_action(data)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        millonario_manager.disconnect(username)
 
 
 
 
 
 
# =============================================================================
# OPO GAME MODULE — Simulacro de oposición tipo test
# Un jugador activo juega solo (puede ser dvd u otro usuario).
# Selecciona respuesta → se revela → 3s → siguiente pregunta.
# dvd controla: iniciar, resetear. Todos ven el marcador en tiempo real.
# =============================================================================
import json    as _json_opo
import asyncio as _aio_opo
 
 
 
 
# =============================================================================
# OPO QUIZ
# =============================================================================
 
OPO_DIR = os.path.join(BASE_DIR, "static", "opo")
 
 
def _load_opo_questions() -> list:
    path = os.path.join(OPO_DIR, "preguntas_opo_nebulosa.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return _json_opo.load(f)
    except Exception as e:
        logger.error("OPO load error: %s", e)
        return []
 
class OpoManager:
    def __init__(self):
        self.enabled:     bool = False
        self.connections: dict = {}        # username → websocket
        self._questions:  list = []
        self._state:      dict = self._empty_state()
        self._auto_task         = None
 
    # ── State ─────────────────────────────────────────────────────────────────
 
    def _empty_state(self) -> dict:
        return {
            "phase":          "waiting",   # waiting|block_select|question|reveal|block_end|finished
            "active_player":  None,        # username of the player answering
            "block_index":    0,
            "q_index":        0,
            "total_blocks":   0,
            "total_qs":       0,
            "current_q":      None,        # {n,p,A,B,C,D} — no answer key
            "player_answer":  None,        # letter chosen by active_player
            "correct":        None,        # correct letter (set after reveal)
            "reveal_delay":   0,           # seconds to show reveal (3=correct, 5=wrong)
            "block_scores":   {},          # username → {correct,wrong}
            "all_scores":     {},          # username → {correct,wrong} cumul.
            "block_result":   None,        # last block summary
            "countdown":      0,           # seconds remaining before auto-next
        }
 
    def _q(self) -> dict | None:
        """Current question without the answer key."""
        bi  = self._state["block_index"]
        qi  = self._state["q_index"]
        qs  = self._questions[bi * 10: (bi + 1) * 10]
        if qi >= len(qs):
            return None
        q = qs[qi]
        return {"n": q["n"], "p": q["p"],
                "A": q["A"], "B": q["B"], "C": q["C"], "D": q["D"]}
 
    def _correct_letter(self) -> str:
        bi = self._state["block_index"]
        qi = self._state["q_index"]
        qs = self._questions[bi * 10: (bi + 1) * 10]
        return qs[qi]["r"] if qi < len(qs) else ""
 
    def _ensure_score(self, u: str):
        for d in (self._state["block_scores"], self._state["all_scores"]):
            if u not in d:
                d[u] = {"correct": 0, "wrong": 0}
 
    # ── Broadcast ─────────────────────────────────────────────────────────────
 
    def _payload(self) -> dict:
        s = self._state
        return {
            "type":          "state",
            "enabled":       self.enabled,
            "phase":         s["phase"],
            "active_player": s["active_player"],
            "block_index":   s["block_index"],
            "q_index":       s["q_index"],
            "total_blocks":  s["total_blocks"],
            "total_qs":      s["total_qs"],
            "current_q":     s["current_q"],
            "player_answer": s["player_answer"],
            "correct":       s["correct"],
            "reveal_delay":  s["reveal_delay"],
            "block_scores":  s["block_scores"],
            "all_scores":    s["all_scores"],
            "block_result":  s["block_result"],
            "countdown":     s["countdown"],
            "connected":     list(self.connections.keys()),
            "wrong_qs_block": s.get("wrong_qs_this_block", []),
        }
 
    async def broadcast(self):
        msg  = self._payload()
        dead = []
        for u, ws in list(self.connections.items()):
            try:
                await ws.send_json(msg)
            except Exception:
                dead.append(u)
        for u in dead:
            self.connections.pop(u, None)
 
    async def connect(self, username: str, ws: WebSocket):
        await ws.accept()
        self.connections[username] = ws
        await self.broadcast()
 
    def disconnect(self, username: str):
        self.connections.pop(username, None)
 
    # ── Auto countdown ─────────────────────────────────────────────────────────
 
    def _cancel(self):
        if self._auto_task and not self._auto_task.done():
            self._auto_task.cancel()
        self._auto_task = None
 
    async def _countdown_then(self, seconds: int, fn):
        try:
            for t in range(seconds, 0, -1):
                self._state["countdown"] = t
                await self.broadcast()
                await _aio_opo.sleep(1)
            self._state["countdown"] = 0
            await fn()
        except _aio_opo.CancelledError:
            pass
 
    # ── Game flow ──────────────────────────────────────────────────────────────
 
    async def _do_reveal(self):
        """Score the answer, broadcast reveal. Waits for manual 'next' action."""
        s = self._state
        if s["phase"] != "question":
            return
        correct = self._correct_letter()
        s["correct"]  = correct
        s["phase"]    = "reveal"
        s["countdown"] = 0
        player        = s["active_player"]
        # Score the active player
        if player:
            self._ensure_score(player)
            if s["player_answer"] == correct:
                s["block_scores"][player]["correct"] += 1
                s["all_scores"][player]["correct"]   += 1
            else:
                s["block_scores"][player]["wrong"]   += 1
                s["all_scores"][player]["wrong"]     += 1
                # Track wrong question for review
                if "wrong_qs_this_block" not in s:
                    s["wrong_qs_this_block"] = []
                q = s.get("current_q", {})
                if q:
                    s["wrong_qs_this_block"].append({
                        "n": q.get("n"), "p": q.get("p"),
                        "A": q.get("A"), "B": q.get("B"),
                        "C": q.get("C"), "D": q.get("D"),
                        "r": self._correct_letter(),
                        "given": s["player_answer"]
                    })
        # Set reveal delay: 3s for correct, 5s for wrong
        was_correct = (s["player_answer"] == correct)
        s["reveal_delay"] = 3 if was_correct else 5
        self._cancel()
        await self.broadcast()
        # Auto-advance after reveal_delay seconds
        self._auto_task = _aio_opo.create_task(
            _aio_opo.sleep(s["reveal_delay"])
        )
        async def _auto_next():
            await _aio_opo.sleep(s["reveal_delay"])
            await self._do_next()
        self._auto_task = _aio_opo.create_task(_auto_next())
 
    async def _do_next(self):
        """Advance to next question or end of block."""
        s     = self._state
        bi    = s["block_index"]
        qi    = s["q_index"] + 1
        block = self._questions[bi * 10: (bi + 1) * 10]
        s["player_answer"] = None
        s["correct"]       = None
        s["countdown"]     = 0
        if qi < len(block):
            s["q_index"]   = qi
            s["phase"]     = "question"
            s["current_q"] = self._q()
            await self.broadcast()
        else:
            # End of block — wait for manual advance
            s["phase"]        = "block_end"
            s["countdown"]    = 0
            s["block_result"] = {
                "block":  bi + 1,
                "scores": {k: dict(v) for k, v in s["block_scores"].items()},
            }
            s["current_q"] = None
            self._cancel()
            await self.broadcast()
            # Auto-advance to next block after 3s
            async def _auto_block():
                await _aio_opo.sleep(3)
                await self._do_next_block()
            self._auto_task = _aio_opo.create_task(_auto_block())
 
    async def _do_next_block(self):
        """Called after block_end auto-timer — go to block_select so nebulosa picks next."""
        s = self._state
        s["countdown"] = 0
        next_bi = s["block_index"] + 1
        if next_bi >= s["total_blocks"]:
            s["phase"]     = "finished"
            s["current_q"] = None
            await self.broadcast()
        else:
            # Save block result to DB
            try:
                import json as _jres
                player_u = s.get("active_player", "nebulosa")
                bs = s["block_scores"].get(player_u, {})
                wqs_list = s.get("wrong_qs_this_block", [])
                _conn = db_opo()
                _conn.execute(
                    "INSERT INTO opo_results(username,block_n,correct,wrong,wrong_qs) VALUES(?,?,?,?,?)",
                    (player_u, bi+1, bs.get("correct",0), bs.get("wrong",0),
                     _jres.dumps(wqs_list, ensure_ascii=False))
                )
                _conn.commit()
                _conn.close()
            except Exception as _e:
                logger.error("OPO result save error: %s", _e)
            # Go to block_select: nebulosa chooses which block to do next
            s["phase"]        = "block_select"
            s["current_q"]    = None
            s["block_result"] = None
            await self.broadcast()
 
    # ── Action handler ─────────────────────────────────────────────────────────
 
    async def handle_action(self, act: dict, username: str):
        s      = self._state
        action = act.get("action", "")
 
        # ── start ──────────────────────────────────────────────────────────────
        if action == "start":
            if username not in OPO_USERS:
                return
            self._cancel()
            qs = _load_opo_questions()
            if not qs:
                return
            self._questions = qs
            n = len(qs)
            # Active player is the user who starts their own game
            player = username
            total_blocks = (n + 9) // 10
            # block param: 0-based block index, default 0
            start_block = int(act.get("block", 0))
            start_block = max(0, min(start_block, total_blocks - 1))
            self._state = self._empty_state()
            s = self._state
            s["phase"]        = "question"
            s["active_player"]= player
            s["total_blocks"] = total_blocks
            s["total_qs"]     = n
            s["block_index"]  = start_block
            s["current_q"]    = self._q()
            self._ensure_score(player)
            await self.broadcast()
 
        # ── answer ─────────────────────────────────────────────────────────────
        elif action == "answer":
            if s["phase"] != "question":
                return
            if username not in OPO_USERS:  # only OPO players answer
                return
            if s["player_answer"] is not None:
                return
            letter = act.get("letter", "").upper()
            if letter not in ("A", "B", "C", "D"):
                return
            s["player_answer"] = letter
            await self.broadcast()
            # Auto-reveal immediately
            await self._do_reveal()
 
        # ── force_reveal (dvd only, in case player is stuck) ───────────────────
        elif action == "force_reveal":
            if username not in OPO_USERS or s["phase"] != "question":
                return
            await self._do_reveal()
 
        # ── skip (dvd can skip countdown) ──────────────────────────────────────
        elif action == "select_block":
            # Any OPO player selects which block to play next
            if username not in OPO_USERS:
                return
            if s["phase"] not in ("waiting", "block_select"):
                return
            block_i = int(act.get("block", 0))
            block_i = max(0, min(block_i, s["total_blocks"] - 1))
            s["block_index"]  = block_i
            s["q_index"]      = 0
            s["phase"]        = "question"
            s["player_answer"]= None
            s["correct"]      = None
            s["current_q"]    = self._q()
            s["block_result"] = None
            s["wrong_qs_this_block"] = []
            # Reset block scores only
            s["block_scores"] = {u: {"correct": 0, "wrong": 0}
                                 for u in s["all_scores"]}
            self._ensure_score("nebulosa")
            await self.broadcast()
 
        elif action == "next":
            # Active player advances after seeing the answer
            if username not in OPO_USERS:
                return
            if s["phase"] == "reveal":
                await self._do_next()
 
        elif action == "next_block":
            # Advance to next block after block_end screen
            if username not in OPO_USERS:
                return
            if s["phase"] == "block_end":
                await self._do_next_block()
 
        elif action == "skip":
            if username not in OPO_USERS:
                return
            self._cancel()
            if s["phase"] == "reveal":
                await self._do_next()
            elif s["phase"] == "block_end":
                await self._do_next_block()
 
        # ── reset ──────────────────────────────────────────────────────────────
        elif action == "reset":
            if username not in OPO_USERS:
                return
            self._cancel()
            self._state = self._empty_state()
            await self.broadcast()
 
 
# ── OPO users and managers ────────────────────────────────────────────────────
 
def _load_opo_users() -> set:
    try:
        c = db_rights()
        rows = c.execute("SELECT username FROM opo_players").fetchall()
        c.close()
        return {"dvd", "nebulosa"} | {r["username"] for r in rows}
    except Exception:
        return {"dvd", "nebulosa"}
 
OPO_USERS: set = {"dvd", "nebulosa"}  # refreshed at startup
 
# ── In-memory video room registry — definido una sola vez arriba ──────────────
# _ROOMS y _room_public_list ya están definidos al inicio del archivo

_opo_managers: dict = {}
 
def get_opo_manager(username: str) -> "OpoManager":
    if username not in _opo_managers:
        _opo_managers[username] = OpoManager()
    return _opo_managers[username]
 
# ── OPO routes ─────────────────────────────────────────────────────────────────
 
@app.get("/opo", response_class=HTMLResponse)
async def opo_page():
    """Serve the OPO game page."""
    return _serve_game_page(os.path.join(BASE_DIR, "static", "opo"))
 
@app.get("/api/opo/status")
async def opo_status(user: str = Depends(get_current_user)):
    """Return OPO status and access for the current user."""
    mgr = get_opo_manager(user)
    return {"enabled": mgr.enabled, "username": user, "is_opo_user": user in OPO_USERS}
 
@app.post("/api/opo/toggle")
async def opo_toggle(user: str = Depends(get_current_user)):
    """Enable or disable OPO."""
    if user not in SUPERADMINS: raise HTTPException(403)
    mgr = get_opo_manager(user)
    mgr.enabled = not mgr.enabled
    return {"enabled": mgr.enabled}
 
@app.get("/api/opo/players")
async def opo_players_list(user: str = Depends(get_current_user)):
    """Return the list of OPO players."""
    if user not in OPO_USERS: raise HTTPException(403)
    cr = db_rights()
    player_rows = cr.execute("SELECT username, added_at FROM opo_players ORDER BY username").fetchall()
    cr.close()
    cs = db_stats()
    co = db_opo()
    result = []
    for pr in player_rows:
        u = pr["username"]
        lc = cs.execute("SELECT MAX(started_at) FROM sessions WHERE username=? AND section='opo'", (u,)).fetchone()[0]
        ls = cs.execute("SELECT duration_s FROM sessions WHERE username=? AND section='opo' ORDER BY started_at DESC LIMIT 1", (u,)).fetchone()
        ts = cs.execute("SELECT COALESCE(SUM(duration_s),0) FROM sessions WHERE username=? AND section='opo'", (u,)).fetchone()[0]
        td = co.execute("SELECT COUNT(*) FROM opo_results WHERE username=?", (u,)).fetchone()[0]
        result.append({"username": u, "added_at": pr["added_at"], "last_conn": lc,
                       "last_session_s": (ls[0] if ls else 0) or 0, "total_s": ts or 0, "tests_done": td or 0})
    cs.close(); co.close()
    for u in sorted({"dvd","nebulosa"} - {r["username"] for r in result}):
        cs2 = db_stats(); co2 = db_opo()
        lc2 = cs2.execute("SELECT MAX(started_at) FROM sessions WHERE username=? AND section='opo'", (u,)).fetchone()[0]
        ts2 = cs2.execute("SELECT COALESCE(SUM(duration_s),0) FROM sessions WHERE username=? AND section='opo'", (u,)).fetchone()[0]
        td2 = co2.execute("SELECT COUNT(*) FROM opo_results WHERE username=?", (u,)).fetchone()[0]
        cs2.close(); co2.close()
        result.insert(0, {"username": u, "added_at": None, "last_conn": lc2,
                          "last_session_s": 0, "total_s": ts2 or 0, "tests_done": td2 or 0})
    return result
 
@app.post("/api/opo/players")
async def opo_player_add(body: OpoPlayerRequest, user: str = Depends(get_current_user)):
    """Add a user to OPO access list."""
    global OPO_USERS
    if user not in SUPERADMINS: raise HTTPException(403)
    uname = body.username.strip().lower()
    if not uname: raise HTTPException(400, "username required")
    conn = db_users()
    if not conn.execute("SELECT 1 FROM users WHERE username=?", (uname,)).fetchone():
        conn.close(); raise HTTPException(404, "Usuario no encontrado")
    conn.close()
    cr = db_rights()
    cr.execute("INSERT OR IGNORE INTO opo_players(username,added_by) VALUES(?,?)", (uname, user))
    cr.commit(); cr.close()
    OPO_USERS = _load_opo_users()
    return {"ok": True}
 
@app.delete("/api/opo/players/{username}")
async def opo_player_remove(username: str, user: str = Depends(get_current_user)):
    """Remove a user from OPO access list."""
    global OPO_USERS
    if user not in SUPERADMINS: raise HTTPException(403)
    if username in {"dvd","nebulosa"}: raise HTTPException(400, "Cannot remove dvd or nebulosa")
    cr = db_rights()
    cr.execute("DELETE FROM opo_players WHERE username=?", (username,))
    cr.commit(); cr.close()
    OPO_USERS = _load_opo_users()
    return {"ok": True}
 
@app.post("/api/opo/result")
async def opo_result_save(body: OpoResultRequest, user: str = Depends(get_current_user)):
    """Save an OPO test result."""
    if user not in OPO_USERS: raise HTTPException(403)
    import json as _jr
    conn = db_opo()
    conn.execute(
        "INSERT INTO opo_results(username,block_n,correct,wrong,wrong_qs) VALUES(?,?,?,?,?)",
        (user, body.block_n, body.correct, body.wrong, _jr.dumps(body.wrong_qs, ensure_ascii=False))
    )
    conn.commit(); conn.close()
    return {"ok": True}
 
@app.get("/api/opo/results")
async def opo_results_all(user: str = Depends(get_current_user), username:
    str = ""):
    if user not in OPO_USERS: raise HTTPException(403)
    import json as _jr
    conn = db_opo()
    if user in SUPERADMINS and username:
        rows = conn.execute(
            "SELECT id,username,block_n,played_at,correct,wrong,wrong_qs FROM opo_results "
            "WHERE username=? ORDER BY played_at DESC LIMIT 500", (username,)
        ).fetchall()
    elif user in SUPERADMINS:
        rows = conn.execute(
            "SELECT id,username,block_n,played_at,correct,wrong,wrong_qs FROM opo_results "
            "ORDER BY played_at DESC LIMIT 500"
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id,username,block_n,played_at,correct,wrong,wrong_qs FROM opo_results "
            "WHERE username=? ORDER BY played_at DESC LIMIT 200", (user,)
        ).fetchall()
    conn.close()
    result = []
    for r in rows:
        try: wqs = _jr.loads(r["wrong_qs"]) if r["wrong_qs"] else []
        except: wqs = []
        result.append({"id":r["id"],"username":r["username"],"block_n":r["block_n"],
                       "played_at":r["played_at"],"correct":r["correct"],"wrong":r["wrong"],"wrong_qs":wqs})
    return result
 
@app.get("/api/opo/stats")
async def opo_stats_endpoint(user: str = Depends(get_current_user)):
    """Return OPO session stats per user."""
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_stats()
    rows = conn.execute(
        "SELECT username, MAX(started_at) last_conn, SUM(duration_s) total_s, COUNT(*) sessions "
        "FROM sessions WHERE section='opo' GROUP BY username ORDER BY last_conn DESC"
    ).fetchall()
    conn.close()
    return [{"username":r["username"],"last_conn":r["last_conn"],"total_s":r["total_s"] or 0,"sessions":r["sessions"]} for r in rows]
 
# ── Cuentos sessions ──────────────────────────────────────────────────────────
 
@app.get("/api/cuentos/sessions")
async def cuentos_sessions(
    user: str = Depends(get_current_user),
    username: str = "", date_from: str = "", date_to: str = "",
    detail: str = "", limit: int = 500
):
    if user not in SUPERADMINS: raise HTTPException(403)
    conn = db_stats()
    q = "SELECT id,username,section,detail,started_at,ended_at,duration_s FROM sessions WHERE section='cuentos'"
    p = []
    if username:  q += " AND username LIKE ?"; p.append(f"%{username}%")
    if date_from: q += " AND started_at >= ?"; p.append(date_from)
    if date_to:   q += " AND started_at <= ?"; p.append(date_to+"T23:59:59")
    if detail:    q += " AND detail LIKE ?";   p.append(f"%{detail}%")
    q += f" ORDER BY started_at DESC LIMIT {min(limit,2000)}"
    rows = conn.execute(q, p).fetchall()
    conn.close()
    return [dict(r) for r in rows]
 
# ── OPO WebSocket ─────────────────────────────────────────────────────────────
 
@app.websocket("/ws/opo")
async def opo_ws(websocket: WebSocket, token: str = ""):
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Auth required"); return
    if username not in OPO_USERS:
        await websocket.close(code=4003, reason="OPO access denied"); return
    conn = db_users()
    row = conn.execute("SELECT is_blocked FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if row and row["is_blocked"]:
        await websocket.close(code=4001, reason="Blocked"); return
    _ping_session(username, "opo")
    mgr = get_opo_manager(username)
    await mgr.connect(username, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            await mgr.handle_action(data, username)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        mgr.disconnect(username)
 
 
# =============================================================================
# MESSAGING SYSTEM
# Supports group chat (room="group") and direct messages (room="dm:a:b").
# Audio messages are uploaded via REST, stored in static/audio/messages/.
# Real-time delivery via WebSocket /ws/messages.
# =============================================================================
 
import uuid as _uuid
import json  as _json_msg
 
# ── DB path ────────────────────────────────────────────────────────────────
DB_MSG      = os.path.join(DATA_DIR, "messages.db")
MSG_DIR     = os.path.join(BASE_DIR, "static", "audio", "messages")
MSG_ALLOWED = {".webm", ".mp4", ".ogg", ".m4a", ".aac", ".wav"}
MSG_MAX_ROWS = 2000  # max messages to keep per room
 
def db_msg() -> sqlite3.Connection:
    """Open the messages database."""
    return _open_db(DB_MSG)
 
 
def _msg_db_init():
    """Create messaging tables. Safe to call on every restart."""
    os.makedirs(MSG_DIR, exist_ok=True)
    c = db_msg()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS messages (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            room         TEXT    NOT NULL DEFAULT 'group',
            from_user    TEXT    NOT NULL,
            content      TEXT    NOT NULL DEFAULT '',
            msg_type     TEXT    NOT NULL DEFAULT 'text',
            reply_to_id  INTEGER,
            deleted      INTEGER NOT NULL DEFAULT 0,
            created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_msg_room ON messages(room, created_at);
        CREATE INDEX IF NOT EXISTS idx_msg_user ON messages(from_user);
 
        CREATE TABLE IF NOT EXISTS msg_reads (
            msg_id   INTEGER NOT NULL,
            username TEXT    NOT NULL,
            PRIMARY KEY (msg_id, username)
        );
 
        CREATE TABLE IF NOT EXISTS msg_reactions (
            msg_id   INTEGER NOT NULL,
            username TEXT    NOT NULL,
            emoji    TEXT    NOT NULL,
            PRIMARY KEY (msg_id, username)
        );
 
        CREATE TABLE IF NOT EXISTS msg_settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );
        INSERT OR IGNORE INTO msg_settings(key, value) VALUES('enabled', 'false');
    """)
    c.commit()
    # Migration: add new columns if missing
    for col_sql in [
        "ALTER TABLE messages ADD COLUMN reply_to_id INTEGER",
        "ALTER TABLE messages ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
        "CREATE TABLE IF NOT EXISTS msg_reactions (msg_id INTEGER NOT NULL, username TEXT NOT NULL, emoji TEXT NOT NULL, PRIMARY KEY (msg_id, username))",
    ]:
        try:
            c.execute(col_sql)
            c.commit()
        except Exception:
            pass
    c.close()
 
 
def _dm_room(a: str, b: str) -> str:
    """Return canonical DM room name for two users (alphabetically sorted)."""
    return "dm:" + ":".join(sorted([a.lower(), b.lower()]))
 
 
def _msg_enabled() -> bool:
    """Check if messaging is currently enabled."""
    try:
        c = db_msg()
        row = c.execute("SELECT value FROM msg_settings WHERE key='enabled'").fetchone()
        c.close()
        return row and row["value"] == "true"
    except Exception:
        return False
 
 
def _set_msg_enabled(val: bool):
    """Persist the messaging enabled flag."""
    c = db_msg()
    c.execute("INSERT OR REPLACE INTO msg_settings(key,value) VALUES('enabled',?)",
              ("true" if val else "false",))
    c.commit()
    c.close()
 
 
def _load_history(room: str, limit: int = 60, before_id: int = 0) -> list:
    """Return message history for a room, newest-last."""
    c = db_msg()
    if before_id:
        rows = c.execute(
            "SELECT id,room,from_user,content,msg_type,reply_to_id,deleted,created_at FROM messages "
            "WHERE room=? AND id<? ORDER BY id DESC LIMIT ?",
            (room, before_id, limit)
        ).fetchall()
    else:
        rows = c.execute(
            "SELECT id,room,from_user,content,msg_type,reply_to_id,deleted,created_at FROM messages "
            "WHERE room=? ORDER BY id DESC LIMIT ?",
            (room, limit)
        ).fetchall()
    msgs = [dict(r) for r in reversed(rows)]
    # Attach reactions
    if msgs:
        ids = [m["id"] for m in msgs]
        react_rows = c.execute(
            f"SELECT msg_id,username,emoji FROM msg_reactions WHERE msg_id IN ({','.join('?'*len(ids))})",
            ids
        ).fetchall()
        reactions_map = {}
        for r in react_rows:
            reactions_map.setdefault(r["msg_id"], []).append({"username": r["username"], "emoji": r["emoji"]})
        for m in msgs:
            m["reactions"] = reactions_map.get(m["id"], [])
    c.close()
    return msgs
 
 
def _save_message(room: str, from_user: str, content: str, msg_type: str = "text", reply_to_id: int = None) -> dict:
    """Persist a message and return its full dict."""
    c = db_msg()
    cur = c.execute(
        "INSERT INTO messages(room,from_user,content,msg_type,reply_to_id) VALUES(?,?,?,?,?)",
        (room, from_user, content, msg_type, reply_to_id)
    )
    row = c.execute(
        "SELECT id,room,from_user,content,msg_type,reply_to_id,created_at FROM messages WHERE id=?",
        (cur.lastrowid,)
    ).fetchone()
    # Prune old messages per room
    c.execute(
        "DELETE FROM messages WHERE room=? AND id NOT IN "
        "(SELECT id FROM messages WHERE room=? ORDER BY id DESC LIMIT ?)",
        (room, room, MSG_MAX_ROWS)
    )
    c.commit()
    c.close()
    return dict(row)
 
 
# ── Connection manager ─────────────────────────────────────────────────────
 
class MessageManager:
    """Manages all active WebSocket connections for the messaging system."""
 
    def __init__(self):
        self.connections: dict = {}   # username → WebSocket
 
    async def connect(self, username: str, ws: WebSocket):
        """Accept a new WebSocket connection and broadcast updated presence."""
        await ws.accept()
        self.connections[username] = ws
        await self.broadcast_status()
 
    def disconnect(self, username: str):
        """Remove a connection and broadcast updated presence."""
        self.connections.pop(username, None)
 
    @property
    def online(self) -> list:
        """Return list of currently connected usernames."""
        return list(self.connections.keys())
 
    async def broadcast_status(self):
        """Push the current online-user list to every connected client."""
        payload = _json_msg.dumps({"type": "status", "online": self.online})
        dead = []
        for u, ws in list(self.connections.items()):
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(u)
        for u in dead:
            self.connections.pop(u, None)
 
    async def deliver(self, msg: dict, room: str):
        """Send a message dict to all users who belong to the room."""
        payload = _json_msg.dumps({"type": "message", **msg})
        if room == "group":
            targets = list(self.connections.items())
        else:
            # DM: only the two participants
            parts = set(room.split(":")[1:])
            targets = [(u, ws) for u, ws in self.connections.items() if u in parts]
        dead = []
        for u, ws in targets:
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(u)
        for u in dead:
            self.connections.pop(u, None)
 
    async def send_to(self, username: str, payload: dict):
        """Send a JSON payload to a specific connected user."""
        ws = self.connections.get(username)
        if ws:
            try:
                await ws.send_text(_json_msg.dumps(payload))
            except Exception:
                self.connections.pop(username, None)
 
 
msg_manager = MessageManager()
 
 
# ── Pydantic models ────────────────────────────────────────────────────────
 
class MsgToggleRequest(BaseModel):
    enabled: bool
 
class MsgSendRequest(BaseModel):
    room:     str
    content:  str
    msg_type: str = "text"
 
 
# ── REST routes ────────────────────────────────────────────────────────────
 
@app.get("/messages", response_class=HTMLResponse)
async def messages_page():
    """Serve the messaging chat page."""
    resp = FileResponse(os.path.join(BASE_DIR, "static", "messages", "chat.html"))
    resp.headers["ngrok-skip-browser-warning"] = "1"
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp
 
 
@app.get("/api/messages/status")
async def messages_status(user: str = Depends(get_current_user)):
    """Return messaging enabled state, online users, and available rooms."""
    enabled = _msg_enabled()
    if not enabled and user not in ALL_ADMINS:
        return {"enabled": False, "online": [], "rooms": []}
    # Build rooms list: group + DMs where user has history
    c = db_msg()
    dm_rows = c.execute(
        "SELECT DISTINCT room FROM messages WHERE room LIKE 'dm:%' AND ("
        "room LIKE ? OR room LIKE ?)",
        (f"dm:{user}:%", f"dm:%:{user}")
    ).fetchall()
    c.close()
    rooms = ["group"] + [r["room"] for r in dm_rows]
    return {
        "enabled": enabled,
        "online":  msg_manager.online,
        "rooms":   rooms,
    }
 
 
@app.get("/api/messages/history")
async def messages_history(
    user: str = Depends(get_current_user),
    room: str = "group",
    limit: int = 60,
    before_id: int = 0,
):
    """Return paginated message history for a room."""
    enabled = _msg_enabled()
    if not enabled and user not in ALL_ADMINS:
        raise HTTPException(403, "Messaging is disabled")
    # Validate access to DM room
    if room.startswith("dm:"):
        parts = set(room.split(":")[1:])
        if user not in parts and user not in SUPERADMINS:
            raise HTTPException(403, "Access denied")
    limit = max(1, min(limit, 100))
    msgs = _load_history(room, limit, before_id)
    # Attach read status for current user
    if msgs:
        ids = [m["id"] for m in msgs]
        c = db_msg()
        read_ids = {
            r["msg_id"]
            for r in c.execute(
                f"SELECT msg_id FROM msg_reads WHERE username=? AND msg_id IN ({','.join('?'*len(ids))})",
                [user] + ids
            ).fetchall()
        }
        c.close()
        for m in msgs:
            m["read_by_me"] = m["id"] in read_ids
    return msgs
 
 
@app.post("/api/messages/read")
async def messages_mark_read(
    user: str = Depends(get_current_user),
    room: str = "group",
    last_id: int = 0,
):
    """Mark all messages up to last_id in a room as read by this user."""
    if not _msg_enabled() and user not in ALL_ADMINS:
        raise HTTPException(403, "Messaging is disabled")
    if not last_id:
        return {"ok": True}
    c = db_msg()
    rows = c.execute(
        "SELECT id FROM messages WHERE room=? AND id<=? AND id NOT IN "
        "(SELECT msg_id FROM msg_reads WHERE username=?)",
        (room, last_id, user)
    ).fetchall()
    for r in rows:
        c.execute("INSERT OR IGNORE INTO msg_reads(msg_id,username) VALUES(?,?)", (r["id"], user))
    c.commit()
    c.close()
    return {"ok": True, "marked": len(rows)}
 
 
@app.post("/api/messages/audio")
async def messages_upload_audio(
    user: str = Depends(get_current_user),
    file: UploadFile = File(...),
):
    """Upload an audio message file; returns its public URL."""
    if not _msg_enabled() and user not in ALL_ADMINS:
        raise HTTPException(403, "Messaging is disabled")
    ext = os.path.splitext(file.filename or "audio.webm")[1].lower()
    if not ext:
        ext = ".webm"
    if ext not in MSG_ALLOWED:
        raise HTTPException(400, f"Audio format not supported: {ext}")
    fname = _uuid.uuid4().hex + ext
    dest  = os.path.join(MSG_DIR, fname)
    os.makedirs(MSG_DIR, exist_ok=True)
    data  = await file.read()
    if len(data) > 10 * 1024 * 1024:  # 10 MB max
        raise HTTPException(413, "Audio too large (max 10 MB)")
    with open(dest, "wb") as f:
        f.write(data)
    url = f"/static/audio/messages/{fname}"
    logger.info("Audio upload: %s by %s (%d bytes)", fname, user, len(data))
    return {"ok": True, "url": url}
 
 
@app.post("/api/messages/toggle")
async def messages_toggle(body: MsgToggleRequest, user: str = Depends(get_current_user)):
    """Enable or disable the messaging system (admins only)."""
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Admins only")
    _set_msg_enabled(body.enabled)
    logger.info("Messaging %s by %s", "enabled" if body.enabled else "disabled", user)
    await msg_manager.broadcast_status()
    return {"enabled": body.enabled}
 
 
@app.get("/api/messages/users")
async def messages_users(user: str = Depends(get_current_user)):
    """Return list of users available to start a DM with."""
    if not _msg_enabled() and user not in ALL_ADMINS:
        raise HTTPException(403, "Messaging is disabled")
    c = db_users()
    rows = c.execute(
        "SELECT username FROM users WHERE password_hash NOT IN ('__UNSET__','__AUTO__') "
        "ORDER BY username"
    ).fetchall()
    c.close()
    return [r["username"] for r in rows if r["username"] != user]
 
 
@app.get("/api/messages/unread")
async def messages_unread(user: str = Depends(get_current_user)):
    """Return unread message counts per room for the current user."""
    if not _msg_enabled() and user not in ALL_ADMINS:
        return {}
    c = db_msg()
    rows = c.execute(
        "SELECT m.room, COUNT(*) cnt FROM messages m "
        "WHERE m.from_user != ? AND m.id NOT IN "
        "(SELECT msg_id FROM msg_reads WHERE username=?) "
        "GROUP BY m.room",
        (user, user)
    ).fetchall()
    c.close()
    return {r["room"]: r["cnt"] for r in rows}
 
 
@app.get("/api/messages/admin/stats")
async def messages_admin_stats(user: str = Depends(get_current_user)):
    """Return admin-level messaging statistics."""
    if user not in ALL_ADMINS:
        raise HTTPException(403, "Admins only")
    c = db_msg()
    total   = c.execute("SELECT COUNT(*) n FROM messages").fetchone()["n"]
    today   = c.execute(
        "SELECT COUNT(*) n FROM messages WHERE date(created_at)=date('now')"
    ).fetchone()["n"]
    users   = c.execute("SELECT COUNT(DISTINCT from_user) n FROM messages").fetchone()["n"]
    rooms   = c.execute("SELECT COUNT(DISTINCT room) n FROM messages").fetchone()["n"]
    recent  = c.execute(
        "SELECT from_user, content, msg_type, created_at FROM messages "
        "ORDER BY id DESC LIMIT 10"
    ).fetchall()
    c.close()
    return {
        "total_messages": total,
        "messages_today": today,
        "unique_senders": users,
        "total_rooms":    rooms,
        "recent":         [dict(r) for r in recent],
        "online_now":     len(msg_manager.online),
        "enabled":        _msg_enabled(),
    }
 
 
@app.get("/api/opo/my-access")
async def opo_my_access(user: str = Depends(get_current_user)):
    """Returns whether the current user can access OPO."""
    is_opo = user in OPO_USERS or user in SUPERADMINS
    return {"is_opo_user": is_opo, "username": user}


@app.get("/api/messages/admin/all-rooms")
async def messages_admin_all_rooms(user: str = Depends(get_current_user)):
    """Return all conversation rooms with last message info, for superadmin view."""
    if user not in SUPERADMINS:
        raise HTTPException(403, "Superadmins only")
    c = db_msg()
    rows = c.execute(
        "SELECT room, from_user AS last_user, content AS last_content, "
        "created_at AS last_at, COUNT(*) OVER (PARTITION BY room) AS total "
        "FROM messages m1 "
        "WHERE id = (SELECT MAX(id) FROM messages m2 WHERE m2.room = m1.room) "
        "ORDER BY last_at DESC"
    ).fetchall()
    c.close()
    return {"rooms": [dict(r) for r in rows]}
 
 
@app.get("/api/rooms/list")
async def rooms_list(user: str = Depends(get_current_user)):
    """List video rooms visible to the current user."""
    return {"rooms": _room_public_list(user)}


@app.post("/api/rooms/invite")
async def rooms_invite(request: Request, user: str = Depends(get_current_user)):
    """Invite a user to an existing private room (host only)."""
    body = await request.json()
    room_key = str(body.get("room", ""))
    invite_user = str(body.get("username", ""))
    if not room_key or not invite_user:
        raise HTTPException(400, "room and username required")
    if room_key not in _ROOMS:
        raise HTTPException(404, "Room not found")
    room = _ROOMS[room_key]
    if room["host"] != user and user not in SUPERADMINS:
        raise HTTPException(403, "Only the host can invite")
    room["invites"].add(invite_user)
    await msg_manager.send_to(invite_user, {
        "type": "room-invite",
        "room_key": room_key,
        "title": room["title"],
        "host": user,
    })
    # Update room list for invited user
    ws_inv = msg_manager.connections.get(invite_user)
    if ws_inv:
        try:
            await ws_inv.send_text(_json_msg.dumps({
                "type": "rooms-update",
                "rooms": _room_public_list(invite_user),
            }))
        except Exception:
            pass
    return {"ok": True}
 
 
# ── WebSocket ──────────────────────────────────────────────────────────────
 
@app.websocket("/ws/messages")
async def messages_ws(websocket: WebSocket, token: str = ""):
    """WebSocket endpoint for real-time messaging.
    Events received:  join | send | typing | read
    Events sent:      history | message | status | typing | error
    """
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Authentication required")
        return
    # Verify user exists
    c = db_users()
    row = c.execute("SELECT username FROM users WHERE username=?", (username,)).fetchone()
    c.close()
    if not row:
        await websocket.close(code=4001, reason="User not found")
        return
 
    enabled = _msg_enabled()
    if not enabled and username not in ALL_ADMINS:
        await websocket.close(code=4003, reason="Messaging disabled")
        return
 
    _ping_session(username, "messages")
    await msg_manager.connect(username, websocket)

    # ── Enviar lista de salas activas al conectarse ────────────────────────
    try:
        await websocket.send_text(_json_msg.dumps({
            "type": "rooms-update",
            "rooms": _room_public_list(username),
        }))
    except Exception:
        pass
 
    try:
        while True:
            raw  = await websocket.receive_text()
            data = _json_msg.loads(raw)
            action = data.get("action", "")
 
            # ── join: client requests history for a room ───────────────
            if action == "join":
                room = data.get("room", "group")
                if room.startswith("dm:"):
                    parts = set(room.split(":")[1:])
                    if username not in parts and username not in SUPERADMINS:
                        continue
                history = _load_history(room, limit=60)
                await websocket.send_text(_json_msg.dumps({
                    "type":    "history",
                    "room":    room,
                    "messages": history,
                }))
 
            # ── send: deliver a new message ────────────────────────────
            elif action == "send":
                if not _msg_enabled() and username not in ALL_ADMINS:
                    continue
                room     = data.get("room", "group")
                content  = str(data.get("content", "")).strip()
                msg_type = data.get("msg_type", "text")
 
                if not content:
                    continue
                if len(content) > 4000:
                    content = content[:4000]
                if msg_type not in ("text", "audio"):
                    msg_type = "text"
 
                # Validate DM access
                if room.startswith("dm:"):
                    parts = set(room.split(":")[1:])
                    if username not in parts and username not in SUPERADMINS:
                        continue
 
                reply_to_id = data.get("reply_to_id") or None
                if reply_to_id: reply_to_id = int(reply_to_id)
                msg = _save_message(room, username, content, msg_type, reply_to_id)
                # Attach context for reply preview
                if reply_to_id:
                    c2 = db_msg()
                    ref = c2.execute("SELECT from_user, content, msg_type FROM messages WHERE id=?", (reply_to_id,)).fetchone()
                    c2.close()
                    if ref:
                        msg["reply_to"] = {"id": reply_to_id, "from_user": ref["from_user"],
                                           "content": ref["content"], "msg_type": ref["msg_type"]}
                await msg_manager.deliver(msg, room)
 
            # ── typing: broadcast typing indicator ─────────────────────
            elif action == "typing":
                room = data.get("room", "group")
                if room.startswith("dm:"):
                    parts = set(room.split(":")[1:])
                    other = [u for u in parts if u != username]
                    for u in other:
                        await msg_manager.send_to(u, {
                            "type": "typing", "room": room, "from": username
                        })
                else:
                    # Group: broadcast to all except sender
                    payload = _json_msg.dumps({
                        "type": "typing", "room": room, "from": username
                    })
                    for u, ws in list(msg_manager.connections.items()):
                        if u != username:
                            try:
                                await ws.send_text(payload)
                            except Exception:
                                pass
 
            # ── read: mark messages as read ────────────────────────────
            elif action == "read":
                room    = data.get("room", "group")
                last_id = int(data.get("last_id", 0))
                if last_id:
                    c = db_msg()
                    rows = c.execute(
                        "SELECT id FROM messages WHERE room=? AND id<=? AND from_user!=? "
                        "AND id NOT IN (SELECT msg_id FROM msg_reads WHERE username=?)",
                        (room, last_id, username, username)
                    ).fetchall()
                    for r in rows:
                        c.execute(
                            "INSERT OR IGNORE INTO msg_reads(msg_id,username) VALUES(?,?)",
                            (r["id"], username)
                        )
                    c.commit()
                    c.close()
 
            # ── react: toggle an emoji reaction ────────────────────────
            elif action == "react":
                msg_id = int(data.get("msg_id", 0))
                emoji  = str(data.get("emoji", ""))[:8]
                if not msg_id or not emoji:
                    continue
                c = db_msg()
                row_check = c.execute(
                    "SELECT 1 FROM msg_reactions WHERE msg_id=? AND username=? AND emoji=?",
                    (msg_id, username, emoji)
                ).fetchone()
                if row_check:
                    c.execute("DELETE FROM msg_reactions WHERE msg_id=? AND username=? AND emoji=?",
                              (msg_id, username, emoji))
                else:
                    c.execute("INSERT OR IGNORE INTO msg_reactions(msg_id,username,emoji) VALUES(?,?,?)",
                              (msg_id, username, emoji))
                # Fetch updated reactions for this message
                react_rows = c.execute(
                    "SELECT username,emoji FROM msg_reactions WHERE msg_id=?", (msg_id,)
                ).fetchall()
                c.commit()
                # Get room for this message to broadcast
                msg_row = c.execute("SELECT room FROM messages WHERE id=?", (msg_id,)).fetchone()
                c.close()
                if msg_row:
                    await msg_manager.deliver({
                        "type":      "reaction",
                        "msg_id":    msg_id,
                        "reactions": [{"username": r["username"], "emoji": r["emoji"]} for r in react_rows],
                    }, msg_row["room"])
 
            # ── delete: soft-delete own message ────────────────────────
            elif action == "delete_msg":
                msg_id = int(data.get("msg_id", 0))
                if not msg_id:
                    continue
                c = db_msg()
                msg_row = c.execute(
                    "SELECT room, from_user FROM messages WHERE id=?", (msg_id,)
                ).fetchone()
                if msg_row and (msg_row["from_user"] == username or username in SUPERADMINS):
                    c.execute("UPDATE messages SET deleted=1, content='Este mensaje fue eliminado' WHERE id=?", (msg_id,))
                    c.commit()
                    room_del = msg_row["room"]
                    c.close()
                    await msg_manager.deliver({"type": "deleted", "msg_id": msg_id}, room_del)
                else:
                    c.close()
 
            # ── webrtc-join: create/join a video room ──────────────────
            elif action == "webrtc-join":
                room_key  = str(data.get("room", _uuid.uuid4().hex[:12]))
                title     = str(data.get("title", f"Sala de {username}"))[:80]
                mode      = data.get("mode", "public")   # "public" | "private"
                invites   = list(data.get("invites", []))  # list of usernames

                if room_key not in _ROOMS:
                    _ROOMS[room_key] = {
                        "host": username, "title": title,
                        "mode": mode, "invites": set(invites),
                        "members": set()
                    }
                else:
                    r = _ROOMS[room_key]
                    if username not in r["invites"] and r["mode"] != "public" and username != r["host"]:
                        await websocket.send_text(_json_msg.dumps({"type":"error","msg":"No tienes acceso a esta sala"}))
                        continue

                _ROOMS[room_key]["members"].add(username)

                # Notify invited users
                for inv in invites:
                    if inv and inv != username:
                        await msg_manager.send_to(inv, {
                            "type": "room-invite",
                            "room_key": room_key,
                            "title": title,
                            "host": username,
                        })
                        _ROOMS[room_key]["invites"].add(inv)

                # Confirm to the joining user that they are in the room
                await websocket.send_text(_json_msg.dumps({
                    "type":     "webrtc-room-joined",
                    "room":     room_key,
                    "title":    _ROOMS[room_key]["title"],
                    "host":     _ROOMS[room_key]["host"],
                    "mode":     _ROOMS[room_key]["mode"],
                    "members":  list(_ROOMS[room_key]["members"]),
                    "you":      username,
                }))

                # Notify peers already in room that a new user joined
                for peer in list(_ROOMS[room_key]["members"]):
                    if peer != username:
                        await msg_manager.send_to(peer, {
                            "type": "webrtc-joined", "from": username, "room": room_key
                        })

                # Broadcast updated room list to all users
                for u, ws_u in list(msg_manager.connections.items()):
                    try:
                        visible = _room_public_list(u)
                        await ws_u.send_text(_json_msg.dumps({"type":"rooms-update","rooms":visible}))
                    except Exception:
                        pass
 
            # ── webrtc-leave: leave a video room ──────────────────────
            elif action == "webrtc-leave":
                room_key = str(data.get("room", ""))
                if room_key in _ROOMS:
                    _ROOMS[room_key]["members"].discard(username)
                    for peer in list(_ROOMS[room_key]["members"]):
                        await msg_manager.send_to(peer, {
                            "type": "webrtc-left", "from": username, "room": room_key
                        })
                    if not _ROOMS[room_key]["members"]:
                        del _ROOMS[room_key]
                    # Broadcast updated room list
                    for u, ws_u in list(msg_manager.connections.items()):
                        try:
                            visible = _room_public_list(u)
                            await ws_u.send_text(_json_msg.dumps({"type":"rooms-update","rooms":visible}))
                        except Exception:
                            pass
 
            # ── webrtc-offer / webrtc-answer / webrtc-ice — forward ────
            elif action in ("webrtc-offer", "webrtc-answer", "webrtc-ice"):
                to = data.get("to")
                if to:
                    # Map action name → type name expected by the client
                    type_map = {
                        "webrtc-offer":  "webrtc-offer",
                        "webrtc-answer": "webrtc-answer",
                        "webrtc-ice":    "webrtc-ice",
                    }
                    fwd = {
                        "type":      type_map[action],
                        "from":      username,
                        "room":      data.get("room", ""),
                        "to":        to,
                    }
                    if action == "webrtc-ice":
                        fwd["candidate"] = data.get("candidate")
                    else:
                        fwd["sdp"] = data.get("sdp")
                    await msg_manager.send_to(to, fwd)
 
            # ── room-invite: invite user to existing room ──────────────
            elif action == "room-invite":
                room_key = str(data.get("room", ""))
                inv_user = str(data.get("invite", ""))
                if room_key in _ROOMS and (_ROOMS[room_key]["host"] == username or username in SUPERADMINS):
                    _ROOMS[room_key]["invites"].add(inv_user)
                    await msg_manager.send_to(inv_user, {
                        "type": "room-invite",
                        "room_key": room_key,
                        "title": _ROOMS[room_key]["title"],
                        "host": username,
                    })

            # ── call-chat: ephemeral in-call chat message ──────────────
            elif action == "call-chat":
                room_key = str(data.get("room", ""))
                text = str(data.get("text", "")).strip()[:500]
                if room_key in _ROOMS and username in _ROOMS[room_key]["members"] and text:
                    for peer in list(_ROOMS[room_key]["members"]):
                        if peer != username:
                            await msg_manager.send_to(peer, {
                                "type": "call-chat",
                                "room": room_key,
                                "from": username,
                                "text": text,
                            })

            # ── call-mute: broadcast mic mute state to room peers ──────
            elif action == "call-mute":
                room_key = str(data.get("room", ""))
                muted = bool(data.get("muted", False))
                if room_key in _ROOMS and username in _ROOMS[room_key]["members"]:
                    for peer in list(_ROOMS[room_key]["members"]):
                        if peer != username:
                            await msg_manager.send_to(peer, {
                                "type": "call-mute",
                                "room": room_key,
                                "from": username,
                                "muted": muted,
                            })
 
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error("Messages WS error [%s]: %s", username, e)
    finally:
        msg_manager.disconnect(username)
        await msg_manager.broadcast_status()
        # Limpiar al usuario de todas las salas activas al desconectarse
        rooms_changed = False
        for room_key in list(_ROOMS.keys()):
            if username in _ROOMS[room_key]["members"]:
                _ROOMS[room_key]["members"].discard(username)
                rooms_changed = True
                for peer in list(_ROOMS[room_key]["members"]):
                    await msg_manager.send_to(peer, {
                        "type": "webrtc-left", "from": username, "room": room_key
                    })
                if not _ROOMS[room_key]["members"]:
                    del _ROOMS[room_key]
        if rooms_changed:
            for u, ws_u in list(msg_manager.connections.items()):
                try:
                    visible = _room_public_list(u)
                    await ws_u.send_text(_json_msg.dumps({"type":"rooms-update","rooms":visible}))
                except Exception:
                    pass
 
 
# ── Init messaging DB at startup ───────────────────────────────────────────
_msg_db_init()
os.makedirs(os.path.join(BASE_DIR, "static", "messages"), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "static", "admin"), exist_ok=True)
 
 
# =============================================================================
# GAME ADMIN PAGES — dedicated HTML panel per game
# =============================================================================
 
ADMIN_DIR = os.path.join(BASE_DIR, "static", "admin")
 
def _serve_admin_page(filename: str):
    """Serve a game admin HTML page with cache-busting headers."""
    path = os.path.join(ADMIN_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(404, f"Admin page not found: {filename}. Upload {filename} to static/admin/")
    resp = FileResponse(path)
    resp.headers["ngrok-skip-browser-warning"] = "1"
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp
 
def _serve_game_page(game_dir: str, filename: str = "game.html"):
    """Serve a player-facing game HTML page. File must exist in the game directory."""
    path = os.path.join(game_dir, filename)
    if not os.path.exists(path):
        game_name = os.path.basename(game_dir)
        # Return a helpful page that explains how to fix it
        html = f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{game_name} — Setup needed</title>
<style>body{{background:#04040A;color:#EAE6D8;font-family:monospace;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;box-sizing:border-box}}
.box{{max-width:500px;text-align:center}}h1{{color:#D4A843;font-size:1.4rem;margin-bottom:12px}}
p{{color:#9A9070;font-size:.82rem;line-height:1.6;margin-bottom:10px}}
code{{background:#0C0C1A;border:1px solid rgba(212,168,67,.2);border-radius:6px;padding:8px 12px;display:block;margin:10px 0;font-size:.75rem;color:#F0C866;text-align:left}}
a{{color:#D4A843}}</style></head>
<body><div class="box">
<h1>🎮 {game_name}</h1>
<p>El archivo del juego no está instalado todavía.</p>
<p>Sube el archivo <strong>game.html</strong> a esta carpeta del servidor:</p>
<code>static/{game_name}/game.html</code>
<p>Este archivo viene incluido en el ZIP de actualizaciones bajo <code>game_pages/{game_name}/game.html</code></p>
<p><a href="/">← Volver al inicio</a></p>
</div></body></html>"""
        return HTMLResponse(content=html, status_code=200, headers={"ngrok-skip-browser-warning": "1"})
    resp = FileResponse(path)
    resp.headers["ngrok-skip-browser-warning"] = "1"
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp
 
@app.get("/admin/games/pasapalabra", response_class=HTMLResponse)
async def admin_pasapalabra_page(user: str = Depends(get_current_user)):
    if user not in ALL_ADMINS: raise HTTPException(403)
    return _serve_admin_page("pasapalabra.html")
 
@app.get("/admin/games/millonario", response_class=HTMLResponse)
async def admin_millonario_page(user: str = Depends(get_current_user)):
    if user not in ALL_ADMINS: raise HTTPException(403)
    return _serve_admin_page("millonario.html")
 
@app.get("/admin/games/quiensoy", response_class=HTMLResponse)
async def admin_quiensoy_page(user: str = Depends(get_current_user)):
    if user not in ALL_ADMINS: raise HTTPException(403)
    return _serve_admin_page("quiensoy.html")
 
@app.get("/admin/games/cifrasletras", response_class=HTMLResponse)
async def admin_cifrasletras_page(user: str = Depends(get_current_user)):
    if user not in ALL_ADMINS: raise HTTPException(403)
    return _serve_admin_page("cifrasletras.html")
 
@app.get("/admin/games/cuentos", response_class=HTMLResponse)
async def admin_cuentos_page(user: str = Depends(get_current_user)):
    if user not in ALL_ADMINS: raise HTTPException(403)
    return _serve_admin_page("cuentos.html")
 
@app.get("/admin/games/mensajes", response_class=HTMLResponse)
async def admin_mensajes_page(user: str = Depends(get_current_user)):
    if user not in ALL_ADMINS: raise HTTPException(403)
    return _serve_admin_page("mensajes.html")
 
 
# =============================================================================
# ENTRY POINT
# =============================================================================
 
# =============================================================================
# VIDEO RELAY — WebSocket relay de video/audio via servidor
# Funciona siempre: PC, Android, iPhone, cualquier red, sin STUN/TURN
# Cada cliente envía su stream como chunks binarios; el servidor los reenvía
# a todos los demás miembros de la sala.
# =============================================================================

# Salas de video relay: room_key → {username: websocket}
_VIDEO_ROOMS: dict = {}

@app.websocket("/ws/video")
async def video_relay_ws(websocket: WebSocket, token: str = ""):
    """WebSocket de relay de video. Recibe chunks binarios de un cliente
    y los reenvía a todos los demás miembros de la misma sala."""
    username = decode_token(token) if token else None
    if not username:
        await websocket.close(code=4001, reason="Auth required")
        return
    conn = db_users()
    row = conn.execute("SELECT username FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        await websocket.close(code=4001, reason="User not found")
        return

    await websocket.accept()
    room_key = None

    try:
        while True:
            msg = await websocket.receive()

            # Mensaje de texto: control (join/leave)
            if "text" in msg:
                try:
                    data = _json_msg.loads(msg["text"])
                except Exception:
                    continue
                action = data.get("action", "")

                if action == "join":
                    room_key = str(data.get("room", ""))
                    if not room_key:
                        continue
                    if room_key not in _VIDEO_ROOMS:
                        _VIDEO_ROOMS[room_key] = {}
                    _VIDEO_ROOMS[room_key][username] = websocket
                    # Notificar a los demás que alguien entró
                    for u, ws_u in list(_VIDEO_ROOMS[room_key].items()):
                        if u != username:
                            try:
                                await ws_u.send_text(_json_msg.dumps({
                                    "type": "peer-joined", "from": username
                                }))
                            except Exception:
                                pass
                    logger.info("Video relay: %s joined room %s", username, room_key)

                elif action == "leave":
                    if room_key and room_key in _VIDEO_ROOMS:
                        _VIDEO_ROOMS[room_key].pop(username, None)
                        if not _VIDEO_ROOMS[room_key]:
                            del _VIDEO_ROOMS[room_key]
                        else:
                            for u, ws_u in list(_VIDEO_ROOMS[room_key].items()):
                                try:
                                    await ws_u.send_text(_json_msg.dumps({
                                        "type": "peer-left", "from": username
                                    }))
                                except Exception:
                                    pass
                    room_key = None

            # Mensaje binario: chunk de video/audio — reenviar a todos en la sala
            elif "bytes" in msg and room_key and room_key in _VIDEO_ROOMS:
                chunk = msg["bytes"]
                if not chunk:
                    continue
                # Prefijo: 4 bytes con longitud del username + username + chunk
                uname_b = username.encode("utf-8")
                header = len(uname_b).to_bytes(1, "big") + uname_b
                payload = header + chunk
                dead = []
                for u, ws_u in list(_VIDEO_ROOMS[room_key].items()):
                    if u != username:
                        try:
                            await ws_u.send_bytes(payload)
                        except Exception:
                            dead.append(u)
                for u in dead:
                    _VIDEO_ROOMS[room_key].pop(u, None)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error("Video relay WS error [%s]: %s", username, e)
    finally:
        if room_key and room_key in _VIDEO_ROOMS:
            _VIDEO_ROOMS[room_key].pop(username, None)
            if not _VIDEO_ROOMS[room_key]:
                del _VIDEO_ROOMS[room_key]
            else:
                for u, ws_u in list(_VIDEO_ROOMS.get(room_key, {}).items()):
                    try:
                        await ws_u.send_text(_json_msg.dumps({
                            "type": "peer-left", "from": username
                        }))
                    except Exception:
                        pass


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)