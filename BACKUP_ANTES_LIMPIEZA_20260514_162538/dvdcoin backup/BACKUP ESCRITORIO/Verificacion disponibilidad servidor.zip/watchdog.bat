@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "C:\DvDcoin"

:: =============================================================================
:: DVDcoin Bank — WATCHDOG v1.0
:: =============================================================================
:: Launched by Windows Task Scheduler:
::   - First run: 10 minutes after Windows boot
::   - Then: every 5 minutes indefinitely
::
:: What it checks (every cycle):
::   1. ngrok.exe process is running
::   2. https://nonflying-unstiffened-oakley.ngrok-free.dev/ responds with HTTP 200
::      AND the response body contains "DVDcoin"
::
:: Failure logic:
::   - 1 failure  → log + toast notification + mark fail
::   - 2 consecutive failures → log + toast + REBOOT PC
::
:: Logs: C:\DvDcoin\logs\watchdog.log (kept, max 500KB then rotated)
:: =============================================================================

set LOG=C:\DvDcoin\logs\watchdog.log
set NGROK_URL=https://nonflying-unstiffened-oakley.ngrok-free.dev/
set FAIL_FILE=C:\DvDcoin\logs\.watchdog_fails
set MAX_FAILS=2
set TIMEOUT_SEC=15

:: Ensure log dir exists
if not exist "C:\DvDcoin\logs" mkdir "C:\DvDcoin\logs"

:: ── Rotate log if > 500KB ──────────────────────────────────
for %%F in ("%LOG%") do set LOG_SIZE=%%~zF
if defined LOG_SIZE if %LOG_SIZE% gtr 512000 (
    copy "%LOG%" "%LOG%.old" >nul 2>&1
    del "%LOG%" >nul 2>&1
)

:: ── Read current fail counter ──────────────────────────────
set FAILS=0
if exist "%FAIL_FILE%" (
    set /p FAILS=<"%FAIL_FILE%"
    if "!FAILS!"=="" set FAILS=0
)

:: ── Timestamp ──────────────────────────────────────────────
for /f "tokens=*" %%d in ('powershell -NoProfile -Command "Get-Date -Format \"yyyy-MM-dd HH:mm:ss\""') do set NOW=%%d

echo [%NOW%] ── Watchdog cycle START ──────────────── >> "%LOG%"

:: =============================================================================
:: CHECK 1 — ngrok.exe process running
:: =============================================================================
set CHECK1=FAIL
tasklist /FI "IMAGENAME eq ngrok.exe" 2>nul | findstr /i "ngrok.exe" >nul 2>&1
if %errorlevel% equ 0 (
    set CHECK1=OK
    echo [%NOW%] CHECK1 ngrok.exe process: RUNNING >> "%LOG%"
) else (
    echo [%NOW%] CHECK1 ngrok.exe process: NOT FOUND >> "%LOG%"
)

:: =============================================================================
:: CHECK 2 — ngrok URL responds AND contains "DVDcoin"
:: =============================================================================
set CHECK2=FAIL
set HTTP_CODE=0
set BODY_OK=0

for /f "tokens=*" %%r in ('powershell -NoProfile -Command ^
  "try { $r = Invoke-WebRequest -Uri '%NGROK_URL%' -UseBasicParsing -TimeoutSec %TIMEOUT_SEC% -MaximumRedirection 5; $code = $r.StatusCode; $body = if($r.Content -like '*DVDcoin*'){'YES'}else{'NO'}; Write-Output \"$code|$body\" } catch { Write-Output \"0|NO\" }" 2^>nul') do (
    set RESPONSE=%%r
)

for /f "tokens=1,2 delims=|" %%a in ("!RESPONSE!") do (
    set HTTP_CODE=%%a
    set BODY_MATCH=%%b
)

if "!HTTP_CODE!"=="200" (
    if "!BODY_MATCH!"=="YES" (
        set CHECK2=OK
        echo [%NOW%] CHECK2 ngrok URL: HTTP 200 + DVDcoin content FOUND >> "%LOG%"
    ) else (
        echo [%NOW%] CHECK2 ngrok URL: HTTP 200 but DVDcoin NOT found in body >> "%LOG%"
    )
) else (
    echo [%NOW%] CHECK2 ngrok URL: HTTP !HTTP_CODE! - FAILED >> "%LOG%"
)

:: =============================================================================
:: VERDICT
:: =============================================================================
if "!CHECK1!"=="OK" if "!CHECK2!"=="OK" (
    :: ── ALL GOOD ────────────────────────────────────────────
    echo [%NOW%] RESULT: ALL CHECKS PASSED >> "%LOG%"
    echo 0 > "%FAIL_FILE%"

    :: Toast: OK
    powershell -NoProfile -Command ^
      "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] | Out-Null; $t=[Windows.UI.Notifications.ToastTemplateType]::ToastText02; $x=[Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($t); $n=$x.GetElementsByTagName('text'); $n[0].AppendChild($x.CreateTextNode('DVDcoin Bank ✓')); $n[1].AppendChild($x.CreateTextNode('All systems operational')); $toast=[Windows.UI.Notifications.ToastNotification]::new($x); [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('DVDcoin Watchdog').Show($toast);" >nul 2>&1

    echo [%NOW%] ── Cycle END: OK ─────────────────────────── >> "%LOG%"
    echo. >> "%LOG%"
    exit /b 0
)

:: ── At least one check failed ─────────────────────────────
set /a FAILS+=1
echo %FAILS% > "%FAIL_FILE%"

echo [%NOW%] RESULT: FAIL (consecutive fails: !FAILS! / %MAX_FAILS%) >> "%LOG%"
echo [%NOW%]   check1_ngrok_process = !CHECK1! >> "%LOG%"
echo [%NOW%]   check2_ngrok_url     = !CHECK2! (HTTP=!HTTP_CODE!, DVDcoin=!BODY_MATCH!) >> "%LOG%"

:: ── Toast: WARNING ────────────────────────────────────────
set TOAST_MSG=Fail !FAILS!/%MAX_FAILS% — ngrok process: !CHECK1! / URL: !CHECK2!
if !FAILS! lss %MAX_FAILS% (
    set TOAST_TITLE=DVDcoin Bank ⚠ WARNING
) else (
    set TOAST_TITLE=DVDcoin Bank 🔴 REBOOTING
    set TOAST_MSG=2 consecutive failures. Rebooting now...
)

powershell -NoProfile -Command ^
  "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] | Out-Null; $t=[Windows.UI.Notifications.ToastTemplateType]::ToastText02; $x=[Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($t); $n=$x.GetElementsByTagName('text'); $n[0].AppendChild($x.CreateTextNode('%TOAST_TITLE%')); $n[1].AppendChild($x.CreateTextNode('%TOAST_MSG%')); $toast=[Windows.UI.Notifications.ToastNotification]::new($x); [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('DVDcoin Watchdog').Show($toast);" >nul 2>&1

:: ── Check if we must reboot ───────────────────────────────
if !FAILS! geq %MAX_FAILS% (
    echo [%NOW%] !! %MAX_FAILS% consecutive failures — INITIATING REBOOT !! >> "%LOG%"
    echo [%NOW%] ── Cycle END: REBOOT ────────────────────── >> "%LOG%"
    echo. >> "%LOG%"

    :: Reset fail counter BEFORE reboot so we start clean
    echo 0 > "%FAIL_FILE%"

    :: Wait 5 seconds then force reboot
    timeout /t 5 /nobreak >nul
    shutdown /r /f /t 0 /c "DVDcoin Watchdog: 2 consecutive failures detected. Rebooting."
) else (
    echo [%NOW%] ── Cycle END: FAIL !FAILS! — waiting next cycle ── >> "%LOG%"
    echo. >> "%LOG%"
)

exit /b 1
