@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title DVDcoin — Watchdog Installer

:: =============================================================================
:: DVDcoin Bank — INSTALL_WATCHDOG.bat
:: =============================================================================
:: Run ONCE as Administrator.
:: Creates TWO scheduled tasks:
::
::   DVDcoin-Watchdog-Boot   → runs 10 min after Windows starts (SYSTEM)
::   DVDcoin-Watchdog-Repeat → runs every 5 min indefinitely (SYSTEM)
::
:: The watchdog checks:
::   1. ngrok.exe process running
::   2. https://nonflying-unstiffened-oakley.ngrok-free.dev/ responds + "DVDcoin"
::
:: 2 consecutive failures = automatic PC reboot
:: Logs: C:\DvDcoin\logs\watchdog.log
:: =============================================================================

set TASK_BOOT=DVDcoin-Watchdog-Boot
set TASK_REPEAT=DVDcoin-Watchdog-Repeat
set WATCHDOG=C:\DvDcoin\watchdog.bat
set NGROK_URL=https://nonflying-unstiffened-oakley.ngrok-free.dev/
set LOG=C:\DvDcoin\logs\watchdog.log

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║       DVDcoin Bank — Watchdog Installer              ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: ── Admin check ───────────────────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Run as Administrator.
    echo  Right-click INSTALL_WATCHDOG.bat → Exécuter en tant qu'administrateur
    pause & exit /b 1
)
echo  [OK] Running as Administrator

:: ── Check watchdog.bat exists ─────────────────────────────
if not exist "%WATCHDOG%" (
    echo  [ERROR] watchdog.bat not found at %WATCHDOG%
    echo  Make sure watchdog.bat is in C:\DvDcoin\
    pause & exit /b 1
)
echo  [OK] watchdog.bat found

:: ── Create log dir ────────────────────────────────────────
if not exist "C:\DvDcoin\logs" mkdir "C:\DvDcoin\logs"
echo  [OK] Log directory ready

:: ── Remove old tasks if exist ─────────────────────────────
echo.
echo  Removing old tasks (if any)...
schtasks /delete /tn "%TASK_BOOT%"   /f >nul 2>&1
schtasks /delete /tn "%TASK_REPEAT%" /f >nul 2>&1
echo  [OK] Old tasks removed

:: ── TASK 1: Run 10 minutes after Windows boot ─────────────
echo.
echo  [1/2] Installing boot task (10 min delay)...

schtasks /create ^
  /tn "%TASK_BOOT%" ^
  /tr "cmd /c \"C:\DvDcoin\watchdog.bat\"" ^
  /sc onstart ^
  /delay 0010:00 ^
  /ru SYSTEM ^
  /rl HIGHEST ^
  /f >nul 2>&1

if %errorlevel% equ 0 (
    echo  [OK] Task '%TASK_BOOT%' created
    echo       Trigger: Windows start + 10 minutes delay
) else (
    echo  [ERROR] Failed to create boot task
    pause & exit /b 1
)

:: ── TASK 2: Repeat every 5 minutes ────────────────────────
echo.
echo  [2/2] Installing repeat task (every 5 min)...

:: Use XML for precise repeat interval (schtasks /sc minute is limited)
set XML_FILE=%TEMP%\dvd_watchdog_task.xml

(
echo ^<?xml version="1.0" encoding="UTF-16"?^>
echo ^<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"^>
echo   ^<RegistrationInfo^>
echo     ^<Description^>DVDcoin Bank watchdog - checks every 5 minutes^</Description^>
echo   ^</RegistrationInfo^>
echo   ^<Triggers^>
echo     ^<TimeTrigger^>
echo       ^<Repetition^>
echo         ^<Interval^>PT5M^</Interval^>
echo         ^<Duration^>P9999D^</Duration^>
echo         ^<StopAtDurationEnd^>false^</StopAtDurationEnd^>
echo       ^</Repetition^>
echo       ^<StartBoundary^>2024-01-01T00:00:00^</StartBoundary^>
echo       ^<Enabled^>true^</Enabled^>
echo     ^</TimeTrigger^>
echo   ^</Triggers^>
echo   ^<Principals^>
echo     ^<Principal id="Author"^>
echo       ^<UserId^>S-1-5-18^</UserId^>
echo       ^<RunLevel^>HighestAvailable^</RunLevel^>
echo     ^</Principal^>
echo   ^</Principals^>
echo   ^<Settings^>
echo     ^<MultipleInstancesPolicy^>IgnoreNew^</MultipleInstancesPolicy^>
echo     ^<DisallowStartIfOnBatteries^>false^</DisallowStartIfOnBatteries^>
echo     ^<StopIfGoingOnBatteries^>false^</StopIfGoingOnBatteries^>
echo     ^<AllowHardTerminate^>true^</AllowHardTerminate^>
echo     ^<StartWhenAvailable^>true^</StartWhenAvailable^>
echo     ^<RunOnlyIfNetworkAvailable^>false^</RunOnlyIfNetworkAvailable^>
echo     ^<IdleSettings^>
echo       ^<StopOnIdleEnd^>false^</StopOnIdleEnd^>
echo       ^<RestartOnIdle^>false^</RestartOnIdle^>
echo     ^</IdleSettings^>
echo     ^<AllowStartOnDemand^>true^</AllowStartOnDemand^>
echo     ^<Enabled^>true^</Enabled^>
echo     ^<Hidden^>false^</Hidden^>
echo     ^<RunOnlyIfIdle^>false^</RunOnlyIfIdle^>
echo     ^<WakeToRun^>false^</WakeToRun^>
echo     ^<ExecutionTimeLimit^>PT2M^</ExecutionTimeLimit^>
echo     ^<Priority^>7^</Priority^>
echo   ^</Settings^>
echo   ^<Actions Context="Author"^>
echo     ^<Exec^>
echo       ^<Command^>cmd^</Command^>
echo       ^<Arguments^>/c "C:\DvDcoin\watchdog.bat"^</Arguments^>
echo       ^<WorkingDirectory^>C:\DvDcoin^</WorkingDirectory^>
echo     ^</Exec^>
echo   ^</Actions^>
echo ^</Task^>
) > "%XML_FILE%"

schtasks /create /tn "%TASK_REPEAT%" /xml "%XML_FILE%" /ru SYSTEM /f >nul 2>&1
del "%XML_FILE%" >nul 2>&1

if %errorlevel% equ 0 (
    echo  [OK] Task '%TASK_REPEAT%' created
    echo       Trigger: every 5 minutes, indefinitely
) else (
    echo  [ERROR] Failed to create repeat task
    echo  Trying alternate method...
    schtasks /create ^
      /tn "%TASK_REPEAT%" ^
      /tr "cmd /c \"C:\DvDcoin\watchdog.bat\"" ^
      /sc minute /mo 5 ^
      /ru SYSTEM ^
      /rl HIGHEST ^
      /f >nul 2>&1
    if !errorlevel! equ 0 (
        echo  [OK] Task created (alternate method)
    ) else (
        echo  [ERROR] Both methods failed. Check Windows Task Scheduler manually.
        pause & exit /b 1
    )
)

:: ── Final verification ────────────────────────────────────
echo.
echo  ── Verification ────────────────────────────────────────
schtasks /query /tn "%TASK_BOOT%"   2>nul | findstr "Ready\|Running\|TaskName" | head -2
schtasks /query /tn "%TASK_REPEAT%" 2>nul | findstr "Ready\|Running\|TaskName" | head -2

schtasks /query /tn "%TASK_BOOT%" >nul 2>&1
if %errorlevel% equ 0 (echo  [PASS] Boot task registered) else (echo  [FAIL] Boot task not found)

schtasks /query /tn "%TASK_REPEAT%" >nul 2>&1
if %errorlevel% equ 0 (echo  [PASS] Repeat task registered) else (echo  [FAIL] Repeat task not found)

:: ── Test run ──────────────────────────────────────────────
echo.
echo  ── Running ONE test cycle now ──────────────────────────
echo  (This will log results and show a toast if working)
echo.
call "C:\DvDcoin\watchdog.bat"
if %errorlevel% equ 0 (
    echo  [PASS] Test cycle: ALL CHECKS PASSED
) else (
    echo  [WARN] Test cycle: one or more checks failed
    echo         This is normal if server/ngrok are not running yet.
    echo         See: C:\DvDcoin\logs\watchdog.log
)

:: ── Create UNINSTALL_WATCHDOG.bat ─────────────────────────
(
echo @echo off
echo net session ^>nul 2^>^&1 ^|^| ^(echo Run as Admin ^& pause ^& exit /b 1^)
echo schtasks /delete /tn "%TASK_BOOT%"   /f
echo schtasks /delete /tn "%TASK_REPEAT%" /f
echo del "C:\DvDcoin\logs\.watchdog_fails" ^>nul 2^>^&1
echo echo [OK] Watchdog removed.
echo pause
) > "C:\DvDcoin\UNINSTALL_WATCHDOG.bat"
echo.
echo  [OK] UNINSTALL_WATCHDOG.bat created

:: ── Summary ───────────────────────────────────────────────
echo.
echo  ════════════════════════════════════════════════════════
echo   Watchdog installed successfully!
echo  ════════════════════════════════════════════════════════
echo.
echo   Checks every cycle:
echo     1. ngrok.exe process running
echo     2. %NGROK_URL% responds HTTP 200 + "DVDcoin"
echo.
echo   Schedule:
echo     Boot:   10 minutes after Windows starts
echo     Repeat: every 5 minutes, indefinitely
echo.
echo   On failure:
echo     1 fail  → log + Windows toast notification
echo     2 fails → log + toast + FORCE REBOOT
echo.
echo   Log:       C:\DvDcoin\logs\watchdog.log
echo   Uninstall: C:\DvDcoin\UNINSTALL_WATCHDOG.bat (as Admin)
echo.
echo  ════════════════════════════════════════════════════════
echo.
pause
