# =============================================================================
# DVDcoin Bank - Backend API v3.2
# =============================================================================
# KEY CHANGES:
#   - bcrypt used directly (no passlib) -> fixes ValueError password > 72 bytes
#   - Admin balance is ALWAYS 0, never changes
#   - Admins CAN transfer any amount regardless of balance
#   - Admin transfers ARE recorded in history
#   - Recipient admin gets the transaction in history but balance stays 0
#   - Emit endpoint removed (no longer needed, admins just transfer)
#   - Password reset endpoint added for admin panel
# =============================================================================

import os
import sqlite3
import bcrypt as _bcrypt
import logging
from datetime import datetime, timedelta
from typing import Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from jose import JWTError, jwt
from pydantic import BaseModel
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

# =============================================================================
# CONFIGURATION
# =============================================================================

JWT_ALGORITHM = "HS256"
JWT_EXPIRE_H  = 8

DB_PATH  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "dvdcoin.db")
CONF_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "conf")

def load_jwt_secret():
    """Load JWT secret from file, generate if missing."""
    path = os.path.join(CONF_DIR, ".jwt_secret")
    if os.path.exists(path):
        with open(path, "r") as f:
            return f.read().strip()
    import secrets
    s = secrets.token_hex(32)
    os.makedirs(CONF_DIR, exist_ok=True)
    with open(path, "w") as f:
        f.write(s)
    return s

JWT_SECRET = load_jwt_secret()

# ✏️  ADD NEW ADMINS HERE (lowercase Clubhouse usernames)
# Admins: can transfer any amount, balance always stays at 0
ADMINS = {"dvd", "nina", "victor", "yu"}

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES     = 15

limiter = Limiter(key_func=get_remote_address)
logger  = logging.getLogger("dvdcoin")

# =============================================================================
# PASSWORD HELPERS - using bcrypt directly (no passlib compatibility issues)
# =============================================================================

def hash_password(password: str) -> str:
    """Hash password with bcrypt. Truncate to 72 bytes (bcrypt hard limit)."""
    pwd_bytes = password.encode("utf-8")[:72]
    return _bcrypt.hashpw(pwd_bytes, _bcrypt.gensalt(rounds=12)).decode("utf-8")

def verify_password(plain: str, hashed: str) -> bool:
    """Verify password against bcrypt hash. Returns False for placeholder values."""
    if hashed in ("__UNSET__", "__AUTO__"):
        return False
    try:
        return _bcrypt.checkpw(plain.encode("utf-8")[:72], hashed.encode("utf-8"))
    except Exception:
        return False

# =============================================================================
# DATABASE
# =============================================================================

def db_connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def db_init() -> None:
    """Create tables on first run. Safe to call on every restart."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = db_connect()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username        TEXT PRIMARY KEY,
            password_hash   TEXT    NOT NULL DEFAULT '__UNSET__',
            balance         REAL    NOT NULL DEFAULT 0.0,
            is_blocked      INTEGER NOT NULL DEFAULT 0,
            failed_attempts INTEGER NOT NULL DEFAULT 0,
            locked_until    TEXT,
            created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            from_user   TEXT    NOT NULL,
            to_user     TEXT    NOT NULL,
            amount      REAL    NOT NULL,
            concept     TEXT    NOT NULL DEFAULT '',
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_from ON transactions(from_user)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_to   ON transactions(to_user)")
    conn.commit()
    conn.close()

def seed_admins() -> None:
    """Pre-create admin rows so they appear in listings before registering."""
    conn = db_connect()
    for u in ADMINS:
        conn.execute("INSERT OR IGNORE INTO users (username) VALUES (?)", (u,))
    # Always force admin balances to 0 on startup
    for u in ADMINS:
        conn.execute("UPDATE users SET balance=0.0 WHERE username=?", (u,))
    conn.commit()
    conn.close()

def zero_admin_balances(conn: sqlite3.Connection) -> None:
    """Force all admin balances to 0. Called after every transfer."""
    for u in ADMINS:
        conn.execute("UPDATE users SET balance=0.0 WHERE username=?", (u,))

# =============================================================================
# APP LIFECYCLE
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("DVDcoin Bank v3.2 starting...")
    db_init()
    seed_admins()
    logger.info("Ready.")
    yield
    logger.info("Shutting down.")

app = FastAPI(title="DVDcoin Bank", version="3.2", lifespan=lifespan)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")
security = HTTPBearer()

# =============================================================================
# JWT HELPERS
# =============================================================================

def create_token(username: str) -> str:
    exp = datetime.utcnow() + timedelta(hours=JWT_EXPIRE_H)
    return jwt.encode({"sub": username, "exp": exp}, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_token(token: str) -> Optional[str]:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM]).get("sub")
    except JWTError:
        return None

def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """FastAPI dependency: validate JWT, return username."""
    u = decode_token(creds.credentials)
    if not u:
        raise HTTPException(401, "Invalid or expired session")
    conn = db_connect()
    row  = conn.execute("SELECT is_blocked FROM users WHERE username=?", (u,)).fetchone()
    conn.close()
    if not row:           raise HTTPException(401, "User not found")
    if row["is_blocked"]: raise HTTPException(403, "Account blocked")
    return u

# =============================================================================
# BRUTE-FORCE PROTECTION
# =============================================================================

def check_lockout(username: str) -> None:
    conn = db_connect()
    row  = conn.execute("SELECT locked_until FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if row and row["locked_until"]:
        locked_until = datetime.fromisoformat(row["locked_until"])
        if datetime.utcnow() < locked_until:
            mins = int((locked_until - datetime.utcnow()).total_seconds() / 60) + 1
            raise HTTPException(429, f"Too many attempts. Locked for ~{mins} more minute(s).")

def record_failed_login(username: str) -> None:
    conn = db_connect()
    row  = conn.execute("SELECT failed_attempts FROM users WHERE username=?", (username,)).fetchone()
    if not row:
        conn.close()
        return
    n    = (row["failed_attempts"] or 0) + 1
    lock = (datetime.utcnow() + timedelta(minutes=LOCKOUT_MINUTES)).isoformat() if n >= MAX_FAILED_ATTEMPTS else None
    conn.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE username=?", (n, lock, username))
    conn.commit()
    conn.close()

def clear_failed_logins(username: str) -> None:
    conn = db_connect()
    conn.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE username=?", (username,))
    conn.commit()
    conn.close()

def get_or_create_user(username: str, conn: sqlite3.Connection) -> bool:
    """Auto-create account if not exists. Returns True if just created."""
    if conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
        return False
    conn.execute("INSERT INTO users (username, password_hash) VALUES (?, '__AUTO__')", (username,))
    return True

# =============================================================================
# MODELS
# =============================================================================

class RegisterRequest(BaseModel):
    username: str
    password: str

class LoginRequest(BaseModel):
    username: str
    password: str

class TransferRequest(BaseModel):
    to_user: str
    amount: float
    concept: str = ""

# =============================================================================
# ROUTES
# =============================================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    return FileResponse("static/index.html")

@app.get("/api/health")
async def health():
    """Health check - used by launcher script to verify server is up."""
    conn  = db_connect()
    users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    txs   = conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
    conn.close()
    return {"status": "ok", "version": "3.2", "users": users,
            "transactions": txs, "timestamp": datetime.utcnow().isoformat()}

# ── REGISTER ──────────────────────────────────────────────────────────────────
@app.post("/api/register")
@limiter.limit("10/minute")
async def register(request: Request, body: RegisterRequest):
    """Register or activate an account (admin pre-created or auto-created recipient)."""
    u = body.username.strip().lower()
    if not (2 <= len(u) <= 30):
        raise HTTPException(400, "Username must be 2-30 characters")
    if len(body.password) < 4:
        raise HTTPException(400, "Password must be at least 4 characters")

    conn = db_connect()
    row  = conn.execute("SELECT password_hash FROM users WHERE username=?", (u,)).fetchone()

    if row:
        if row["password_hash"] not in ("__UNSET__", "__AUTO__"):
            conn.close()
            raise HTTPException(409, "Username already registered")
        conn.execute("UPDATE users SET password_hash=? WHERE username=?", (hash_password(body.password), u))
    else:
        conn.execute("INSERT INTO users (username, password_hash) VALUES (?,?)",
                     (u, hash_password(body.password)))

    # Ensure admin balance stays 0 after registration
    zero_admin_balances(conn)
    conn.commit()
    conn.close()
    logger.info("Registered: %s", u)
    return {"token": create_token(u), "username": u}

# ── LOGIN ─────────────────────────────────────────────────────────────────────
@app.post("/api/login")
@limiter.limit("20/minute")
async def login(request: Request, body: LoginRequest):
    """Authenticate and return JWT token."""
    u = body.username.strip().lower()
    check_lockout(u)

    conn = db_connect()
    row  = conn.execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
    conn.close()

    if not row:           raise HTTPException(401, "Invalid username or password")
    if row["is_blocked"]: raise HTTPException(403, "Account blocked. Contact an admin.")
    if not verify_password(body.password, row["password_hash"]):
        record_failed_login(u)
        raise HTTPException(401, "Invalid username or password")

    clear_failed_logins(u)
    logger.info("Login: %s", u)

    return {
        "token":    create_token(u),
        "username": u,
        "balance":  0.0 if u in ADMINS else row["balance"],
        "is_admin": u in ADMINS
    }

# ── ME ────────────────────────────────────────────────────────────────────────
@app.get("/api/me")
async def me(user: str = Depends(get_current_user)):
    conn = db_connect()
    row  = conn.execute("SELECT username, balance, created_at FROM users WHERE username=?", (user,)).fetchone()
    conn.close()
    return {
        "username":   row["username"],
        "balance":    0.0 if user in ADMINS else row["balance"],
        "created_at": row["created_at"],
        "is_admin":   user in ADMINS
    }

# ── USER LIST ─────────────────────────────────────────────────────────────────
@app.get("/api/users")
async def list_users(user: str = Depends(get_current_user)):
    """Alphabetical list of registered users for transfer dropdown."""
    conn = db_connect()
    rows = conn.execute(
        "SELECT username FROM users WHERE password_hash NOT IN ('__UNSET__','__AUTO__') ORDER BY username ASC"
    ).fetchall()
    conn.close()
    return [r["username"] for r in rows if r["username"] != user]

# ── TRANSFER ──────────────────────────────────────────────────────────────────
@app.post("/api/transfer")
@limiter.limit("30/minute")
async def transfer(request: Request, body: TransferRequest, user: str = Depends(get_current_user)):
    """
    Transfer DVDcoins between users.
    - Regular users: need sufficient balance, balance is debited
    - Admins: no balance check, no debit (balance stays 0)
    - If recipient is admin: coins arrive but balance stays 0 (transaction recorded in history)
    - Auto-creates recipient account if they don't exist yet
    """
    to_user = body.to_user.strip().lower()
    amount  = round(body.amount, 6)

    if to_user == user:  raise HTTPException(400, "Cannot transfer to yourself")
    if amount <= 0:      raise HTTPException(400, "Amount must be positive")
    if len(body.concept) > 200: raise HTTPException(400, "Concept max 200 characters")

    conn = db_connect()

    # Balance check only for non-admin senders
    if user not in ADMINS:
        sender = conn.execute("SELECT balance FROM users WHERE username=?", (user,)).fetchone()
        if not sender:
            conn.close()
            raise HTTPException(404, "Sender not found")
        if sender["balance"] < amount:
            conn.close()
            raise HTTPException(400,
                f"Insufficient funds. Your balance: {sender['balance']:.4f} DVDcoins")

    # Auto-create recipient if needed
    was_created = get_or_create_user(to_user, conn)

    # Debit sender only if not admin
    if user not in ADMINS:
        conn.execute("UPDATE users SET balance = balance - ? WHERE username=?", (amount, user))

    # Credit recipient only if not admin
    if to_user not in ADMINS:
        conn.execute("UPDATE users SET balance = balance + ? WHERE username=?", (amount, to_user))

    # Always record transaction for history
    conn.execute(
        "INSERT INTO transactions (from_user, to_user, amount, concept) VALUES (?,?,?,?)",
        (user, to_user, amount, body.concept)
    )

    # Guarantee all admin balances stay at 0
    zero_admin_balances(conn)
    conn.commit()

    new_balance = 0.0 if user in ADMINS else \
        conn.execute("SELECT balance FROM users WHERE username=?", (user,)).fetchone()["balance"]
    conn.close()

    logger.info("Transfer %s -> %s: %.4f", user, to_user, amount)
    return {
        "success":      True,
        "message":      f"Sent {amount} DVDcoins to @{to_user}" +
                        (" (account auto-created)" if was_created else ""),
        "new_balance":  new_balance,
        "auto_created": was_created
    }

# ── HISTORY ───────────────────────────────────────────────────────────────────
@app.get("/api/history")
async def history(user: str = Depends(get_current_user), limit: int = 100):
    """Transaction history for current user (sent + received)."""
    conn = db_connect()
    rows = conn.execute(
        "SELECT id, from_user, to_user, amount, concept, created_at FROM transactions "
        "WHERE from_user=? OR to_user=? ORDER BY created_at DESC LIMIT ?",
        (user, user, min(limit, 500))
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ── ADMIN: LIST USERS ─────────────────────────────────────────────────────────
@app.get("/api/admin/users")
async def admin_users(user: str = Depends(get_current_user)):
    if user not in ADMINS: raise HTTPException(403, "Admins only")
    conn = db_connect()
    rows = conn.execute(
        "SELECT username, balance, is_blocked, failed_attempts, locked_until, created_at "
        "FROM users ORDER BY balance DESC"
    ).fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        if d["username"] in ADMINS:
            d["balance"] = 0.0
        d["is_admin"] = d["username"] in ADMINS
        result.append(d)
    return result

@app.get("/api/admin/ledger")
async def admin_ledger(user: str = Depends(get_current_user), limit: int = 200):
    if user not in ADMINS: raise HTTPException(403, "Admins only")
    conn = db_connect()
    rows = conn.execute("SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?",
                        (min(limit, 1000),)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/api/admin/block/{target}")
async def block(target: str, user: str = Depends(get_current_user)):
    if user not in ADMINS: raise HTTPException(403, "Admins only")
    conn = db_connect()
    conn.execute("UPDATE users SET is_blocked=1 WHERE username=?", (target,))
    conn.commit(); conn.close()
    logger.info("Blocked %s by %s", target, user)
    return {"ok": True, "message": f"{target} blocked"}

@app.post("/api/admin/unblock/{target}")
async def unblock(target: str, user: str = Depends(get_current_user)):
    if user not in ADMINS: raise HTTPException(403, "Admins only")
    conn = db_connect()
    conn.execute("UPDATE users SET is_blocked=0, failed_attempts=0, locked_until=NULL WHERE username=?", (target,))
    conn.commit(); conn.close()
    logger.info("Unblocked %s by %s", target, user)
    return {"ok": True, "message": f"{target} unblocked"}

@app.post("/api/admin/reset-pwd/{target}")
async def reset_pwd(target: str, user: str = Depends(get_current_user)):
    """Reset user password to __UNSET__ so they can re-register. Balance preserved."""
    if user not in ADMINS: raise HTTPException(403, "Admins only")
    conn = db_connect()
    conn.execute("UPDATE users SET password_hash='__UNSET__' WHERE username=?", (target,))
    conn.commit(); conn.close()
    logger.info("Password reset for %s by %s", target, user)
    return {"ok": True, "message": f"Password reset for @{target}. They can now re-register."}
