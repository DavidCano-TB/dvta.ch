@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title DVDcoin Bank v4

set APP_DIR=%~dp0
set LOG_DIR=%APP_DIR%logs
set DATA_DIR=%APP_DIR%data
set CONF_DIR=%APP_DIR%conf
set VENV_DIR=%APP_DIR%venv
set PORT=8000
set PS=powershell -NoProfile -ExecutionPolicy Bypass -Command

for %%D in ("%LOG_DIR%" "%DATA_DIR%" "%CONF_DIR%" "%APP_DIR%static\gallery" "%APP_DIR%static\i18n") do (
    if not exist "%%~D" mkdir "%%~D"
)

cls
echo.
echo  ════════════════════════════════════════════
echo   DVDcoin Bank v4
echo  ════════════════════════════════════════════
echo.

:: ── Free port ────────────────────────────────────────────
echo [1/6] Freeing port %PORT%...
for /f "tokens=5" %%i in ('netstat -aon 2^>nul ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (
    if not "%%i"=="0" taskkill /PID %%i /F >nul 2>&1
)
taskkill /IM uvicorn.exe /F >nul 2>&1
taskkill /IM ngrok.exe   /F >nul 2>&1
timeout /t 2 /nobreak >nul

:: ── Python ────────────────────────────────────────────────
echo [2/6] Checking Python...
set PYTHON_CMD=
python --version >nul 2>&1
if %errorlevel% equ 0 set PYTHON_CMD=python & goto :pyok
py -3 --version >nul 2>&1
if %errorlevel% equ 0 set PYTHON_CMD=py -3 & goto :pyok
echo  [ERROR] Python not found.
echo  Install from: https://www.python.org/downloads/
echo  Check "Add Python to PATH" during install.
pause & exit /b 1
:pyok
for /f "tokens=*" %%i in ('!PYTHON_CMD! --version 2^>^&1') do echo  !PYTHON_CMD! = %%i

:: ── Venv ──────────────────────────────────────────────────
echo [3/6] Setting up environment...
if not exist "%VENV_DIR%\Scripts\activate.bat" (
    !PYTHON_CMD! -m venv "%VENV_DIR%"
    if !errorlevel! neq 0 (echo  [ERROR] venv failed & pause & exit /b 1)
)
call "%VENV_DIR%\Scripts\activate.bat"

:: Install packages — bcrypt 4.0.1 ONLY (not passlib bcrypt)
python -m pip install --quiet --upgrade pip
python -m pip install --quiet ^
    "fastapi==0.104.1" ^
    "uvicorn[standard]==0.24.0" ^
    "bcrypt==4.0.1" ^
    "python-jose[cryptography]==3.3.0" ^
    "python-multipart==0.0.6" ^
    "slowapi==0.1.9"
if !errorlevel! neq 0 (echo  [ERROR] pip install failed & pause & exit /b 1)

:: Force correct bcrypt version
python -m pip install "bcrypt==4.0.1" --force-reinstall --no-cache-dir --quiet

echo  Packages ready.

:: ── ngrok ─────────────────────────────────────────────────
echo [4/6] ngrok setup...
set NGROK_EXE=
set NGROK_TOKEN=
set TOKEN_FILE=%CONF_DIR%\.ngrok_token

if exist "%APP_DIR%ngrok.exe" set NGROK_EXE=%APP_DIR%ngrok.exe & goto :ngrok_found
ngrok version >nul 2>&1 & if !errorlevel! equ 0 set NGROK_EXE=ngrok & goto :ngrok_found
winget install --id Ngrok.Ngrok --silent --accept-package-agreements --accept-source-agreements >nul 2>&1
ngrok version >nul 2>&1 & if !errorlevel! equ 0 set NGROK_EXE=ngrok & goto :ngrok_found
%PS% "try{Invoke-WebRequest 'https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip' -OutFile '%TEMP%\ng.zip' -UseBasicParsing;Expand-Archive '%TEMP%\ng.zip' -DestinationPath '%APP_DIR%' -Force;Remove-Item '%TEMP%\ng.zip'}catch{}" >nul 2>&1
if exist "%APP_DIR%ngrok.exe" set NGROK_EXE=%APP_DIR%ngrok.exe & goto :ngrok_found
echo  ngrok not found — local access only.
goto :ngrok_done

:ngrok_found
if exist "%TOKEN_FILE%" (
    set /p NGROK_TOKEN=<"%TOKEN_FILE%"
    if not exist "%LOCALAPPDATA%\ngrok" mkdir "%LOCALAPPDATA%\ngrok"
    (echo authtoken: !NGROK_TOKEN!& echo version: "2") > "%LOCALAPPDATA%\ngrok\ngrok.yml"
    "!NGROK_EXE!" config add-authtoken !NGROK_TOKEN! >nul 2>&1
    echo  Token loaded.
    goto :ngrok_done
)
echo.
echo  ── ngrok token setup ─────────────────────────
echo  1. https://dashboard.ngrok.com/signup
echo  2. https://dashboard.ngrok.com/get-started/your-authtoken
echo  ──────────────────────────────────────────────
set /p "NGROK_TOKEN=  Paste token (Enter to skip): "
if not "!NGROK_TOKEN!"=="" (
    echo !NGROK_TOKEN!>"%TOKEN_FILE%"
    if not exist "%LOCALAPPDATA%\ngrok" mkdir "%LOCALAPPDATA%\ngrok"
    (echo authtoken: !NGROK_TOKEN!& echo version: "2") > "%LOCALAPPDATA%\ngrok\ngrok.yml"
    "!NGROK_EXE!" config add-authtoken !NGROK_TOKEN! >nul 2>&1
)
:ngrok_done

:: ── Verify files ──────────────────────────────────────────
echo [5/6] Verifying files...
if not exist "%APP_DIR%main.py"            (echo  [ERROR] main.py missing        & pause & exit /b 1)
if not exist "%APP_DIR%static\index.html"  (echo  [ERROR] static\index.html missing & pause & exit /b 1)
echo  main.py OK — static\index.html OK

:: ── Start server ──────────────────────────────────────────
echo [6/6] Starting server...
call "%VENV_DIR%\Scripts\activate.bat"
start "DVDcoin-Server" /HIGH cmd /c "cd /d "%APP_DIR%" && call "%VENV_DIR%\Scripts\activate.bat" && uvicorn main:app --host 0.0.0.0 --port %PORT% --log-level info >> "%LOG_DIR%\app.log" 2>&1"

echo  Waiting for server...
set SRV_OK=0
for /l %%i in (1,1,20) do (
    timeout /t 2 /nobreak >nul
    %PS% "try{if((Invoke-WebRequest 'http://localhost:%PORT%/api/health' -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200){exit 0}else{exit 1}}catch{exit 1}" >nul 2>&1
    if !errorlevel! equ 0 (set SRV_OK=1 & goto :srv_ok)
    echo  Still starting %%i/20...
)
echo  [ERROR] Server did not start. Log:
%PS% "Get-Content '%LOG_DIR%\app.log' -Tail 10 -ErrorAction SilentlyContinue"
pause & exit /b 1

:srv_ok
echo  Server ready on port %PORT%

:: ── Start ngrok ───────────────────────────────────────────
set PUBLIC_URL=
if defined NGROK_EXE (
  if not "!NGROK_TOKEN!"=="" (
    start "DVDcoin-Ngrok" /MIN cmd /c ""!NGROK_EXE!" http %PORT% >> "%LOG_DIR%\ngrok.log" 2>&1"
    echo  Waiting for tunnel...
    for /l %%i in (1,1,15) do (
        timeout /t 2 /nobreak >nul
        for /f "delims=" %%u in ('%PS% "try{$t=(Invoke-WebRequest http://localhost:4040/api/tunnels -UseBasicParsing -TimeoutSec 2|ConvertFrom-Json).tunnels;$u=$t|Where{$_.public_url -like 'https*'}|Select -First 1 -Exp public_url;if($u){Write-Output $u}}catch{}" 2^>nul') do set PUBLIC_URL=%%u
        if not "!PUBLIC_URL!"=="" goto :ng_ok
    )
    echo  Tunnel timeout.
    goto :show
    :ng_ok
    echo  Tunnel: !PUBLIC_URL!
  )
)

:show
title DVDcoin Bank v4 — RUNNING
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /i "IPv4" ^| findstr /v "169.254"') do (set LOCAL_IP=%%i & set LOCAL_IP=!LOCAL_IP: =! & goto :ipok)
:ipok
cls
echo.
echo  ════════════════════════════════════════════
echo   DVDcoin Bank v4 — RUNNING
echo  ════════════════════════════════════════════
echo.
echo   LOCAL:  http://localhost:%PORT%
echo           http://!LOCAL_IP!:%PORT%
if not "!PUBLIC_URL!"=="" (
echo.
echo   PUBLIC: !PUBLIC_URL!
echo           ^^ Share with Clubhouse members
)
echo.
echo   Admins: dvd, nina, victor, yu
echo   First time: click Register, not Login
echo   Languages: ES / FR / EN / IT
echo.
echo   STATUS.bat  — server status + URL
echo   kill.bat    — stop everything
echo.
echo  ════════════════════════════════════════════
echo   Press any key to STOP
echo.
if not "!PUBLIC_URL!"=="" (start "" "!PUBLIC_URL!") else (start "" "http://localhost:%PORT%")
pause >nul

:: Cleanup
taskkill /FI "WINDOWTITLE eq DVDcoin-Server" /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq DVDcoin-Ngrok"  /F >nul 2>&1
taskkill /IM ngrok.exe /F >nul 2>&1
echo  Stopped. Data preserved in: %DATA_DIR%
timeout /t 2 /nobreak >nul
