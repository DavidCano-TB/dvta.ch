# Config folder - JWT secret and ngrok token stored here
